﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_day3_bankingApplication
{

    class Saving : Account
    {
        public Saving(int AccountID, string CustomerName, int AccountBalance) : base(AccountID, CustomerName, AccountBalance)
        {
            Console.WriteLine("Current Saving Constructor");
        }

        public override void Deposit(int Amt)
        {
            this.AccountBalance += Amt + 100;

        }

        public override void WithDraw(int Amt)
        {
            this.AccountBalance -= Amt + 10;
        }
    }
}

