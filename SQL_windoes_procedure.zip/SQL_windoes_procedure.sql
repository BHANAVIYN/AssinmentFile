select * from tbl_employees



--1
create proc proc_addemployee(@name varchar(100),
@city varchar(100),@pasword varchar(100))
as
insert tbl_employees values(@name,@city,@pasword,getdate())
return @@identity
--2
create proc proc_employeedetail(@id int)
as
select * from tbl_employees where EmployeeID=@id
--3
create proc proc_showEmployee(@city varchar(100))
as
select * from tbl_employees where EmployeeCity=@city
--4
create proc proc_searchemployee(@key varchar(100))
as
select * from tbl_employees
where EmployeeID like '%'+@key+'%' or EmployeeName like '%'+@key+'%'
or EmployeeCity like '%'+@key+'%';

--5
create proc proc_updateemployee(@id int,@city varchar(100),@pasword varchar(100))
as
update tbl_employees set EmployeeCity=@city,EmployeePasword=@pasword
where EmployeeID=@id
return @@rowcount

--6
create proc proc_deleteemployee(@id int)
as
delete tbl_employees where EmployeeID=@id
return @@rowcount
--7
create proc proc_login(@id int,@pasword varchar(100))
as
declare @count int
select @count=count(*) from tbl_employees where
EmployeeID=@id and EmployeePasword=@pasword
return @count


select * from tbl_employees