﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Class_Reflection
{
   public class Test2
    {
        public string Addvalue()
        {
            return "hello";

        }
        public string Addvalues()
        {
            return "dot net";
        }
    }
}
