use PathfrontDB2

create table tbl_customerrs
(
 customerId int identity(1,1) primary key,
 customerName varchar(100),
 customercity varchar(100),
 customerAddress varchar(100),
 customermobilenumber varchar(100) unique,
 customerPan varchar(100) unique,
 customerPasword varchar(100)
 )

 insert tbl_customerrs values('ramya','Arsikere','jjd',98932787,'jja2872873','87avg57676')

 insert tbl_customerrs values('navya','chennai','vhf',973837,'bjh456','bhg68')

 insert tbl_customerrs values('njdhj','pune','bhbd',993887,'msehdgwy','nndjwqh66')

 insert tbl_customerrs values('bddgwu','hyd','hhgy',883663756,'bdjwhiuwut','jeu7ey7e')

 insert tbl_customerrs values('bwjdtu','dnwdb','hfg',8748874,'bqkjw465','hiuweh579')
 
 insert tbl_customerrs values('njdff','hrfjdb','nwguft',92387443709,'hdhqwoi7f5','jfhw7jhh758')

 insert tbl_customerrs values('jdhdddw','dbhuff','hdwddwo',9448447484,'ndtfwqjhu','kdw4eh887')

 select * from  tbl_customerrs

 create table tbl_Account
 (
 AccountId int identity(100,1) primary key,
 customerid int foreign key references tbl_customerrs(customerid),
 AccountType varchar(100) ,
 AccountBalance int,
 AccountOpenDate Datetime,
AccountStatus varchar(100)
)

insert tbl_Account values(1,'savings',63736,'4-22-2018','open')
insert tbl_Account values(3,'current',837837,'4-24-1996','closed')
insert tbl_Account values(1,'savings',938733,'5-17-2017','open')
insert tbl_Account values(5,'savings',null,'3-11-1999','blockes')
insert tbl_Account values(8,'current',8378387,getdate(),'blocks')
insert tbl_Account values(7,'savings',37586594,'3-3-2018','open')
insert tbl_Account values(9,'current',9358798,getdate(),'open')
insert tbl_Account values(10,'curent',9784857,getdate(),'blocks')
select * from tbl_Account




create table tbl_Transaction
(
transactionId int identity(1000,1) primary key,
Accountid int foreign key references tbl_Account,
Transactiontype varchar(100),
Amount int check(Amount>0),
Transactiondate Datetime
)

insert tbl_Transaction values(100,'withdraw',1000,getdate())
insert tbl_Transaction values(105,'deposit',5000,getdate())
insert tbl_Transaction values(103,'credit',547865,'3-26-2017')
insert tbl_Transaction values(106,'withdraw',95885,'4-24-2016')
insert tbl_Transaction values(104,'deposit',84776,getdate())
insert tbl_Transaction values(106,'withdraw',28370,getdate())
insert tbl_Transaction values(108,'deposit',3298478,'8-18-2018')
 select * from tbl_Transaction
 select top 5 * from tbl_Transaction where Accountid =(100) order by Transactiondate desc

 select * from tbl_Account  where customerid=2

 select tbl_customerrs.customerid,tbl_customerrs.customername,tbl_customerrs.customerAddress,
 tbl_customerrs.customermobilenumber,tbl_account.AccountId,tbl_Account.AccountBalance from tbl_customerrs
 join tbl_Account on tbl_customerrs.customerId=tbl_Account.customerid

 select tbl_Account.AccountId,tbl_Account.AccountBalance,tbl_Transaction.transactionid,
 tbl_Transaction.Amount,tbl_Transaction.transactiontype from tbl_Account join tbl_Transaction
 on tbl_Account.AccountId=tbl_Transaction.Accountid

 select tbl_customerrs.customerid,tbl_customerrs.customername,tbl_customerrs.customermobilenumber,tbl_Account.AccountId,
 tbl_Account.AccountBalance,tbl_Transaction.transactionId,tbl_Transaction.Amount,tbl_Transaction.Transactiontype from
 tbl_customerrs join tbl_Account on  tbl_customerrs.customerId=tbl_Account.customerid
 join tbl_Transaction
 on 
 tbl_Account.AccountId=tbl_Transaction.Accountid

 select * from tbl_customerrs where customerid in( select customerid from tbl_Account)
 
select * from tbl_customerrs where customerId not in(select customerid from tbl_Account)

select * from tbl_Account where AccountId in(select AccountId from tbl_Transaction)

select * from tbl_Account where AccountId not in(select AccountId from tbl_Transaction)

