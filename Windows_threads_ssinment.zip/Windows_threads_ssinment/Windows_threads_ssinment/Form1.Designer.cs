﻿namespace Windows_threads_ssinment
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_sum = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_Number2 = new System.Windows.Forms.TextBox();
            this.txt_Number1 = new System.Windows.Forms.TextBox();
            this.btn_Subs = new System.Windows.Forms.Button();
            this.lst_Results = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btn_sum
            // 
            this.btn_sum.Location = new System.Drawing.Point(85, 274);
            this.btn_sum.Name = "btn_sum";
            this.btn_sum.Size = new System.Drawing.Size(75, 23);
            this.btn_sum.TabIndex = 0;
            this.btn_sum.Text = "Sum";
            this.btn_sum.UseVisualStyleBackColor = true;
            this.btn_sum.Click += new System.EventHandler(this.btn_sum_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(82, 155);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Number 2:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(82, 80);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Number 1:";
            // 
            // txt_Number2
            // 
            this.txt_Number2.Location = new System.Drawing.Point(179, 155);
            this.txt_Number2.Name = "txt_Number2";
            this.txt_Number2.Size = new System.Drawing.Size(164, 22);
            this.txt_Number2.TabIndex = 3;
            // 
            // txt_Number1
            // 
            this.txt_Number1.Location = new System.Drawing.Point(179, 80);
            this.txt_Number1.Name = "txt_Number1";
            this.txt_Number1.Size = new System.Drawing.Size(164, 22);
            this.txt_Number1.TabIndex = 4;
            // 
            // btn_Subs
            // 
            this.btn_Subs.Location = new System.Drawing.Point(248, 274);
            this.btn_Subs.Name = "btn_Subs";
            this.btn_Subs.Size = new System.Drawing.Size(75, 33);
            this.btn_Subs.TabIndex = 5;
            this.btn_Subs.Text = "Substract";
            this.btn_Subs.UseVisualStyleBackColor = true;
            this.btn_Subs.Click += new System.EventHandler(this.btn_Subs_Click);
            // 
            // lst_Results
            // 
            this.lst_Results.FormattingEnabled = true;
            this.lst_Results.ItemHeight = 16;
            this.lst_Results.Location = new System.Drawing.Point(465, 241);
            this.lst_Results.Name = "lst_Results";
            this.lst_Results.Size = new System.Drawing.Size(120, 84);
            this.lst_Results.TabIndex = 6;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(689, 431);
            this.Controls.Add(this.lst_Results);
            this.Controls.Add(this.btn_Subs);
            this.Controls.Add(this.txt_Number1);
            this.Controls.Add(this.txt_Number2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_sum);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_sum;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_Number2;
        private System.Windows.Forms.TextBox txt_Number1;
        private System.Windows.Forms.Button btn_Subs;
        private System.Windows.Forms.ListBox lst_Results;
    }
}

