﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Windows_threads_ssinment
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Calcultr c = new Calcultr();
        private  async void btn_sum_Click(object sender, EventArgs e)
        {
            double d1 = Convert.ToDouble(txt_Number1.Text);
            double d2 = Convert.ToDouble(txt_Number2.Text);

            var t = c.GetCalcultr(d1, d2, "+");

            var result = await t;
            lst_Results.Items.Add(d1 + "+" + d2 + ":" + result);
        }

        private async  void btn_Subs_Click(object sender, EventArgs e)
        {
            double d1 = Convert.ToDouble(txt_Number1.Text);
            double d2 = Convert.ToDouble(txt_Number2.Text);
            var t = c.GetCalcultr(d1, d2, "-");

            var result = await t;
            lst_Results.Items.Add(d1 + "+" + d2 + ":" + result);
       

        }
    }
}
