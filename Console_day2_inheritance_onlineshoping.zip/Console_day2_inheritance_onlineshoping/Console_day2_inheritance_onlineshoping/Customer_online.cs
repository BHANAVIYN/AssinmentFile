﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_day2_inheritance_onlineshoping
{
    class Customer_online:Customer
    {
        private string PaymentType;
        private string DeliveryAddress;

        public Customer_online(string CustomerEmail, string CustomerName, string PaymentType, string DeliveryAddress) : base(CustomerEmail, CustomerName)

        {
            this.PaymentType = PaymentType;
            this.DeliveryAddress = DeliveryAddress;
            Console.WriteLine("Customer Constructor");

        }
        public string PPaymentType
        {
            get
            {
                return this.PaymentType;
            }
        }
        public string PDeliveryAddress
        {
            get
            {
                return this.DeliveryAddress;
            }
        }
    }
}

