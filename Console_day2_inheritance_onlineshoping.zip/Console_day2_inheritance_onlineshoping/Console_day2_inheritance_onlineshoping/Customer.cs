﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_day2_inheritance_onlineshoping
{
    class Customer
    {
        public string CustomerEmailID;
        private string CustomerName;

        public Customer(string CustomerEmailID, string CustomerName)
        {
            this.CustomerEmailID = CustomerEmailID;
            this.CustomerName = CustomerName;

        }

        public string PCustomerEmailID
        {
            get
            {
                return this.CustomerEmailID;

            }
        }
        public string PCustomerName
        {
            get
            {
                return CustomerName;
            }
        }
    }
}


