﻿namespace Windows_Account_MiniProject
{
    partial class Customer_Login_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_loginID = new System.Windows.Forms.Label();
            this.lbl_Password = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lbl_CustomerMOB = new System.Windows.Forms.Label();
            this.lbl_CustomerEmail = new System.Windows.Forms.Label();
            this.lbl_CustomerName = new System.Windows.Forms.Label();
            this.btn_Rest = new System.Windows.Forms.Button();
            this.btn_Login = new System.Windows.Forms.Button();
            this.btn_NewCustomer = new System.Windows.Forms.Button();
            this.btn_Reset = new System.Windows.Forms.Button();
            this.txt_Password = new System.Windows.Forms.TextBox();
            this.txt_LoginID = new System.Windows.Forms.TextBox();
            this.txt_CustomerPassword = new System.Windows.Forms.TextBox();
            this.txt_CustomerMobilNO = new System.Windows.Forms.TextBox();
            this.txt_CustomerEmailID = new System.Windows.Forms.TextBox();
            this.txt_CustomerName = new System.Windows.Forms.TextBox();
            this.rd_Female = new System.Windows.Forms.RadioButton();
            this.rd_Male = new System.Windows.Forms.RadioButton();
            this.lbl_Gender = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl_loginID
            // 
            this.lbl_loginID.AutoSize = true;
            this.lbl_loginID.Location = new System.Drawing.Point(78, 171);
            this.lbl_loginID.Name = "lbl_loginID";
            this.lbl_loginID.Size = new System.Drawing.Size(64, 17);
            this.lbl_loginID.TabIndex = 0;
            this.lbl_loginID.Text = "Login ID:";
            // 
            // lbl_Password
            // 
            this.lbl_Password.AutoSize = true;
            this.lbl_Password.Location = new System.Drawing.Point(78, 249);
            this.lbl_Password.Name = "lbl_Password";
            this.lbl_Password.Size = new System.Drawing.Size(73, 17);
            this.lbl_Password.TabIndex = 1;
            this.lbl_Password.Text = "Password:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(680, 249);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(137, 17);
            this.label4.TabIndex = 3;
            this.label4.Text = "Customer Password:";
            // 
            // lbl_CustomerMOB
            // 
            this.lbl_CustomerMOB.AutoSize = true;
            this.lbl_CustomerMOB.Location = new System.Drawing.Point(680, 176);
            this.lbl_CustomerMOB.Name = "lbl_CustomerMOB";
            this.lbl_CustomerMOB.Size = new System.Drawing.Size(138, 17);
            this.lbl_CustomerMOB.TabIndex = 4;
            this.lbl_CustomerMOB.Text = "Customer MobileNO:";
            // 
            // lbl_CustomerEmail
            // 
            this.lbl_CustomerEmail.AutoSize = true;
            this.lbl_CustomerEmail.Location = new System.Drawing.Point(680, 106);
            this.lbl_CustomerEmail.Name = "lbl_CustomerEmail";
            this.lbl_CustomerEmail.Size = new System.Drawing.Size(123, 17);
            this.lbl_CustomerEmail.TabIndex = 5;
            this.lbl_CustomerEmail.Text = "Customer EmailID:";
            // 
            // lbl_CustomerName
            // 
            this.lbl_CustomerName.AutoSize = true;
            this.lbl_CustomerName.Location = new System.Drawing.Point(680, 45);
            this.lbl_CustomerName.Name = "lbl_CustomerName";
            this.lbl_CustomerName.Size = new System.Drawing.Size(113, 17);
            this.lbl_CustomerName.TabIndex = 6;
            this.lbl_CustomerName.Text = "Customer Name:";
            // 
            // btn_Rest
            // 
            this.btn_Rest.Location = new System.Drawing.Point(222, 354);
            this.btn_Rest.Name = "btn_Rest";
            this.btn_Rest.Size = new System.Drawing.Size(75, 36);
            this.btn_Rest.TabIndex = 7;
            this.btn_Rest.Text = "Reset";
            this.btn_Rest.UseVisualStyleBackColor = true;
            this.btn_Rest.Click += new System.EventHandler(this.btn_Rest_Click);
            // 
            // btn_Login
            // 
            this.btn_Login.Location = new System.Drawing.Point(60, 354);
            this.btn_Login.Name = "btn_Login";
            this.btn_Login.Size = new System.Drawing.Size(75, 36);
            this.btn_Login.TabIndex = 8;
            this.btn_Login.Text = "Login";
            this.btn_Login.UseVisualStyleBackColor = true;
            this.btn_Login.Click += new System.EventHandler(this.btn_Login_Click);
            // 
            // btn_NewCustomer
            // 
            this.btn_NewCustomer.Location = new System.Drawing.Point(743, 417);
            this.btn_NewCustomer.Name = "btn_NewCustomer";
            this.btn_NewCustomer.Size = new System.Drawing.Size(75, 36);
            this.btn_NewCustomer.TabIndex = 9;
            this.btn_NewCustomer.Text = "New";
            this.btn_NewCustomer.UseVisualStyleBackColor = true;
            this.btn_NewCustomer.Click += new System.EventHandler(this.btn_NewCustomer_Click);
            // 
            // btn_Reset
            // 
            this.btn_Reset.Location = new System.Drawing.Point(871, 417);
            this.btn_Reset.Name = "btn_Reset";
            this.btn_Reset.Size = new System.Drawing.Size(75, 36);
            this.btn_Reset.TabIndex = 10;
            this.btn_Reset.Text = "Reset";
            this.btn_Reset.UseVisualStyleBackColor = true;
            this.btn_Reset.Click += new System.EventHandler(this.btn_Reset_Click);
            // 
            // txt_Password
            // 
            this.txt_Password.Location = new System.Drawing.Point(197, 249);
            this.txt_Password.Name = "txt_Password";
            this.txt_Password.Size = new System.Drawing.Size(100, 22);
            this.txt_Password.TabIndex = 11;
            // 
            // txt_LoginID
            // 
            this.txt_LoginID.Location = new System.Drawing.Point(197, 171);
            this.txt_LoginID.Name = "txt_LoginID";
            this.txt_LoginID.Size = new System.Drawing.Size(100, 22);
            this.txt_LoginID.TabIndex = 12;
            // 
            // txt_CustomerPassword
            // 
            this.txt_CustomerPassword.Location = new System.Drawing.Point(824, 246);
            this.txt_CustomerPassword.Name = "txt_CustomerPassword";
            this.txt_CustomerPassword.Size = new System.Drawing.Size(100, 22);
            this.txt_CustomerPassword.TabIndex = 14;
            // 
            // txt_CustomerMobilNO
            // 
            this.txt_CustomerMobilNO.Location = new System.Drawing.Point(824, 176);
            this.txt_CustomerMobilNO.Name = "txt_CustomerMobilNO";
            this.txt_CustomerMobilNO.Size = new System.Drawing.Size(100, 22);
            this.txt_CustomerMobilNO.TabIndex = 15;
            // 
            // txt_CustomerEmailID
            // 
            this.txt_CustomerEmailID.Location = new System.Drawing.Point(824, 106);
            this.txt_CustomerEmailID.Name = "txt_CustomerEmailID";
            this.txt_CustomerEmailID.Size = new System.Drawing.Size(100, 22);
            this.txt_CustomerEmailID.TabIndex = 16;
            // 
            // txt_CustomerName
            // 
            this.txt_CustomerName.Location = new System.Drawing.Point(824, 45);
            this.txt_CustomerName.Name = "txt_CustomerName";
            this.txt_CustomerName.Size = new System.Drawing.Size(100, 22);
            this.txt_CustomerName.TabIndex = 17;
            // 
            // rd_Female
            // 
            this.rd_Female.AutoSize = true;
            this.rd_Female.Location = new System.Drawing.Point(834, 336);
            this.rd_Female.Name = "rd_Female";
            this.rd_Female.Size = new System.Drawing.Size(75, 21);
            this.rd_Female.TabIndex = 18;
            this.rd_Female.TabStop = true;
            this.rd_Female.Text = "Female";
            this.rd_Female.UseVisualStyleBackColor = true;
            // 
            // rd_Male
            // 
            this.rd_Male.AutoSize = true;
            this.rd_Male.Location = new System.Drawing.Point(834, 297);
            this.rd_Male.Name = "rd_Male";
            this.rd_Male.Size = new System.Drawing.Size(59, 21);
            this.rd_Male.TabIndex = 19;
            this.rd_Male.TabStop = true;
            this.rd_Male.Text = "Male";
            this.rd_Male.UseVisualStyleBackColor = true;
            // 
            // lbl_Gender
            // 
            this.lbl_Gender.AutoSize = true;
            this.lbl_Gender.Location = new System.Drawing.Point(734, 301);
            this.lbl_Gender.Name = "lbl_Gender";
            this.lbl_Gender.Size = new System.Drawing.Size(60, 17);
            this.lbl_Gender.TabIndex = 20;
            this.lbl_Gender.Text = "Gender:";
            // 
            // Customer_Login_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1075, 504);
            this.Controls.Add(this.lbl_Gender);
            this.Controls.Add(this.rd_Male);
            this.Controls.Add(this.rd_Female);
            this.Controls.Add(this.txt_CustomerName);
            this.Controls.Add(this.txt_CustomerEmailID);
            this.Controls.Add(this.txt_CustomerMobilNO);
            this.Controls.Add(this.txt_CustomerPassword);
            this.Controls.Add(this.txt_LoginID);
            this.Controls.Add(this.txt_Password);
            this.Controls.Add(this.btn_Reset);
            this.Controls.Add(this.btn_NewCustomer);
            this.Controls.Add(this.btn_Login);
            this.Controls.Add(this.btn_Rest);
            this.Controls.Add(this.lbl_CustomerName);
            this.Controls.Add(this.lbl_CustomerEmail);
            this.Controls.Add(this.lbl_CustomerMOB);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lbl_Password);
            this.Controls.Add(this.lbl_loginID);
            this.Name = "Customer_Login_Form";
            this.Text = "Customer_Login_Form";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_loginID;
        private System.Windows.Forms.Label lbl_Password;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lbl_CustomerMOB;
        private System.Windows.Forms.Label lbl_CustomerEmail;
        private System.Windows.Forms.Label lbl_CustomerName;
        private System.Windows.Forms.Button btn_Rest;
        private System.Windows.Forms.Button btn_Login;
        private System.Windows.Forms.Button btn_NewCustomer;
        private System.Windows.Forms.Button btn_Reset;
        private System.Windows.Forms.TextBox txt_Password;
        private System.Windows.Forms.TextBox txt_LoginID;
        private System.Windows.Forms.TextBox txt_CustomerPassword;
        private System.Windows.Forms.TextBox txt_CustomerMobilNO;
        private System.Windows.Forms.TextBox txt_CustomerEmailID;
        private System.Windows.Forms.TextBox txt_CustomerName;
        private System.Windows.Forms.RadioButton rd_Female;
        private System.Windows.Forms.RadioButton rd_Male;
        private System.Windows.Forms.Label lbl_Gender;
    }
}