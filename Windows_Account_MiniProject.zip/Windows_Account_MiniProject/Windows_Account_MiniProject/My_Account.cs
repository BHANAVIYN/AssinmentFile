﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Windows_Account_MiniProject
{
    public partial class My_Account : Form
    {
        public My_Account()
        {
            InitializeComponent();
        }

        private void btn_Show_Click(object sender, EventArgs e)
        {
            programs_Banking dal = new programs_Banking();
            string CID = txt_CustomerID.Text;
            List<Account> list = dal.showAccount(CID);
            dg_AcntList.DataSource = list;

            Home_Page d = new Home_Page();
            d.Show();
        }

        private void My_Account_Load(object sender, EventArgs e)
        {
            txt_CustomerID.Text = Convert.ToString(CID.CustomerID);
            txt_CustomerID.Enabled = false;
        }
    }
}
   
