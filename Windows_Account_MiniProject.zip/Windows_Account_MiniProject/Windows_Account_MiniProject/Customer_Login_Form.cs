﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Windows_Account_MiniProject
{
    public partial class Customer_Login_Form : Form
    {
        public Customer_Login_Form()
        {
            InitializeComponent();
        }

        private void btn_Login_Click(object sender, EventArgs e)
        {
            int ID = Convert.ToInt32(txt_LoginID.Text);
            string password = txt_Password.Text;
            {
                programs_Banking dal = new programs_Banking();
                bool status = dal.login(ID, password);
                if (status)
                {


                    CID.CustomerID = Convert.ToInt32(ID);

                    MessageBox.Show("valid User");
                    Home_Page Home = new Home_Page();
                    Home.Show();
                }
                else
                {
                    MessageBox.Show("Invalid User");
                }

               
            }
        }


        private void btn_NewCustomer_Click(object sender, EventArgs e)
        {
            if (txt_CustomerName.Text == string.Empty)
            {
                MessageBox.Show("Enter Name");
            }
            else if (txt_CustomerEmailID.Text == string.Empty)
            {
                MessageBox.Show("Enter EmailId");
            }
            else if (txt_CustomerMobilNO.Text == string.Empty)
            {

                MessageBox.Show("Enter valid Mobile Number");
            }
            else if (txt_CustomerPassword.Text == string.Empty)
            {
                MessageBox.Show("Enter Valid Password");
            }
            else if (lbl_Gender.Text == string.Empty)
            {
                MessageBox.Show("Select Gender ");
            }
            else if (rd_Female.Checked == false && rd_Male.Checked == false)
                {
                    MessageBox.Show("Select Your Gender");
                }
                else
                {
                    string Gender = string.Empty;
                    if (rd_Female.Checked)
                    {
                        Gender = "Female";

                    }
                    else
                    {
                        Gender = "Male";
                    }

                    
                    string name = txt_CustomerName.Text;
                    string EmailID = txt_CustomerEmailID.Text;
                    string MobileNO = txt_CustomerMobilNO.Text;
                    string Password = txt_CustomerPassword.Text;
                    Customers obj = new Customers();
                    obj.CustomerName = name;
                    obj.CustomerEmail = EmailID;
                    obj.CustomerMOB = MobileNO;
                    obj.CustomerPassword = Password;
                obj.CustomerGender = Gender;

                    programs_Banking dal = new programs_Banking();
                    int ID = dal.AddCustomer(obj);
                    MessageBox.Show("Customer Added :" + ID);
                }
            }
        

        private void btn_Reset_Click(object sender, EventArgs e)
        {
            txt_CustomerName.Text = string.Empty;
            txt_CustomerEmailID.Text = string.Empty;
            txt_CustomerMobilNO.Text = string.Empty;
            txt_CustomerPassword.Text = string.Empty;
            lbl_Gender.Text = string.Empty;

        }

        private void btn_Rest_Click(object sender, EventArgs e)
        {
            txt_LoginID.Text = string.Empty;
            txt_CustomerPassword.Text = string.Empty;
        }
    }
        }
    

