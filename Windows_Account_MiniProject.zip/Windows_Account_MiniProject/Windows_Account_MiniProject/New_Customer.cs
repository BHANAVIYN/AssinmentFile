﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Windows_Account_MiniProject
{
    public partial class New_Customer : Form
    {
        public New_Customer()
        {
            InitializeComponent();
        }

        private void btn_Reset_Click(object sender, EventArgs e)
        {
            txt_CustomerID.Text = string.Empty;
            txt_AccountType.Text = string.Empty;
            txt_Balance.Text = string.Empty;
        }

        private void btn_New_Click(object sender, EventArgs e)
        {
            if(txt_CustomerID.Text==string.Empty)
            {
                MessageBox.Show("Enter Valid Customer ID");
            }
            else if(txt_AccountType.Text==string.Empty)
            {
                MessageBox.Show("Enter Type of Account");
            }
            else if(txt_Balance.Text==string.Empty)
            {
                MessageBox.Show("Enter Balance");
            }
            else
            {
               


                 int Id = Convert.ToInt32(txt_CustomerID.Text);
                 int Balance = Convert.ToInt32(txt_Balance.Text);

              /*  int Id = txt_CustomerID.Text;
                int Balance = txt_Balance.Text;*/
                string Type = txt_AccountType.Text;
                Account obj = new Account();
                obj.CustomerID=Id;
                obj.AccountType = Type;
                obj.AccountBalance = Balance;

           programs_Banking dal = new programs_Banking();
                int id = dal.AddAccount(obj);
                MessageBox.Show("Customer Added :" + id);


                Home_Page o = new Home_Page();
                o.Show();
            }
        }

        private void New_Customer_Load(object sender, EventArgs e)
        {
            txt_CustomerID.Text = Convert.ToString(CID.CustomerID);
            txt_CustomerID.Enabled = false;
        }
    }
}
