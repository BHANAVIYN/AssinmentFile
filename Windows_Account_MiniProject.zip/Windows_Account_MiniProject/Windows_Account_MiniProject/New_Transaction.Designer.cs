﻿namespace Windows_Account_MiniProject
{
    partial class New_Transaction
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_AccountID = new System.Windows.Forms.Label();
            this.lbl_Amount = new System.Windows.Forms.Label();
            this.btn_MakeTransaction = new System.Windows.Forms.Button();
            this.rd_Withdraw = new System.Windows.Forms.RadioButton();
            this.txt_Amount = new System.Windows.Forms.TextBox();
            this.rd_Deposite = new System.Windows.Forms.RadioButton();
            this.lbl_Type = new System.Windows.Forms.Label();
            this.com_list = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // lbl_AccountID
            // 
            this.lbl_AccountID.AutoSize = true;
            this.lbl_AccountID.Location = new System.Drawing.Point(63, 56);
            this.lbl_AccountID.Name = "lbl_AccountID";
            this.lbl_AccountID.Size = new System.Drawing.Size(80, 17);
            this.lbl_AccountID.TabIndex = 0;
            this.lbl_AccountID.Text = "Account ID:";
            // 
            // lbl_Amount
            // 
            this.lbl_Amount.AutoSize = true;
            this.lbl_Amount.Location = new System.Drawing.Point(63, 135);
            this.lbl_Amount.Name = "lbl_Amount";
            this.lbl_Amount.Size = new System.Drawing.Size(60, 17);
            this.lbl_Amount.TabIndex = 1;
            this.lbl_Amount.Text = "Amount:";
            // 
            // btn_MakeTransaction
            // 
            this.btn_MakeTransaction.Location = new System.Drawing.Point(50, 346);
            this.btn_MakeTransaction.Name = "btn_MakeTransaction";
            this.btn_MakeTransaction.Size = new System.Drawing.Size(253, 45);
            this.btn_MakeTransaction.TabIndex = 3;
            this.btn_MakeTransaction.Text = "Make Transaction:";
            this.btn_MakeTransaction.UseVisualStyleBackColor = true;
            this.btn_MakeTransaction.Click += new System.EventHandler(this.btn_MakeTransaction_Click);
            // 
            // rd_Withdraw
            // 
            this.rd_Withdraw.AutoSize = true;
            this.rd_Withdraw.Location = new System.Drawing.Point(230, 260);
            this.rd_Withdraw.Name = "rd_Withdraw";
            this.rd_Withdraw.Size = new System.Drawing.Size(87, 21);
            this.rd_Withdraw.TabIndex = 5;
            this.rd_Withdraw.TabStop = true;
            this.rd_Withdraw.Text = "Withdraw";
            this.rd_Withdraw.UseVisualStyleBackColor = true;
            // 
            // txt_Amount
            // 
            this.txt_Amount.Location = new System.Drawing.Point(183, 135);
            this.txt_Amount.Name = "txt_Amount";
            this.txt_Amount.Size = new System.Drawing.Size(100, 22);
            this.txt_Amount.TabIndex = 6;
            // 
            // rd_Deposite
            // 
            this.rd_Deposite.AutoSize = true;
            this.rd_Deposite.Location = new System.Drawing.Point(230, 213);
            this.rd_Deposite.Name = "rd_Deposite";
            this.rd_Deposite.Size = new System.Drawing.Size(85, 21);
            this.rd_Deposite.TabIndex = 8;
            this.rd_Deposite.TabStop = true;
            this.rd_Deposite.Text = "Deposite";
            this.rd_Deposite.UseVisualStyleBackColor = true;
            // 
            // lbl_Type
            // 
            this.lbl_Type.AutoSize = true;
            this.lbl_Type.Location = new System.Drawing.Point(77, 215);
            this.lbl_Type.Name = "lbl_Type";
            this.lbl_Type.Size = new System.Drawing.Size(123, 17);
            this.lbl_Type.TabIndex = 9;
            this.lbl_Type.Text = "Transaction Type:";
            // 
            // com_list
            // 
            this.com_list.FormattingEnabled = true;
            this.com_list.Location = new System.Drawing.Point(183, 47);
            this.com_list.Name = "com_list";
            this.com_list.Size = new System.Drawing.Size(121, 24);
            this.com_list.TabIndex = 10;
            // 
            // New_Transaction
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(721, 449);
            this.Controls.Add(this.com_list);
            this.Controls.Add(this.lbl_Type);
            this.Controls.Add(this.rd_Deposite);
            this.Controls.Add(this.txt_Amount);
            this.Controls.Add(this.rd_Withdraw);
            this.Controls.Add(this.btn_MakeTransaction);
            this.Controls.Add(this.lbl_Amount);
            this.Controls.Add(this.lbl_AccountID);
            this.Name = "New_Transaction";
            this.Text = "New_Transaction";
            this.Load += new System.EventHandler(this.New_Transaction_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_AccountID;
        private System.Windows.Forms.Label lbl_Amount;
        private System.Windows.Forms.Button btn_MakeTransaction;
        private System.Windows.Forms.RadioButton rd_Withdraw;
        private System.Windows.Forms.TextBox txt_Amount;
        private System.Windows.Forms.RadioButton rd_Deposite;
        private System.Windows.Forms.Label lbl_Type;
        private System.Windows.Forms.ComboBox com_list;
    }
}