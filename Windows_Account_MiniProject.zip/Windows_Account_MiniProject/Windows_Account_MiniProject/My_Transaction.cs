﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Windows_Account_MiniProject
{
    public partial class My_Transaction : Form
    {
        public My_Transaction()
        {
            InitializeComponent();
        }

        private void btn_Show_Click(object sender, EventArgs e)
        {
            programs_Banking dal = new programs_Banking();
            string AcntID = com_list.Text;
            List<Transaction> list = dal.showTransfer(AcntID);
            dt_ShowTransList.DataSource = list;

            Home_Page r = new Home_Page();
            r.Show();
        }

        private void My_Transaction_Load(object sender, EventArgs e)
        {
            programs_Banking obj = new programs_Banking();
            List<int> lis = obj.showAccount1(CID.CustomerID);
            foreach (var x in lis)
            {

                com_list.Items.Add(x);

            }
        }
    }
    }


