﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Windows_Account_MiniProject
{
    public partial class Home_Page : Form
    {
        public Home_Page()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            New_Transaction TR = new New_Transaction();
            TR.Show();
        }

        private void btn_NewCustomer_Click(object sender, EventArgs e)
        {
            New_Customer Cust = new New_Customer();
            Cust.Show();
        }

        private void btn_MyAccount_Click(object sender, EventArgs e)
        {
            My_Account Ac = new My_Account();
            Ac.Show();
        }

        private void btn_MyTransaction_Click(object sender, EventArgs e)
        {
            My_Transaction MTR = new My_Transaction();
            MTR.Show();
        }
    }
}
