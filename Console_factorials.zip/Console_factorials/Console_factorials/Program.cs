﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_factorials
{
    class Program
    {
        static void Main(string[] args)
        {
            int fact = 1;
            Console.WriteLine("Enter the value for n");
           // int fact = Convert.ToInt32(Console.ReadLine());
            int n = Convert.ToInt32(Console.ReadLine());

            for (int i = 1; i<=n; i++)
            {
                fact = fact * i;
            }
            Console.WriteLine("fact" + fact);

            Console.ReadLine();
        } 
       
        
    }
}
