﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Swapping_Without_Third_Variable
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the value of m and n");
            int m = Convert.ToInt32(Console.ReadLine());
            int n = Convert.ToInt32(Console.ReadLine());

            m = m + n;  // a=m;

            n = m - n;  //n=m;

            m = m - n;   //n=a;

            Console.WriteLine("m:" + m);
            Console.WriteLine("n:" + n);

            Console.ReadLine();
        }
       

    }
}
