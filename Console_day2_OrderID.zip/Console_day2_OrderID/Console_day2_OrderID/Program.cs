﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_day2_OrderID
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("enter custumer name : ");
            string name = Console.ReadLine();
            Console.WriteLine("enter item name : ");
            string item = Console.ReadLine();
            Console.Write("enter item price : ");
            int price = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter item quantity : ");
            int quantity = Convert.ToInt32(Console.ReadLine());

            Order obj = new Order(name, item, price, quantity);


            int a = obj.POrderID;
            string b = obj.PCustomerName;
            string k = obj.PItemName;
            int c = obj.PItemPrice;
            int d = obj.PItemQuantity;

            Console.WriteLine("order id : " + a);
            Console.WriteLine("Customer Name: " + b);
            Console.WriteLine("ItemName : " + k);
            Console.WriteLine("item price : " + c);
            Console.WriteLine("item quantity : " + d);

            int h = obj.amount();
            Console.WriteLine("amount : " + h);

            Console.ReadLine();






        }
    }
}

