﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_day3_Overriding
{
    class Employee_Trainee:Employee
    { 
            public Employee_Trainee(int EmployeeID, string EmployeeName, int EmployeeSalary) : base(EmployeeID, EmployeeName, EmployeeSalary)
            {

            }
            public override int GetSalary(int Days)
            {
                int TotalSalary = this.PEmployeeSalary / 30 * Days - 2000;
                return TotalSalary;
            }
        }
    }

