﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Min_basics
{
    class Program
    {
        static void Main(string[] args)
        {
            int min;
            Console.WriteLine("enter a number of array");
            int n = Convert.ToInt32(Console.ReadLine());
            int[] a = new int[n];

            for(int i=0;i<n;i++)
            {
                a[i] = Convert.ToInt32(Console.ReadLine());
            }
            min = a[0];
            for(int i=0;i<n;i++)
           {
                if(a[i]<min)
                {
                    min = a[i];

                }
            }
            Console.WriteLine("min:" + min);
            Console.ReadLine();



        }
    }
}
