﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_day2_student
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("enter student name");
            string name = Console.ReadLine();
            Console.WriteLine("enter student marks");
            int marks = Convert.ToInt32(Console.ReadLine());

            Student obj = new Student(name, marks);
            int sid = obj.PStudentID;
            string sname = obj.PStudentName;
            int smarks = obj.PStudentmarks;

            Student s1 = new Student("ABC", 90);
            Console.WriteLine(s1.PStudentID);

            Console.WriteLine(sid + " " + sname + " " + smarks);

            obj.PStudentmarks = 101;


            Console.WriteLine(obj.PStudentmarks);

            obj.PStudentmarks = 90;
            Console.WriteLine(obj.PStudentmarks);

            Console.ReadLine();


            Console.ReadLine();
        }
    }
}

