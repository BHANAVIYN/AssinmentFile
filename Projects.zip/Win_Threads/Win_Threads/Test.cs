﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Win_Threads
{
    class Test
    {
        public Task<int> AddnumberAsync(int n1, int n2)
        {
            Task<int> t = Task.Run(() =>
              {
                  System.Threading.Thread.Sleep(5000);
                  return n1 + n2;
              });
            return t;  // this will be the async function 
        }
            
        }
    }

