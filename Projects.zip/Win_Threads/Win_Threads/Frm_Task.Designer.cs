﻿namespace Win_Threads
{
    partial class Frm_Task
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_newtask = new System.Windows.Forms.Button();
            this.btn_Newtask2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_newtask
            // 
            this.btn_newtask.Location = new System.Drawing.Point(145, 163);
            this.btn_newtask.Name = "btn_newtask";
            this.btn_newtask.Size = new System.Drawing.Size(238, 61);
            this.btn_newtask.TabIndex = 0;
            this.btn_newtask.Text = "New task";
            this.btn_newtask.UseVisualStyleBackColor = true;
            this.btn_newtask.Click += new System.EventHandler(this.btn_newtask_Click);
            // 
            // btn_Newtask2
            // 
            this.btn_Newtask2.Location = new System.Drawing.Point(191, 301);
            this.btn_Newtask2.Name = "btn_Newtask2";
            this.btn_Newtask2.Size = new System.Drawing.Size(207, 50);
            this.btn_Newtask2.TabIndex = 1;
            this.btn_Newtask2.Text = "New task 2";
            this.btn_Newtask2.UseVisualStyleBackColor = true;
            this.btn_Newtask2.Click += new System.EventHandler(this.btn_Newtask2_Click);
            // 
            // Frm_Task
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(689, 452);
            this.Controls.Add(this.btn_Newtask2);
            this.Controls.Add(this.btn_newtask);
            this.Name = "Frm_Task";
            this.Text = "Frm_Task";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_newtask;
        private System.Windows.Forms.Button btn_Newtask2;
    }
}