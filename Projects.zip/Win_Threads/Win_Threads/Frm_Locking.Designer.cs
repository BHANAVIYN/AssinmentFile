﻿namespace Win_Threads
{
    partial class Frm_Locking
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_thread1 = new System.Windows.Forms.Button();
            this.lvl_Number1 = new System.Windows.Forms.Label();
            this.lbl_Number1 = new System.Windows.Forms.Label();
            this.txt_Number1 = new System.Windows.Forms.TextBox();
            this.txt_Number2 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btn_thread1
            // 
            this.btn_thread1.Location = new System.Drawing.Point(114, 280);
            this.btn_thread1.Name = "btn_thread1";
            this.btn_thread1.Size = new System.Drawing.Size(205, 52);
            this.btn_thread1.TabIndex = 0;
            this.btn_thread1.Text = "Asynch Sum";
            this.btn_thread1.UseVisualStyleBackColor = true;
            this.btn_thread1.Click += new System.EventHandler(this.btn_thread1_Click);
            // 
            // lvl_Number1
            // 
            this.lvl_Number1.AutoSize = true;
            this.lvl_Number1.Location = new System.Drawing.Point(101, 141);
            this.lvl_Number1.Name = "lvl_Number1";
            this.lvl_Number1.Size = new System.Drawing.Size(74, 17);
            this.lvl_Number1.TabIndex = 1;
            this.lvl_Number1.Text = "Number 2:";
            // 
            // lbl_Number1
            // 
            this.lbl_Number1.AutoSize = true;
            this.lbl_Number1.Location = new System.Drawing.Point(101, 87);
            this.lbl_Number1.Name = "lbl_Number1";
            this.lbl_Number1.Size = new System.Drawing.Size(74, 17);
            this.lbl_Number1.TabIndex = 2;
            this.lbl_Number1.Text = "Number 1:";
            // 
            // txt_Number1
            // 
            this.txt_Number1.Location = new System.Drawing.Point(208, 87);
            this.txt_Number1.Name = "txt_Number1";
            this.txt_Number1.Size = new System.Drawing.Size(100, 22);
            this.txt_Number1.TabIndex = 3;
            // 
            // txt_Number2
            // 
            this.txt_Number2.Location = new System.Drawing.Point(208, 141);
            this.txt_Number2.Name = "txt_Number2";
            this.txt_Number2.Size = new System.Drawing.Size(100, 22);
            this.txt_Number2.TabIndex = 4;
            // 
            // Frm_Locking
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(591, 397);
            this.Controls.Add(this.txt_Number2);
            this.Controls.Add(this.txt_Number1);
            this.Controls.Add(this.lbl_Number1);
            this.Controls.Add(this.lvl_Number1);
            this.Controls.Add(this.btn_thread1);
            this.Name = "Frm_Locking";
            this.Text = "Frm_Locking";
            this.Load += new System.EventHandler(this.Frm_Locking_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_thread1;
        private System.Windows.Forms.Label lvl_Number1;
        private System.Windows.Forms.Label lbl_Number1;
        private System.Windows.Forms.TextBox txt_Number1;
        private System.Windows.Forms.TextBox txt_Number2;
    }
}