﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Find_Num_Palindrome_NotPalindrom
{
    class Program
    {
        static void Main(string[] args)
        {
            string revers = " ";
            string s;
            Console.WriteLine("Enter the String");
            s = Console.ReadLine();
            
            for(int i=s.Length-1;i>=0;i--)

            {
                revers= revers+ s[i].ToString();

            }
            if(revers == s)
            {
                Console.WriteLine("palindrome");
            }
            else
            {
                Console.WriteLine("Not a Pallindrome");
                
            }

            Console.ReadLine();



        }
    }
}
