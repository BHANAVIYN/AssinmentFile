﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_day1_SwitchCase
{
    class Program
    {
        static void Main(string[] args)
        {
            int opt=3 ;
            switch (opt)
            {
                case 1:
                    Console.WriteLine("one");
                    break;
                case 2:
                    Console.WriteLine("two");
                    break;
                case 3:
                    Console.WriteLine("three");
                    break;
                case 4:
                    Console.WriteLine("four");
                    break;
                default:
                    Console.WriteLine("wrong number");
                    break;
            }

            Console.ReadLine();

        }
    }
}

