﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_day2_practiceemp
{
    class Employee
    {
        private int employeeid;
        private string employeename;
        private string employeecity;
        private double employeesalary;

        public Employee(int employeeid, string employeename, string employeecity, double employeesalary)
        {
            this.employeeid = employeeid;
            this.employeename = employeename;
            this.employeecity = employeecity;
            this.employeesalary = employeesalary;


        }
        public double getemployeesalary(int noofdays)
        {
            double d = employeesalary / 30;
            return noofdays * d;

        }
        public string getdetails()
        {
            return this.employeeid + " " + this.employeename + " " + this.employeecity + " " + this.employeesalary + " ";

        }

    }

}

