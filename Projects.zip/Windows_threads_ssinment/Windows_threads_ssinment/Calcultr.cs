﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Windows_threads_ssinment
{
    class Calcultr
    {
        public Task<double> GetCalcultr(double d1,double d2,string operationType)
        {
            Task<double> t = Task.Run(() =>
              {
                  System.Threading.Thread.Sleep(3000);
                  if (operationType == "+")
                  {
                      return d1 + d2;
                  }
                  else if (operationType == "-")
                  {
                      return d1 - d2;
                  }
                  else
                  {
                      throw new Exception("Invalid Operation");
                  }
              });
            return t;
        }
    }
}
