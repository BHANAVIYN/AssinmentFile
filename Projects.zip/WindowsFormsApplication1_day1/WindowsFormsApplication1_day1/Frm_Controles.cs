﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1_day1
{
    public partial class Frm_Controles : Form
    {
        public Frm_Controles()
        {
            InitializeComponent();
        }

        private void Frm_Controles_Load(object sender, EventArgs e)
        {
            lst_Cities.Items.Add("Pune");
            lst_Cities.Items.Add("Chennai");
            lst_Cities.Items.Add("Hyd");
            lst_Cities.Items.Add("banglore");

            cmb_cities.Items.Add("Pune");
            cmb_cities.Items.Add("chennai");
            cmb_cities.Items.Add("Hyd");
            cmb_cities.Items.Add("banglore");

        }

        private void btn_Save_Click(object sender, EventArgs e)
        {
            if (rdb_female.Checked == false && rdb_Male.Checked == false)
            {
                MessageBox.Show("Select Your Gender");
            }
            else
            {
                string gender = string.Empty;
                if (rdb_Male.Checked)
                {
                    gender = "Male";
                }
                else
                {
                    gender = "Female";
                }
                MessageBox.Show(gender);
            }
            bool status = chk_readme.Checked;
            if (status)
            {
                MessageBox.Show("It is Checked");
            }
            else
            {
                MessageBox.Show(" Not Checked");
            }

            if (lst_Cities.Text == string.Empty)
            {
                MessageBox.Show("Select a City");

            }
            else
            {
                string city = lst_Cities.Text;
                MessageBox.Show(city);
            }
        }
    }
}

       
