﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1_day1
{
    public partial class Frm_Sum : Form
    {
        public Frm_Sum()
        {
            InitializeComponent();
        }
        private void BTN_Sum_Click(object sender, EventArgs e)
        {
            if (txt_Number1.Text == string.Empty)
            {
                MessageBox.Show("Enter Number 1");
            }
            else if (txt_Number2.Text == string.Empty)
            {
                MessageBox.Show("Enter Number 2");
            }
            else
            {
                int num1 = Convert.ToInt32(txt_Number1.Text);
                int num2 = Convert.ToInt32(txt_Number2.Text);
                int total = num1 + num2;
                MessageBox.Show("Total:" + total);
            }

        }
    }

}