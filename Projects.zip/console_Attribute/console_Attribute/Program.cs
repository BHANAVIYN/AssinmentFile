﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace console_Attribute
{
    class Program
    {
        static void Main(string[] args)
        {

            // Test obj = new Test();
            // obj.Call1();

            Type t = typeof(Test);
            DeveloperAttribute att = Attribute.GetCustomAttribute(t, typeof(DeveloperAttribute))
                       as DeveloperAttribute;

            Console.WriteLine(att.DeveloperID + " " + att.DeveloperName);

            foreach (MethodInfo m in t.GetMethods())
            {
                DeveloperAttribute attmethod = Attribute.GetCustomAttribute(m, typeof(DeveloperAttribute))
                    as DeveloperAttribute;
                if (attmethod != null)
                {


                    Console.WriteLine(m.Name + " " + attmethod.DeveloperID + " " + attmethod.DeveloperName);
                }

                Console.ReadLine();

            }
        }
    }

}