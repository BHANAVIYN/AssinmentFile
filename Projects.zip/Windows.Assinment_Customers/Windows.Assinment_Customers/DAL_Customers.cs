﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;   
using System.Data.SqlClient;

namespace Windows.Assinment_Customers
{
    class  DAl_Customer_Procedure //DAL_Customers
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["cust"].ConnectionString);
        public int AddCustomer(Customers cus)
        {
            SqlCommand com_cus_insert = new SqlCommand("insert tbl_customers values(@name,@password,@City,@Address,@MOBNO,@EmailID)", con);
            com_cus_insert.Parameters.AddWithValue("@name", cus.CustomerName);
            com_cus_insert.Parameters.AddWithValue("@password", cus.CustomerPassword);
            com_cus_insert.Parameters.AddWithValue("@City", cus.CustomerCity);
            com_cus_insert.Parameters.AddWithValue("@Address", cus.CustomerAddress);
            com_cus_insert.Parameters.AddWithValue("@MoBNO", cus.CustomerMobileNO);
            com_cus_insert.Parameters.AddWithValue("@EmailID", cus.CustomerEmailID);
            con.Open();
            com_cus_insert.ExecuteNonQuery();
            SqlCommand com_id = new SqlCommand("select @@identity", con);  //read the CustomerId one by one
            int ID = Convert.ToInt32(com_id.ExecuteScalar());
            con.Close();
            return ID;

        }
        public Customers Find(int ID)
        {
            SqlCommand com_find = new SqlCommand("select * from tbl_customers where CustomerID=@Id ", con);
            com_find.Parameters.AddWithValue("@Id", ID);
            con.Open();
            SqlDataReader cr = com_find.ExecuteReader();
            if (cr.Read())
            {
                Customers c = new Customers();
                c.CustomerID = cr.GetInt32(0);  //1st column
                c.CustomerName = cr.GetString(1); //2nd column
                c.CustomerPassword = cr.GetString(2);
                c.CustomerCity = cr.GetString(3);
                c.CustomerAddress = cr.GetString(4);
                c.CustomerMobileNO = cr.GetString(5);
                c.CustomerEmailID = cr.GetString(6);
                con.Close();
                return c;
            }
            else
            {
                return null;
            }
        }
        public bool Update(int ID, string City, string Password)
        {

            SqlCommand com_update = new SqlCommand("update tbl_customers set CustomerCity=@city,CustomerPassword=@Password where CustomerId=@id", con);
            com_update.Parameters.AddWithValue("@id", ID);
            com_update.Parameters.AddWithValue("@city", City);
            com_update.Parameters.AddWithValue("@password", Password);
            con.Open();
            int count = com_update.ExecuteNonQuery();
            con.Close();
            if (count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }

        }

        public bool Delete(int ID)
        {
            SqlCommand com_delete = new SqlCommand("delete tbl_employees where EmployeeID=@id", con);
            com_delete.Parameters.AddWithValue("@id", ID);
            con.Open();
            int count = com_delete.ExecuteNonQuery();
            con.Close();
            if (count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        public List<Customers> showcustomer(string City)
        {
            SqlCommand com_customers = new SqlCommand("select * from tbl_customers where CustomerCity=@city", con);
            com_customers.Parameters.AddWithValue("@city", City);
            con.Open();
            SqlDataReader cs = com_customers.ExecuteReader();
            List<Customers> cuslist = new List<Customers>();

            while (cs.Read())
            {
                Customers obj = new Customers();
                obj.CustomerID = cs.GetInt32(0);
                obj.CustomerName = cs.GetString(1);
                obj.CustomerPassword = cs.GetString(2);
                obj.CustomerCity = cs.GetString(3);
                obj.CustomerAddress = cs.GetString(4);
                obj.CustomerMobileNO = cs.GetString(5);
                obj.CustomerEmailID = cs.GetString(6);
                cuslist.Add(obj);
            }
            con.Close(); // ntncry
            return cuslist;
        }

        public List<Customers> search(string Search)
        {
            SqlCommand com_search = new SqlCommand("select * from  tbl_customers where CustomerID like '%" + Search + "%' or CustomerName like ' %" + Search + "%' or CustomerPassword like '%" + Search + "%'", con);
            con.Open();
            SqlDataReader cus = com_search.ExecuteReader();
            List<Customers> custlist = new List<Customers>();
            while (cus.Read())
            {
                Customers obj = new Customers();
                obj.CustomerID = cus.GetInt32(0);
                obj.CustomerName = cus.GetString(1);
                obj.CustomerPassword = cus.GetString(2);
                obj.CustomerCity = cus.GetString(3);
                obj.CustomerAddress = cus.GetString(4);
                obj.CustomerMobileNO = cus.GetString(5);
                obj.CustomerEmailID = cus.GetString(6);
                custlist.Add(obj);


            }

            con.Close();
            return custlist;
        }

        public bool login(int ID, string Password)
        {
            SqlCommand com_log = new SqlCommand("Select * from tbl_customers where CustomerId=@id and CustomerPassword=@Password", con);
            com_log.Parameters.AddWithValue("@Id", ID);
            com_log.Parameters.AddWithValue("@Password", Password);
            con.Open();
            int count = Convert.ToInt32(com_log.ExecuteScalar());
            con.Close();
            if (count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool logininjection(int Id, string Password)
        {
            SqlCommand com_inject = new SqlCommand("select * from tbl_customers where CustomerId=@Id and CustomerPassword=@Password", con);
            com_inject.Parameters.AddWithValue("@Id", Id);
            com_inject.Parameters.AddWithValue("@Password", Password);
            con.Open();
            int count = Convert.ToInt32(com_inject.ExecuteScalar());
            con.Close();
            if (count > 0)

            {
                return true;
            }
            else
            {
                return false;
            }


        }
    }
}


 
