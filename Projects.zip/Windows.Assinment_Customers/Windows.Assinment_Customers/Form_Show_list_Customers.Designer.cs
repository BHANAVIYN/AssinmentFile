﻿namespace Windows.Assinment_Customers
{
    partial class Form_Show_list_Customers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dg_Employees = new System.Windows.Forms.DataGridView();
            this.btn_Find = new System.Windows.Forms.Button();
            this.btn_Search = new System.Windows.Forms.Button();
            this.txt_Search = new System.Windows.Forms.TextBox();
            this.txt_EmployeeCity = new System.Windows.Forms.TextBox();
            this.lbl_search = new System.Windows.Forms.Label();
            this.lbl_Emploteename = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dg_Employees)).BeginInit();
            this.SuspendLayout();
            // 
            // dg_Employees
            // 
            this.dg_Employees.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_Employees.Location = new System.Drawing.Point(105, 294);
            this.dg_Employees.Name = "dg_Employees";
            this.dg_Employees.RowTemplate.Height = 24;
            this.dg_Employees.Size = new System.Drawing.Size(869, 150);
            this.dg_Employees.TabIndex = 13;
            // 
            // btn_Find
            // 
            this.btn_Find.Location = new System.Drawing.Point(746, 73);
            this.btn_Find.Name = "btn_Find";
            this.btn_Find.Size = new System.Drawing.Size(75, 23);
            this.btn_Find.TabIndex = 12;
            this.btn_Find.Text = "Find";
            this.btn_Find.UseVisualStyleBackColor = true;
            this.btn_Find.Click += new System.EventHandler(this.btn_Find_Click);
            // 
            // btn_Search
            // 
            this.btn_Search.Location = new System.Drawing.Point(746, 172);
            this.btn_Search.Name = "btn_Search";
            this.btn_Search.Size = new System.Drawing.Size(75, 23);
            this.btn_Search.TabIndex = 11;
            this.btn_Search.Text = "Search";
            this.btn_Search.UseVisualStyleBackColor = true;
            this.btn_Search.Click += new System.EventHandler(this.btn_Search_Click);
            // 
            // txt_Search
            // 
            this.txt_Search.Location = new System.Drawing.Point(317, 158);
            this.txt_Search.Name = "txt_Search";
            this.txt_Search.Size = new System.Drawing.Size(100, 22);
            this.txt_Search.TabIndex = 10;
            // 
            // txt_EmployeeCity
            // 
            this.txt_EmployeeCity.Location = new System.Drawing.Point(317, 85);
            this.txt_EmployeeCity.Name = "txt_EmployeeCity";
            this.txt_EmployeeCity.Size = new System.Drawing.Size(100, 22);
            this.txt_EmployeeCity.TabIndex = 9;
            // 
            // lbl_search
            // 
            this.lbl_search.AutoSize = true;
            this.lbl_search.Location = new System.Drawing.Point(142, 172);
            this.lbl_search.Name = "lbl_search";
            this.lbl_search.Size = new System.Drawing.Size(53, 17);
            this.lbl_search.TabIndex = 8;
            this.lbl_search.Text = "Search";
            // 
            // lbl_Emploteename
            // 
            this.lbl_Emploteename.AutoSize = true;
            this.lbl_Emploteename.Location = new System.Drawing.Point(142, 90);
            this.lbl_Emploteename.Name = "lbl_Emploteename";
            this.lbl_Emploteename.Size = new System.Drawing.Size(138, 17);
            this.lbl_Emploteename.TabIndex = 7;
            this.lbl_Emploteename.Text = "EmployeeName City:";
            // 
            // Form_Show_list_Customers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1078, 517);
            this.Controls.Add(this.dg_Employees);
            this.Controls.Add(this.btn_Find);
            this.Controls.Add(this.btn_Search);
            this.Controls.Add(this.txt_Search);
            this.Controls.Add(this.txt_EmployeeCity);
            this.Controls.Add(this.lbl_search);
            this.Controls.Add(this.lbl_Emploteename);
            this.Name = "Form_Show_list_Customers";
            this.Text = "Form_Show_list_Customers";
            ((System.ComponentModel.ISupportInitialize)(this.dg_Employees)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dg_Employees;
        private System.Windows.Forms.Button btn_Find;
        private System.Windows.Forms.Button btn_Search;
        private System.Windows.Forms.TextBox txt_Search;
        private System.Windows.Forms.TextBox txt_EmployeeCity;
        private System.Windows.Forms.Label lbl_search;
        private System.Windows.Forms.Label lbl_Emploteename;
    }
}