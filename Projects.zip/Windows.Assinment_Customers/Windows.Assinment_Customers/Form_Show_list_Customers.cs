﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Windows.Assinment_Customers
{
    public partial class Form_Show_list_Customers : Form
    {
        public Form_Show_list_Customers()
        {
            InitializeComponent();
        }

        private void btn_Find_Click(object sender, EventArgs e)
        {
            DAL_Customers dal = new DAL_Customers();
            string city = txt_EmployeeCity.Text;
            List<Customers> list = dal.showcustomer(city);
            dg_Employees.DataSource = list;
        }

        private void btn_Search_Click(object sender, EventArgs e)
        {
            DAL_Customers dal = new DAL_Customers();
            string key = txt_Search.Text;
            List<Customers> list = dal.search(key);
            dg_Employees.DataSource = list;
        }
    }
}
