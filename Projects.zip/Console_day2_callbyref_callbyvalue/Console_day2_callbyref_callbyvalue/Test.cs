﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_day2_callbyref_callbyvalue
{
    class Test
    {
        public void call(ref int amt)
        {
            //Console.WriteLine(amt);
        }
        public void CallArray(params int[] marks)
        {
            foreach (int m in marks)
            {
                Console.WriteLine(m);
            }
        }
        public int GetOrderValue(int itemprice, int itemqty = 1)
        {
            return itemqty * itemprice;
        }
    }
}





