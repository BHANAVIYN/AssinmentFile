﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Link
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Customer> custlist = new List<Customer>();
            custlist.Add(new Customer { CustomerID = 1, CustomerAge = 25, CustomerCity = "BGl", CustomerName = "bhavya" });  //object intializer
            custlist.Add(new Customer { CustomerID = 2, CustomerAge = 30, CustomerCity = "Bang", CustomerName="navya" });
            custlist.Add(new Customer { CustomerID = 3, CustomerAge = 22, CustomerCity = "Ask", CustomerName = "bhagya" });
            custlist.Add(new Customer { CustomerID = 4, CustomerAge = 20, CustomerCity = "Hassan", CustomerName = "Madhu" });


            List<Order> ordlist = new List<Order>();
            ordlist.Add(new Order { OrderID = 100, CustomerID = 1, ItemName = "Samsong", ItemPrice = 60000 });
            ordlist.Add(new Order { OrderID = 101, CustomerID = 2, ItemName = "Geon", ItemPrice = 40000 });
            ordlist.Add(new Order { OrderID = 102, CustomerID = 3, ItemName = "vivo", ItemPrice = 26000 });
            ordlist.Add(new Order { OrderID = 103, CustomerID = 4, ItemName = "Oppo", ItemPrice = 30000 });

            string city = "BGl";
                var q = from c in custlist
                        where c.CustomerCity == city
                        orderby c.CustomerAge descending,c.CustomerName ascending

                        select c;
            foreach(var x in q)
            {
                Console.WriteLine(x.CustomerID + " " + x.CustomerName + " " + x.CustomerCity);
            }

            var count = (from c in custlist
                         where c.CustomerCity == city
                         select c).Count();

            Console.WriteLine(count);

            var obj = (from c in custlist
                       where c.CustomerID == 1
                       select c).FirstOrDefault();

            if(obj!=null)
            {
                Console.WriteLine(obj.CustomerID + " " + obj.CustomerName);
            }
            else
            {
                Console.WriteLine("Not Found");
            }

            var qdata = from c in custlist
                        where c.CustomerAge > 20
                        select new { CID = c.CustomerID, CName = c.CustomerName, CCity = c.CustomerCity };
                 
            foreach(var p in qdata)
            {
                Console.WriteLine(p.CID + " " + p.CName + " " + p.CCity);


            }

            var joindata = from c in custlist
                           join o in ordlist
      on c.CustomerID equals o.CustomerID
                           select new { CId = c.CustomerID, CName = c.CustomerName, OID = o.OrderID, ItemName = o.ItemName, Price = o.ItemPrice };


            foreach(var j in joindata)
            {
                Console.WriteLine(j.CId+" "+j.CName+" "+j.OID+" "+j.ItemName+" "+j.Price);
            }



                        Console.ReadLine();
        }
    }
}
