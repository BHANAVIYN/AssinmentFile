﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_day4_generic_employee
{
    class Program
    {
        static void Main(string[] args)
        {
            Company C = new Company("Pathfront", "banglore");
                bool flag = true;
            while(flag)
            {
                Console.WriteLine("Enter  The Expected Operation:1-Add,2-Search,3-Remove,4-Show,5-Leave,6-Exit");
                int Opt = Convert.ToInt32(Console.ReadLine());
                switch (Opt)
                {
                    case 1:
                        Console.WriteLine("Enter Employee Name:");
                        string Name = Console.ReadLine();
                        Console.WriteLine("Enter Employee City");
                        string City = Console.ReadLine();
                        Employee E = new Employee(Name, City);
                        C.AddEmployee(E);
                        Console.WriteLine("Employee Added:" + E.PEmpID);
                        break;
                    case 2:
                        Console.WriteLine("Enter Employee ID:");
                        int ID = Convert.ToInt32(Console.ReadLine());
                        Employee Obj = C.Search(ID);
                        if (Obj != null)
                        {
                            Console.WriteLine(Obj.PEmpID + " " + Obj.PEmpName);
                        }
                        else
                        {
                            Console.WriteLine("Employee Not Found");
                        }
                        break;
                    case 3:
                        Console.WriteLine("Enter Employee ID:");
                        int EID = Convert.ToInt32(Console.ReadLine());
                        bool Status = C.Remove(EID);
                        if (Status)
                        {
                            Console.WriteLine("Employee is Removed from the list");
                        }
                        else
                        {
                            Console.WriteLine("Employee is Not Found from the list");
                        }
                        break;
                
                    case 4:
                        C.ShowAll();
                        break;
                    case 5:
                        Console.WriteLine("Enter the Employee ID:");
                        int EmpId = Convert.ToInt32(Console.ReadLine());
                        Employee EObj = C.Search(EmpId);
                        Console.WriteLine("Enter Reason");
                        string Reason = Console.ReadLine();
                        EObj.TakeLeave(Reason);
                        break;
                    case 6:
                        flag = false;
                        break;
                    



                }            
            }


        }
    }
}
