﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_day1_quantity
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("enter any item:");
            string itemname = Console.ReadLine();
            Console.WriteLine("enter item quantity");
            int quantity = Convert.ToInt32(Console.ReadLine());
            if (quantity < 1)
            {
                Console.WriteLine("invalid quantity");
            }
            else
            {
                Console.WriteLine("order placed");
            }
            Console.ReadLine();
        }

    }
}

