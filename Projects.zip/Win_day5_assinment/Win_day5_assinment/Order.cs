﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Win_day5_assinment
{
    class Order
    {
        private string CsmName;
        private int OrderId;
        private int Quantity;
        private int Price;
        private string Address;
        private string PaymentType;
        private string cities;

        public Order(string CsmName,int OrderId,int Quantity,int Price,string Address,string PaymentType,string cities)
        {
            this.CsmName = CsmName;
            this.OrderId = OrderId;
            this.Quantity = Quantity;
            this.Price = Price;
            this.Address = Address;
            this.PaymentType = PaymentType;
            this.cities = cities;

        }
        public int getOrderValue()
        {
            return this.Quantity * Price;
        }

    }
}
