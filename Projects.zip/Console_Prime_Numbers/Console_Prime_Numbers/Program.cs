﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Prime_Numbers
{
    class Program
    {
        static void Main(string[] args)
        {
            int flag = 0;
            Console.WriteLine("Enter the value of p");
            int p = Convert.ToInt32(Console.ReadLine());
            for (int i = 2; i <= p / 2; i++)
            {

                if (p % i == 0)
                {
                    flag = 1;
                    break;
                }
                if (p == 1)
                {
                    Console.WriteLine("Given number is cons number");
                }

                if (flag == 0)
                {
                    Console.WriteLine("Given number is  prime number");
                }
                else
                {
                    Console.WriteLine("Given number is not  prime number");
                }
                Console.ReadLine();
            }
        }
    }
}