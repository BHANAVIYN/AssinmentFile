﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_day5_Dictionary
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string, string> name = new Dictionary<string, string>();
            name.Add("E1", "Ajay");
            name.Add("E2", "vijay");
            name.Add("E3", "jhon");
            name.Add("E4", "Rosy");

            foreach(KeyValuePair<string,string> s in name)
            {
                Console.WriteLine(s.Key + " " + s.Value);
            }
            foreach(string k in name.Keys)
            {
                Console.WriteLine(k); 
            }
            foreach( string v in name.Values)
            {
                Console.WriteLine(v);
                
            }

            string n = name["E1"];
            Console.WriteLine(name);

            Console.ReadLine();
           
        }
    }
}
