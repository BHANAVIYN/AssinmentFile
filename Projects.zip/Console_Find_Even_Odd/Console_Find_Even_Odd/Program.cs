﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Find_Even_Odd
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the value of n");

            int n = Convert.ToInt32(Console.ReadLine());
           // for (int i = 1; i < 5; i++)
            
                if (n % 2 == 0)
                {
                    Console.WriteLine("Given number is even");

                }
                else
                {
                    Console.WriteLine("Given number is Odd");
                }
                Console.ReadLine();
            }
        }
    }

