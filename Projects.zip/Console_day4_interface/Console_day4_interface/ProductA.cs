﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_day4_interface
{
    class ProductA:Iproduct_Transport
    {
        private int ProductID;
        private string ProductName;

        public ProductA(int ProductID,string ProductName)
        {

            this.ProductID = ProductID;
            this.ProductName = ProductName;
       
        }
        public int Getprice()
        {

            return 20000;
        }
        public string GetDetails()
        {

            return this.ProductID + " " + this.ProductName;
        }

        public string Getadress()
        {
            return "xyz,Pune";
        }
    }
}
