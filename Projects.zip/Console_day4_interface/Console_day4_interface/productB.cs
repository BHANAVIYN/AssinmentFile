﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_day4_interface
{
    class ProductB:Iproduct_Transport
    {

        private int PID;
        private string Pname;

        public ProductB(int PID, string Pname)
        {

            this.PID = PID;
            this.Pname = Pname
        }
        public int Getprice()
        {

            return 20000;
        }
        public string GetDetails()
        {
            return this.PID + " " + this.Pname;
        }
        public void Strat() //function of the product are start and stop
        { }
        public void Stop()
        { }

        public string Getadress() //implimentation of transport
        {
            return "ABC,Chenni";
        }
    }
}
