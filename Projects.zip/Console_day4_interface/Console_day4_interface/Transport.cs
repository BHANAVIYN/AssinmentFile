﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_day4_interface
{
    class Transport
    {
        public void Send(Iproduct_Transport obj) //Iproduct_Transport is interface variable
        {
            string Address = obj.Getadress();
            Console.WriteLine("Delivery Address:" + Address);

        }


    }

}
