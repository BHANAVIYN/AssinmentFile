﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_day3_bankingApplication
{
        abstract class Account
        {
            protected int AccountID;
            protected string CustomerName;
            protected int AccountBalance;
            public Account(int AccountID, string CustomerName, int AccountBalance)
            {
                this.AccountBalance = AccountID;
                this.CustomerName = CustomerName;
                this.AccountBalance = AccountBalance;
                Console.WriteLine("Account Constructor:");

            }
            public int PAccountID
            {
                get
                {
                    return this.AccountID;
                }
            }
            public string PCustomerName
            {
                get
                {
                    return this.CustomerName;
                }
            }
            public int PAccountBalance
            {
                get
                {
                    return this.PAccountBalance;
                }
            }

            public void StopPayment()
            {
                Console.WriteLine("Stop PaymenT Called");
            }
            public void BlockAccount()
            {
                Console.WriteLine("Block Account Called");
            }
            public int GetBalance()
            {
                return this.AccountBalance;
            }
            public abstract void Deposit(int Amt);
            public abstract void WithDraw(int Amt);

        }
    }

