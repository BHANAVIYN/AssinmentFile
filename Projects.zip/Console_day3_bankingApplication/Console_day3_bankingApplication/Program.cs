﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_day3_bankingApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Account ID:");
            int id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Customer Name:");
            string name = Console.ReadLine();
            Console.WriteLine("Enter Account Balance:");
            int balance = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Account Type:");
            string type = Console.ReadLine();

            Account obj = null;
            if (type == "Saving")
            {
                obj = new Saving(id, name, balance);
            }
            else if (type == "Current")
            {
                obj = new Current(id, name, balance);
            }
            if (obj != null)
            {
                obj.StopPayment();
                obj.BlockAccount();
                int AccBalance = obj.GetBalance();
                Console.WriteLine("Balance:" + AccBalance);
                Console.WriteLine("Enter an amount to deposit:");
                int Amt = Convert.ToInt32(Console.ReadLine());
                obj.Deposit(Amt);
                AccBalance = obj.GetBalance();
                Console.WriteLine("Balance:" + AccBalance);
                Console.WriteLine("Enter an amount to withdraw:");
                Amt = Convert.ToInt32(Console.ReadLine());
                obj.WithDraw(Amt);
                AccBalance = obj.GetBalance();
                Console.WriteLine("Balance:" + AccBalance);

            }
            Console.ReadLine();


        }

    }
}


