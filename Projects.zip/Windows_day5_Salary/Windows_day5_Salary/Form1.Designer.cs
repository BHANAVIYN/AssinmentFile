﻿namespace Windows_day5_Salary
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_Days = new System.Windows.Forms.Label();
            this.lbl_perdaysalary = new System.Windows.Forms.Label();
            this.txt_days = new System.Windows.Forms.TextBox();
            this.txt_perdaysalary = new System.Windows.Forms.TextBox();
            this.btn_getsalary = new System.Windows.Forms.Button();
            this.lbl_salary = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl_Days
            // 
            this.lbl_Days.AutoSize = true;
            this.lbl_Days.Location = new System.Drawing.Point(127, 117);
            this.lbl_Days.Name = "lbl_Days";
            this.lbl_Days.Size = new System.Drawing.Size(42, 17);
            this.lbl_Days.TabIndex = 0;
            this.lbl_Days.Text = "days:";
            // 
            // lbl_perdaysalary
            // 
            this.lbl_perdaysalary.AutoSize = true;
            this.lbl_perdaysalary.Location = new System.Drawing.Point(123, 160);
            this.lbl_perdaysalary.Name = "lbl_perdaysalary";
            this.lbl_perdaysalary.Size = new System.Drawing.Size(98, 17);
            this.lbl_perdaysalary.TabIndex = 1;
            this.lbl_perdaysalary.Text = "per day salary";
            // 
            // txt_days
            // 
            this.txt_days.Location = new System.Drawing.Point(274, 117);
            this.txt_days.Name = "txt_days";
            this.txt_days.Size = new System.Drawing.Size(179, 22);
            this.txt_days.TabIndex = 2;
            this.txt_days.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // txt_perdaysalary
            // 
            this.txt_perdaysalary.Location = new System.Drawing.Point(274, 160);
            this.txt_perdaysalary.Name = "txt_perdaysalary";
            this.txt_perdaysalary.Size = new System.Drawing.Size(179, 22);
            this.txt_perdaysalary.TabIndex = 3;
            // 
            // btn_getsalary
            // 
            this.btn_getsalary.Location = new System.Drawing.Point(146, 254);
            this.btn_getsalary.Name = "btn_getsalary";
            this.btn_getsalary.Size = new System.Drawing.Size(137, 37);
            this.btn_getsalary.TabIndex = 4;
            this.btn_getsalary.Text = "Get Salary";
            this.btn_getsalary.UseVisualStyleBackColor = true;
            this.btn_getsalary.Click += new System.EventHandler(this.btn_getsalary_Click);
            // 
            // lbl_salary
            // 
            this.lbl_salary.AutoSize = true;
            this.lbl_salary.Location = new System.Drawing.Point(358, 254);
            this.lbl_salary.Name = "lbl_salary";
            this.lbl_salary.Size = new System.Drawing.Size(52, 17);
            this.lbl_salary.TabIndex = 5;
            this.lbl_salary.Text = "Salary:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1008, 465);
            this.Controls.Add(this.lbl_salary);
            this.Controls.Add(this.btn_getsalary);
            this.Controls.Add(this.txt_perdaysalary);
            this.Controls.Add(this.txt_days);
            this.Controls.Add(this.lbl_perdaysalary);
            this.Controls.Add(this.lbl_Days);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_Days;
        private System.Windows.Forms.Label lbl_perdaysalary;
        private System.Windows.Forms.TextBox txt_days;
        private System.Windows.Forms.TextBox txt_perdaysalary;
        private System.Windows.Forms.Button btn_getsalary;
        private System.Windows.Forms.Label lbl_salary;
    }
}

