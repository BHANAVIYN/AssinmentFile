﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Class_day5_sum_assinment
{
    class Airthmatic_Operation
    {
        private int Number1;
        private int Number2;

        public Airthmatic_Operation(int Number1,int Number2)
        {
            this.Number1 = Number1;
            this.Number2 = Number2;
        }

    }
}
