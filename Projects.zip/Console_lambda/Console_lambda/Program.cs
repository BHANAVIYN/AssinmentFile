﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_lambda
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Customer> custlist = new List<Customer>();
            custlist.Add(new Customer { CustomerID = 1, CustomerAge = 25, CustomerCity = "BGL", CustomerName = "bhavya" });  //object intializer
            custlist.Add(new Customer { CustomerID = 2, CustomerAge = 30, CustomerCity = "Bang", CustomerName = "navya" });
            custlist.Add(new Customer { CustomerID = 3, CustomerAge = 22, CustomerCity = "Ask", CustomerName = "bhagya" });
            custlist.Add(new Customer { CustomerID = 4, CustomerAge = 20, CustomerCity = "BGL", CustomerName = "Madhu" });


            List<Order> ordlist = new List<Order>();
            ordlist.Add(new Order { OrderID = 100, CustomerID = 1, ItemName = "Samsong", ItemPrice = 60000 });
            ordlist.Add(new Order { OrderID = 101, CustomerID = 2, ItemName = "Geon", ItemPrice = 40000 });
            ordlist.Add(new Order { OrderID = 102, CustomerID = 3, ItemName = "vivo", ItemPrice = 26000 });
            ordlist.Add(new Order { OrderID = 103, CustomerID = 4, ItemName = "Oppo", ItemPrice = 30000 });

            //it gives list 

            var data = custlist.Where((c) => c.CustomerCity == "BGL"); //lambda expression
            foreach (var x in data)
            {
                Console.WriteLine(x.CustomerID + " " + x.CustomerName);
            }
            var count = custlist.Count((c) => c.CustomerCity == "BGL");
            Console.WriteLine(count);


            // first value based on list
            var obj = custlist.FirstOrDefault((c) => c.CustomerID == 1);
            if (obj != null)
            {
                Console.WriteLine(obj.CustomerID + " " + obj.CustomerName);
            }
            else
            {
                Console.WriteLine("Not Found");
            }

            //Exist gives true or false

            var status = custlist.Exists((c) => c.CustomerID == 1);
            Console.WriteLine(status);

            var dataprojection = custlist.Where((c) => c.CustomerCity == "BGL").
                Select((s) => new { CID = s.CustomerID, CName = s.CustomerName });

            foreach(var d in  dataprojection)
            {
                Console.WriteLine(d.CID + " " + d.CName);
            }

            // Orderby class

            var dataorderby = custlist.Where((c) => c.CustomerAge > 20).OrderBy((o) => o.CustomerName).
                ThenByDescending((o1) => o1.CustomerCity);
            foreach(var d in dataorderby)
            {
                Console.WriteLine(d.CustomerID + " " + d.CustomerName + " " + d.CustomerCity);
            }

           //Group by clss

            var groupdata = custlist.GroupBy((g) => g.CustomerCity).      //using group by cls (.)
                Select((s) => new
                {
                    City = s.Key,
                    Count = s.Count(),
                    Avg = s.Average((a) => a.CustomerAge)
                });
            foreach(var x in groupdata)
            {
                Console.WriteLine(x.City + " " + x.Count + " " + x.Avg);
            }

            //joins 

            var joindata = custlist.Join(ordlist,
                (c) => c.CustomerID,
                (o) => o.CustomerID,
                (c, o) => new
                {
                    CID = c.CustomerID,
                    CName = c.CustomerName,
                    OID = o.OrderID,
                    IName = o.ItemName,
                    Iprice = o.ItemPrice
                });
            foreach(var j in joindata)
            {
                Console.WriteLine(j.CID + " " + j.CName + " " + j.OID + " " + j.IName + " " + j.Iprice);
            }

               
         

            Console.ReadLine();
        }
    }
}
