﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Windows_assinment_Dal_Student
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_Add_Click(object sender, EventArgs e)
        {
            if (txt_StudentName.Text == string.Empty)
            {
                MessageBox.Show("Enter Name");
            }
            else if (txt_StudentCity.Text == string.Empty)
            {
                MessageBox.Show("Enter City");
            }
            else if (txt_StudentAddress.Text == string.Empty)
            {

                MessageBox.Show("Enter valid Address");

            }
            else if(txt_StudentEmailId.Text==string.Empty)
            {
                MessageBox.Show("Enter Valid Email ID");
            }
            else
            {
                string name =txt_StudentName.Text;
                string City = txt_StudentCity.Text;
                string Address = txt_StudentAddress.Text;
                string EmailID = txt_StudentEmailId.Text;
                Students obj = new Students();
                obj.StudentName = name;
                obj.StudentCity = City;
                obj.Studentaddress = Address;
                obj.StudentEmailID = EmailID;

                DAL_Students dal = new DAL_Students();
                int id = dal.AddStudent(obj);
                MessageBox.Show("Student Added :" + id);
            }

        }

        private void btn_Find_Click(object sender, EventArgs e)
        {
            if (txt_StudentID.Text == string.Empty)
            {
                MessageBox.Show("Enter ID");
            }
            else
            {
                int Id = Convert.ToInt32(txt_StudentID.Text);
                DAL_Students dal = new DAL_Students();
                Students stu = dal.Find(Id);
                if (stu != null)
                {
                    txt_StudentName.Text = stu.StudentName;
                    txt_StudentCity.Text = stu.StudentCity;
                    txt_StudentAddress.Text = stu.Studentaddress;
                    txt_StudentEmailId.Text = stu.StudentEmailID;
                }
                else
                {
                    MessageBox.Show("Not Found");
                }
            }
        }

        private void btn_Update_Click(object sender, EventArgs e)
        {
            if (txt_StudentID.Text == string.Empty)
            {
                MessageBox.Show("Enter ID");
            }
            else if (txt_StudentCity.Text == string.Empty)
            {
                MessageBox.Show("Enter City");
            }
            else if (txt_StudentEmailId.Text == string.Empty)
            {
                MessageBox.Show("Enter valid EmailID");
            }
            else
            {
                int ID = Convert.ToInt32(txt_StudentID.Text);
                string city = txt_StudentCity.Text;
                string EmailID = txt_StudentEmailId.Text;

                DAL_Students std = new DAL_Students();
                bool status = std.Update(ID, city, EmailID);
                if (status)
                {
                    MessageBox.Show("Update");
                }


                else
                {
                    MessageBox.Show("Not Update");
                }


            }
        }

        private void btn_Delete_Click(object sender, EventArgs e)
        {

            if (txt_StudentID.Text == string.Empty)
            {
                MessageBox.Show("Enter ID");
            }
            else
            {
                int ID = Convert.ToInt32(txt_StudentID.Text);
                DAL_Students std = new DAL_Students();
                bool status = std.Delete(ID);
                if (status)
                {
                    MessageBox.Show("Deleted");
                }
                else
                {
                    MessageBox.Show("Not Founds");
                }
            }
        }

        private void btn_Reset_Click(object sender, EventArgs e)
        {
            txt_StudentID.Text = string.Empty;
           txt_StudentName.Text = string.Empty;
            txt_StudentCity.Text = string.Empty;
           txt_StudentAddress.Text = string.Empty;
            txt_StudentEmailId.Text = string.Empty;
        }
    }
}



