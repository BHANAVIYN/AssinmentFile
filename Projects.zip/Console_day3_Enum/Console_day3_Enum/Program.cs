﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using a = day_3_enum_var_dynamic_using1;
using static day_3_enum_var_dynamic_using1.Test;

namespace day_3_enum_var_dynamic_using
{
    class Program
    {
        static void Main(string[] args)
        {
            var obj = new a.Test();
            a.Test t = new a.Test();
            t.MakePayment(PaymentType.NetBanking);
            call();

        }
    }
}

