﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Salary_day5_liberary
{
    public class Salary
    {
        public int GetSalary(int days,int per_day_salary)
        {
            return days * per_day_salary+1000;

        }
    }
}
