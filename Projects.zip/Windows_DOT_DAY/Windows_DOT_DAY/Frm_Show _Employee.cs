﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Windows_DOT_DAY
{
    public partial class Frm_Show__Employee : Form
    {
        public Frm_Show__Employee()
        {
            InitializeComponent();
        }

        private void btn_Find_Click(object sender, EventArgs e)
        {
            EmployeeDall dal = new EmployeeDall();
            string city = txt_EmployeeCity.Text;
            List<Employee> list = dal.showEmployees(city);
            dg_Employees.DataSource = list;
        }

        private void btn_Search_Click(object sender, EventArgs e)
        {
            EmployeeDall dal = new EmployeeDall();
            string key = txt_Search.Text;
            List<Employee> list = dal.SearchEmployees(key);
            dg_Employees.DataSource = list;
        }
    }
}
