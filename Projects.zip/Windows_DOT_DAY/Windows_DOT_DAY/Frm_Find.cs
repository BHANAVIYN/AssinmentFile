﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Windows_DOT_DAY
{
    public partial class Frm_Find : Form
    {
        public Frm_Find()
        {
            InitializeComponent();
        }

        private void btn_newemployee_Click(object sender, EventArgs e)
        {
            if (txt_EmployeeID.Text == string.Empty)
            {
                MessageBox.Show("Enter ID");
            }
            else
            {
                int Id = Convert.ToInt32(txt_EmployeeID.Text);
                EmployeeDall dal = new EmployeeDall();
                Employee emp = dal.Find(Id);
                if (emp != null)
                {
                    txt_EmployeeName.Text = emp.EmployeeName;
                    txt_EmployeePassword.Text = emp.EmployeePasword;
                    txt_EmployeeCity.Text = emp.EmployeeCity;
                    txt_EmployeeDOJ.Text = emp.EmployeeDOJ.ToString();
                }
                else
                {
                    MessageBox.Show("Not Found");
                }
            }
        }

        private void btn_Update_Click(object sender, EventArgs e)
        {
            if (txt_EmployeeID.Text == string.Empty)
            {
                MessageBox.Show("Enter ID");
            }
            else if (txt_EmployeeCity.Text == string.Empty)
            {
                MessageBox.Show("Enter City");
            }
            else if (txt_EmployeePassword.Text == string.Empty)
            {
                MessageBox.Show("Enter valid Password");
            }
            else
            {
                int ID = Convert.ToInt32(txt_EmployeeID.Text);
                string city = txt_EmployeeCity.Text;
                string pasword = txt_EmployeePassword.Text;

                EmployeeDall dal = new EmployeeDall();
                bool status = dal.Update(ID, city, pasword);
                if (status)
                {
                    MessageBox.Show("Update");
                }


                else
                {
                    MessageBox.Show("Not Update");
                }

            }
        }

        private void btn_Delet_Click(object sender, EventArgs e)
        {
            if(txt_EmployeeID.Text==string.Empty)
            {
                MessageBox.Show("Enter ID");
            }
            else
            {
                int ID = Convert.ToInt32(txt_EmployeeID.Text);
                EmployeeDall dal = new EmployeeDall();
                bool status = dal.Delete(ID);
                if(status)
                {
                    MessageBox.Show("Deleted");
                }
                else
                {
                    MessageBox.Show("Not Founds");
                }
            }
        }
    }
}



       
