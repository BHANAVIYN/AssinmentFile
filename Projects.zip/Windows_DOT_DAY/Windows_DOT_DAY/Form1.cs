﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Windows_DOT_DAY
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_Reset_Click(object sender, EventArgs e)
        {
            txt_EmployeeName.Text = string.Empty;
            txt_EmployeePassword.Text = string.Empty;
            txt_EmployeeCity.Text = string.Empty;
        }

        private void btn_newemployee_Click(object sender, EventArgs e)
        {
            if (txt_EmployeeName.Text == string.Empty)
            {
                MessageBox.Show("Enter Name");
            }
            else if (txt_EmployeeCity.Text == string.Empty)
            {
                MessageBox.Show("Enter City");
            }
            else if (txt_EmployeePassword.Text == string.Empty)
            {

                MessageBox.Show("Enter valid Password");

            }
            else
            {
                string name = txt_EmployeeName.Text;
                string City = txt_EmployeeCity.Text;
                string Pasword = txt_EmployeePassword.Text;
                Employee obj = new Employee();
                obj.EmployeeName = name;
                obj.EmployeeCity = City;
                obj.EmployeePasword = Pasword;

                EmployeeDall dal = new EmployeeDall();
                int id = dal.AddEmployee(obj);
                MessageBox.Show("Employee Added :" + id);
            }


        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }

}
