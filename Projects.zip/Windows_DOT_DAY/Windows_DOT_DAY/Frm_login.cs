﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Windows_DOT_DAY
{
    public partial class Frm_login : Form
    {
        public Frm_login()
        {
            InitializeComponent();
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            int ID = Convert.ToInt32(txt_login.Text);
            string password = txt_Password.Text;
            try
            {
                EmployeeDall dal = new EmployeeDall();
                bool status = dal.login(ID, password);
                if (status)
                {
                    MessageBox.Show("valid User");
                }
                else
                {
                    MessageBox.Show("Invalid User");
                }

            }
            catch(System.Data.SqlClient.SqlException exp)
            {
                MessageBox.Show("SQl Error");
            }
            catch (Exception exp)
            {
                MessageBox.Show("Try Again");
            }
            finally
            {
                MessageBox.Show("Finally block");
            }
        }

        private void btn_Logininjection_Click(object sender, EventArgs e)
        {
            string id = txt_login.Text;
            string password = txt_Password.Text;

            EmployeeDall dal = new EmployeeDall();
            bool status = dal.loginInjection(id, password);
            if(status)
            {
                MessageBox.Show("Valid User ");

            }
            else
            {
                MessageBox.Show("Invalid User");
            }
        }
    }
}
