﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Windows_dya5_sum_exeapplication
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //private void btn_GetResult_Click(object sender, EventArgs e)
        //{
        //    if (txt_Number1.Text == string.Empty)
        //    {
        //        MessageBox.Show("Enter Number 1");
        //    }
        //    else if (txt_Number2.Text == string.Empty)
        //    {
        //        MessageBox.Show("Enter Number 2");
        //    }
        //    else
            
        //        int num1 = Convert.ToInt32(txt_Number1.Text);
        //        int num2 = Convert.ToInt32(txt_Number2.Text);
        //        Class_day5_sum_assinment.Calculator obj = new Class_day5_sum_assinment.Calculator();
        //        int Sum = obj.GetSum(num1, num2);
        //        int mul = obj.GetMultiply(num1, num2);
        //        int sub = obj.GetResult(num1, num2);
        //        int div = obj.GetResult(num1, num2);

                //        lbl_Sum.Text = Sum.ToString();
                //        lbl_Mul.Text = mul.ToString();
                //        lbl_Sub.Text = sub.ToString();
                //        lbl_Div.Text = div.ToString();




                //    }
                //}





        private void btn_GetSum_Click(object sender, EventArgs e)
        {
            if (txt_Number1.Text == string.Empty)
            {
                MessageBox.Show("Enter Number 1");
            }
            else if (txt_Number2.Text == string.Empty)
            {
                MessageBox.Show("Enter Number 2");
            }
            else
            {
                int num1 = Convert.ToInt32(txt_Number1.Text);
                int num2 = Convert.ToInt32(txt_Number2.Text);
                Class_day5_sum_assinment.Calculator obj = new Class_day5_sum_assinment.Calculator();
                int Sum = obj.GetSum(num1, num2);
                lbl_GetResult.Text = Sum.ToString();
            }
        }

        private void btn_GetMul_Click(object sender, EventArgs e)
        {
            if (txt_Number1.Text == string.Empty)
            {
                MessageBox.Show("Enter the Number1");
            }
            else if (txt_Number2.Text == string.Empty)
            {
                MessageBox.Show("Enter the Number2");
            }
            else
         {
                    int num3 = Convert.ToInt32(txt_Number1.Text);
                    int num4 = Convert.ToInt32(txt_Number2.Text);
                    Class_day5_sum_assinment.Calculator obj = new Class_day5_sum_assinment.Calculator();
                    int mul = obj.GetMultiply(num3, num4);
                    lbl_GetResult.Text = mul.ToString();

                }
            }

        private void btn_Sub_Click(object sender, EventArgs e)
        {
            if(txt_Number1.Text==string.Empty)
            {
                MessageBox.Show("Enter The Number1");
            }
            else if(txt_Number2.Text==string.Empty)
            {
                MessageBox.Show("Enter the Number2");
            }
            else
            {
                int num5 = Convert.ToInt32(txt_Number1.Text);
                int num6 = Convert.ToInt32(txt_Number2.Text);
                Class_day5_sum_assinment.Calculator obj = new Class_day5_sum_assinment.Calculator();
                int sub = obj.GetSubstraction(num5, num6);
                lbl_GetResult.Text = sub.ToString();
                

            }
        }

        private void btn_Div_Click(object sender, EventArgs e)
        {
            if(txt_Number1.Text==string.Empty)
            {
                MessageBox.Show("Enter the Number1");
            }
            else if(txt_Number2.Text==string.Empty)
            {
                MessageBox.Show("Enter the Number2");
            }
            else
            {
                int num7 = Convert.ToInt32(txt_Number1.Text);
                int num8 = Convert.ToInt32(txt_Number2.Text);
                Class_day5_sum_assinment.Calculator obj = new Class_day5_sum_assinment.Calculator();
                int div = obj.GetDivide(num7, num8);
                lbl_GetResult.Text = div.ToString();
            }
        }
    }
    }









