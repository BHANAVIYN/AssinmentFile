﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_lambda_linq
{
    class Employee
    {
        public int EmployeeID { get; set; }

        public string EmployeeName { get; set; }

        public int EmployeeSalary { get; set; }

        public int EmployeeExperiance { get; set; }

        public string EmployeeCity { get; set; }

    }
}
