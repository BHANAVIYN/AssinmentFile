﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_lambda_linq
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Employee> emplist = new List<Employee>();
            emplist.Add(new Employee { EmployeeID = 1, EmployeeName = "bhavya", EmployeeSalary = 20000, EmployeeExperiance = 2, EmployeeCity = "banglore" });
            emplist.Add(new Employee { EmployeeID = 2, EmployeeName = "bhagya", EmployeeSalary = 30000, EmployeeExperiance = 6, EmployeeCity = "Hyd" });
            emplist.Add(new Employee { EmployeeID = 3, EmployeeName = "Madhu", EmployeeSalary = 60000, EmployeeExperiance = 7, EmployeeCity = "hyd" });
            emplist.Add(new Employee { EmployeeID = 4, EmployeeName = "Akash", EmployeeSalary = 70000, EmployeeExperiance = 5, EmployeeCity = "banglore" });
            emplist.Add(new Employee { EmployeeID = 5, EmployeeName = "bhanu", EmployeeSalary = 55000, EmployeeExperiance = 6, EmployeeCity = "Udupi" });

            List<Employee_leave> empleave = new List<Employee_leave>();
            empleave.Add(new Employee_leave { LeaveID = 100, LeaveType = "sick", EmployeeID = 2, Reason = "fvr" });
            empleave.Add(new Employee_leave { LeaveID = 101, LeaveType = "skr", EmployeeID = 3, Reason = "Not well" });
            empleave.Add(new Employee_leave { LeaveID = 102, LeaveType = "fvr", EmployeeID = 4, Reason = "fnctn" });
            empleave.Add(new Employee_leave { LeaveID = 103, LeaveType = "gnrl", EmployeeID = 3, Reason = "not well" });

            //Linq

            var q = from e in emplist
                    where e.EmployeeExperiance >= 5
                    select e;
            foreach (var x in q)
            {
                Console.WriteLine(x.EmployeeName + " " + x.EmployeeExperiance);
            }

            //lambda

            var find = emplist.Where((e) => e.EmployeeExperiance > 5).
                 Select((s) => new { EXp = s.EmployeeExperiance, Name = s.EmployeeName });

            foreach (var x in find)
            {
                Console.WriteLine(x.EXp + " " + x.Name);


            }

            //linq

            var sal = from e in emplist
                      where e.EmployeeSalary >= 50000
                      select e;
            foreach (var x in sal)
            {
                Console.WriteLine(x.EmployeeName + " " + x.EmployeeSalary);
            }

            //lambda

            var salary = emplist.Where((e) => e.EmployeeSalary>=50000).
                 Select((s) => new { salr = s.EmployeeSalary, Name = s.EmployeeName });

            foreach (var x in salary)
            {
                Console.WriteLine(x.salr + " " + x.Name);
            }


            //linq

            var  city= from e in emplist
                      where e.EmployeeCity=="banglore"
                      select e;
            foreach (var x in city)
            {
                Console.WriteLine(x.EmployeeName + " " + x.EmployeeCity);
            }

            //lambda

            var C= emplist.Where((e) => e.EmployeeCity=="banglore").
                 Select((s) => new { City=s.EmployeeCity, Name = s.EmployeeName });

            foreach (var x in C)
            {
                Console.WriteLine(x.City + " " + x.Name);
            }

            //linq

            var list = from e in emplist
                       where e.EmployeeName.StartsWith("A")
                       select e;
            foreach(var x in list)
            {
                Console.WriteLine(x.EmployeeName+" "+x.EmployeeID+" "+x.EmployeeExperiance);
            }

            //lambda

            var l= emplist.Where((e) => e.EmployeeName.StartsWith("A")).
                 Select((s) => new { Name = s.EmployeeName,ID=s.EmployeeID,EXP=s.EmployeeExperiance });

            foreach (var x in l)
            {
                Console.WriteLine(x.Name+" "+x.ID+" "+x.EXP);
            }


            //linq

            var join = from e in emplist
                           join v in empleave
      on e.EmployeeID equals v.EmployeeID
                           select new { CId = e.EmployeeID, CName = e.EmployeeName, OID = v.LeaveID,type=v.LeaveType,re=v.Reason };


            foreach (var a in join)
            {
                Console.WriteLine(a.CId + " " + a.CName + " " + a.OID + " " + a.OID + " " +a.re);
            }

            //lambda

            var joinEMp = emplist.Join(empleave,
                (e) => e.EmployeeID,
                (Le) => Le.EmployeeID,
                (e, Le) => new
                {
                    EID = e.EmployeeID,
                    Ename = e.EmployeeName,
                    LID = Le.LeaveID,
                    Ltype = Le.LeaveType,
                    Lre = Le.Reason
                });

            foreach(var L in joinEMp)
            {
                Console.WriteLine(L.EID + " " + L.Ename + " " + L.LID + " " + L.Ltype + " " + L.Lre);
            }












            Console.ReadLine();


            }
        }
    }
