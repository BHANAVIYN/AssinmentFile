﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_day2_employee
{
    class Employee
    {
        private int EmployeeID;
        private string EmployeeName;
        private string EmployeeCity;
        private double EmployeeSalary;

        public Employee(int EmployeeID, string EmployeeName, string EmployeeCity, double EmployeeSalary)
        {
            this.EmployeeID = EmployeeID;
            this.EmployeeName = EmployeeName;
            this.EmployeeCity = EmployeeCity;
            this.EmployeeSalary = EmployeeSalary;
        }
        public double GetEmployeeSalary(int NoofDays)
        {
            double d = EmployeeSalary / 30;
            return NoofDays * d;


        }
        public string Getdetails()
        {
            return this.EmployeeID + " " + this.EmployeeName + " " + this.EmployeeCity + " " + this.EmployeeSalary + " ";

        }


    }
}

