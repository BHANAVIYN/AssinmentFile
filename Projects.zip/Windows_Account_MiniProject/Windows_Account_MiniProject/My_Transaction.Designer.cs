﻿namespace Windows_Account_MiniProject
{
    partial class My_Transaction
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Show = new System.Windows.Forms.Button();
            this.lbl_AccountID = new System.Windows.Forms.Label();
            this.dt_ShowTransList = new System.Windows.Forms.DataGridView();
            this.com_list = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.dt_ShowTransList)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_Show
            // 
            this.btn_Show.Location = new System.Drawing.Point(379, 84);
            this.btn_Show.Name = "btn_Show";
            this.btn_Show.Size = new System.Drawing.Size(75, 23);
            this.btn_Show.TabIndex = 0;
            this.btn_Show.Text = "Show";
            this.btn_Show.UseVisualStyleBackColor = true;
            this.btn_Show.Click += new System.EventHandler(this.btn_Show_Click);
            // 
            // lbl_AccountID
            // 
            this.lbl_AccountID.AutoSize = true;
            this.lbl_AccountID.Location = new System.Drawing.Point(53, 34);
            this.lbl_AccountID.Name = "lbl_AccountID";
            this.lbl_AccountID.Size = new System.Drawing.Size(80, 17);
            this.lbl_AccountID.TabIndex = 1;
            this.lbl_AccountID.Text = "Account ID:";
            // 
            // dt_ShowTransList
            // 
            this.dt_ShowTransList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dt_ShowTransList.Location = new System.Drawing.Point(12, 197);
            this.dt_ShowTransList.Name = "dt_ShowTransList";
            this.dt_ShowTransList.RowTemplate.Height = 24;
            this.dt_ShowTransList.Size = new System.Drawing.Size(603, 150);
            this.dt_ShowTransList.TabIndex = 2;
            // 
            // com_list
            // 
            this.com_list.FormattingEnabled = true;
            this.com_list.Location = new System.Drawing.Point(139, 34);
            this.com_list.Name = "com_list";
            this.com_list.Size = new System.Drawing.Size(121, 24);
            this.com_list.TabIndex = 3;
            // 
            // My_Transaction
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(644, 371);
            this.Controls.Add(this.com_list);
            this.Controls.Add(this.dt_ShowTransList);
            this.Controls.Add(this.lbl_AccountID);
            this.Controls.Add(this.btn_Show);
            this.Name = "My_Transaction";
            this.Text = "My_Transaction";
            this.Load += new System.EventHandler(this.My_Transaction_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dt_ShowTransList)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Show;
        private System.Windows.Forms.Label lbl_AccountID;
        private System.Windows.Forms.DataGridView dt_ShowTransList;
        private System.Windows.Forms.ComboBox com_list;
    }
}