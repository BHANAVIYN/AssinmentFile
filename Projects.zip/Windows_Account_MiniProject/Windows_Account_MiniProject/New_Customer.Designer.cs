﻿namespace Windows_Account_MiniProject
{
    partial class New_Customer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_CustomerID = new System.Windows.Forms.Label();
            this.lbl_AccntType = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btn_Reset = new System.Windows.Forms.Button();
            this.btn_New = new System.Windows.Forms.Button();
            this.txt_Balance = new System.Windows.Forms.TextBox();
            this.txt_AccountType = new System.Windows.Forms.TextBox();
            this.txt_CustomerID = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lbl_CustomerID
            // 
            this.lbl_CustomerID.AutoSize = true;
            this.lbl_CustomerID.Location = new System.Drawing.Point(94, 37);
            this.lbl_CustomerID.Name = "lbl_CustomerID";
            this.lbl_CustomerID.Size = new System.Drawing.Size(89, 17);
            this.lbl_CustomerID.TabIndex = 0;
            this.lbl_CustomerID.Text = "Customer ID:";
            // 
            // lbl_AccntType
            // 
            this.lbl_AccntType.AutoSize = true;
            this.lbl_AccntType.Location = new System.Drawing.Point(94, 107);
            this.lbl_AccntType.Name = "lbl_AccntType";
            this.lbl_AccntType.Size = new System.Drawing.Size(99, 17);
            this.lbl_AccntType.TabIndex = 1;
            this.lbl_AccntType.Text = "Account Type:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(94, 189);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "Balance:";
            // 
            // btn_Reset
            // 
            this.btn_Reset.Location = new System.Drawing.Point(274, 296);
            this.btn_Reset.Name = "btn_Reset";
            this.btn_Reset.Size = new System.Drawing.Size(95, 27);
            this.btn_Reset.TabIndex = 3;
            this.btn_Reset.Text = "Reset";
            this.btn_Reset.UseVisualStyleBackColor = true;
            this.btn_Reset.Click += new System.EventHandler(this.btn_Reset_Click);
            // 
            // btn_New
            // 
            this.btn_New.Location = new System.Drawing.Point(76, 296);
            this.btn_New.Name = "btn_New";
            this.btn_New.Size = new System.Drawing.Size(75, 27);
            this.btn_New.TabIndex = 4;
            this.btn_New.Text = "New";
            this.btn_New.UseVisualStyleBackColor = true;
            this.btn_New.Click += new System.EventHandler(this.btn_New_Click);
            // 
            // txt_Balance
            // 
            this.txt_Balance.Location = new System.Drawing.Point(249, 184);
            this.txt_Balance.Name = "txt_Balance";
            this.txt_Balance.Size = new System.Drawing.Size(100, 22);
            this.txt_Balance.TabIndex = 5;
            // 
            // txt_AccountType
            // 
            this.txt_AccountType.Location = new System.Drawing.Point(249, 107);
            this.txt_AccountType.Name = "txt_AccountType";
            this.txt_AccountType.Size = new System.Drawing.Size(100, 22);
            this.txt_AccountType.TabIndex = 6;
            // 
            // txt_CustomerID
            // 
            this.txt_CustomerID.Location = new System.Drawing.Point(249, 37);
            this.txt_CustomerID.Name = "txt_CustomerID";
            this.txt_CustomerID.Size = new System.Drawing.Size(100, 22);
            this.txt_CustomerID.TabIndex = 7;
            // 
            // New_Customer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(826, 399);
            this.Controls.Add(this.txt_CustomerID);
            this.Controls.Add(this.txt_AccountType);
            this.Controls.Add(this.txt_Balance);
            this.Controls.Add(this.btn_New);
            this.Controls.Add(this.btn_Reset);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lbl_AccntType);
            this.Controls.Add(this.lbl_CustomerID);
            this.Name = "New_Customer";
            this.Text = "New_Customer";
            this.Load += new System.EventHandler(this.New_Customer_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_CustomerID;
        private System.Windows.Forms.Label lbl_AccntType;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btn_Reset;
        private System.Windows.Forms.Button btn_New;
        private System.Windows.Forms.TextBox txt_Balance;
        private System.Windows.Forms.TextBox txt_AccountType;
        private System.Windows.Forms.TextBox txt_CustomerID;
    }
}