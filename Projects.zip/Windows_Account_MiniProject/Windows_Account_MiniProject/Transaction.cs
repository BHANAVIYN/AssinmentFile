﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Windows_Account_MiniProject
{
    class Transaction
    {
        public int TransID { get; set; }

        public int AccountID { get; set; }

        public int Amount { get; set; }

        public string TransType { get; set; }

        public DateTime  TransDate { get; set; }
    }
}

 