﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Windows_Account_MiniProject
{
    public partial class New_Transaction : Form
    {
        public New_Transaction()
        {
            InitializeComponent();
        }

        private void btn_MakeTransaction_Click(object sender, EventArgs e)
        {
            if (com_list.Text == string.Empty)
            {
                MessageBox.Show("Enter Valid Customer ID");
            }
            else if (txt_Amount.Text == string.Empty)
            {
                MessageBox.Show("Enter Type of Account");
            }
            else if (lbl_Type.Text == string.Empty)
            {
                MessageBox.Show("Enter Type");
            }
             else if (rd_Deposite.Checked == false && rd_Withdraw.Checked == false)
                {
                    MessageBox.Show("Select Your Type");
                }
                else
                {
                    string TranType = string.Empty;
                    if (rd_Deposite.Checked)
                    {
                         TranType = "Deposite";
                    }
                    else
                    {
                    TranType = "Withdraw";
                    }


                    int AccntID = Convert.ToInt32(com_list.Text);
                    int Amt = Convert.ToInt32(txt_Amount.Text);
              
                    Transaction obj = new Transaction();
                    obj.AccountID = AccntID;
                    obj.Amount =Amt ;
                obj.TransType = TranType;
                

                    programs_Banking dal = new programs_Banking();
                    int id = dal.AddTransaction(obj);
                    MessageBox.Show("Transaction Added :" + id);

                Home_Page s = new Home_Page();
                s.Show();


                }
            }

        private void New_Transaction_Load(object sender, EventArgs e)
        {
            programs_Banking obj = new programs_Banking();
            List<int> lis = obj.showAccount1(CID.CustomerID);
            foreach (var x in lis)
            {

                com_list.Items.Add(x);

            }
        }
    }
    }
