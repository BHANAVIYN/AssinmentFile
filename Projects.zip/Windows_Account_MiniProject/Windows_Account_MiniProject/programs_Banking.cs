﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;   //Dll ref
using System.Data.SqlClient;
using System.Data;

namespace Windows_Account_MiniProject
{
    class programs_Banking
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Bank"].ConnectionString);
        public int AddCustomer(Customers cus)
        {
            SqlCommand com_cus_insert = new SqlCommand("proc_addCustomer", con);
            com_cus_insert.Parameters.AddWithValue("@Name", cus.CustomerName);
            com_cus_insert.Parameters.AddWithValue("@Email", cus.CustomerEmail);
            com_cus_insert.Parameters.AddWithValue("@MOB", cus.CustomerMOB);
            com_cus_insert.Parameters.AddWithValue("@Gender", cus.CustomerGender);
            com_cus_insert.Parameters.AddWithValue("@Password", cus.CustomerPassword);
            com_cus_insert.CommandType = CommandType.StoredProcedure;
            SqlParameter retdata = new SqlParameter(); 
            retdata.Direction = ParameterDirection.ReturnValue;

            com_cus_insert.Parameters.Add(retdata);
            con.Open(); 
            com_cus_insert.ExecuteNonQuery();
            con.Close();

            int ID = Convert.ToInt32(retdata.Value);

            return ID;
        }
        public int AddAccount(Account act)
        {
            SqlCommand com_Act_insert = new SqlCommand("proc_AddAccount", con);
            com_Act_insert.Parameters.AddWithValue("@AcntBalance", act.AccountBalance);
            com_Act_insert.Parameters.AddWithValue("@AcntType", act.AccountType);
            com_Act_insert.Parameters.AddWithValue("@CID", act.CustomerID);
            

            com_Act_insert.CommandType = CommandType.StoredProcedure;
            SqlParameter retdata = new SqlParameter(); 
            retdata.Direction = ParameterDirection.ReturnValue;

            com_Act_insert.Parameters.Add(retdata);
            con.Open(); 
            com_Act_insert.ExecuteNonQuery(); 
            con.Close();

            int ID = Convert.ToInt32(retdata.Value);

            return ID;

        }

        public int AddTransaction(Transaction Tran)
        {
            SqlCommand com_Trans_insert = new SqlCommand("proc_AddTransationse", con);
            com_Trans_insert.Parameters.AddWithValue("@AcntID", Tran.AccountID);
            com_Trans_insert.Parameters.AddWithValue("@Amount", Tran.Amount);
            com_Trans_insert.Parameters.AddWithValue("@TranType",Tran.TransType);
           
            com_Trans_insert.CommandType = CommandType.StoredProcedure;//changing
            SqlParameter retdata = new SqlParameter(); //return value
            retdata.Direction = ParameterDirection.ReturnValue;

            com_Trans_insert.Parameters.Add(retdata);
            con.Open(); // opens the connection
            com_Trans_insert.ExecuteNonQuery(); //it sends or insert the above query to database
            con.Close();

            int ID = Convert.ToInt32(retdata.Value);

            return ID;
        }
        public List<Customers> showCustomers(string EmailID)
        {
            SqlCommand com_customers = new SqlCommand("proc_showCustomer", con);

            com_customers.Parameters.AddWithValue("@EmailID", EmailID);
            com_customers.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = com_customers.ExecuteReader();
            List<Customers> custlist = new List<Customers>();
            while (dr.Read())
            {
                Customers obj = new Customers();
                obj.CustomerID = dr.GetInt32(0);
                obj.CustomerName = dr.GetString(1);
                obj.CustomerEmail = dr.GetString(2);
                obj.CustomerMOB = dr.GetString(3);
                obj.CustomerGender = dr.GetString(4);
                obj.CustomerPassword = dr.GetString(5);
                custlist.Add(obj);

            }
            return custlist;
        }

        public List<Account> showAccount(string CustomerID)
        {
            SqlCommand com_Account = new SqlCommand("proc_ShowAccount", con);

            com_Account.Parameters.AddWithValue("@CID", CustomerID);
            com_Account.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = com_Account.ExecuteReader();
            List<Account> Auctlist = new List<Account>();
            while (dr.Read())
            {
                Account obj = new Account();
                obj.AccountID = dr.GetInt32(0);
                obj.CustomerID = dr.GetInt32(1);
                obj.AccountBalance = dr.GetInt32(2);
                obj.AccountType = dr.GetString(3);
                obj.AccountOpeningDate = dr.GetDateTime(4);

                Auctlist.Add(obj);

            }
            return Auctlist;
        }

        public List<Transaction> showTransfer(string AccountID)
        {
            SqlCommand com_Trans = new SqlCommand("proc_ShowTrans", con);

            com_Trans.Parameters.AddWithValue("@AcntID", AccountID);
            com_Trans.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = com_Trans.ExecuteReader();
            List<Transaction> Translist = new List<Transaction>();
            while (dr.Read())
            {
                Transaction obj = new Transaction();
                obj.TransID = dr.GetInt32(0);
                obj.AccountID = dr.GetInt32(1);
                obj.Amount = dr.GetInt32(2);
                obj.TransType = dr.GetString(3);
                obj.TransDate = dr.GetDateTime(4);
                

                Translist.Add(obj);

            }
            return Translist;
        }

        public bool login(int ID, string Password)
        {
            SqlCommand com_login = new SqlCommand("proc_login", con);

            com_login.Parameters.AddWithValue("@CID", ID);
            com_login.Parameters.AddWithValue("@password", Password);
            com_login.CommandType = CommandType.StoredProcedure;
            SqlParameter retdata = new SqlParameter();
            retdata.Direction = ParameterDirection.ReturnValue;

            com_login.Parameters.Add(retdata);

            con.Open();
            com_login.ExecuteNonQuery();
            con.Close();
            int count = Convert.ToInt32(retdata.Value);
            if (count > 0)
            {
                return true;

            }
            else
            {
                return false;
            }
        }

        public List<int> showAccount1(int CustomerID)
        {
            SqlCommand com_Account = new SqlCommand("proc_ShowAccount", con);

            com_Account.Parameters.AddWithValue("@CID", CustomerID);
            com_Account.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = com_Account.ExecuteReader();
            List<int> Auctlist = new List<int>();
            while (dr.Read())
            {
                Auctlist.Add(dr.GetInt32(0));

            }
            return Auctlist;
        }
    }
     }
    
