﻿namespace Windows_Account_MiniProject
{
    partial class Home_Page
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_NewCustomer = new System.Windows.Forms.Button();
            this.btn_MyAccount = new System.Windows.Forms.Button();
            this.btn_NewTransaction = new System.Windows.Forms.Button();
            this.btn_MyTransaction = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_NewCustomer
            // 
            this.btn_NewCustomer.Location = new System.Drawing.Point(31, 38);
            this.btn_NewCustomer.Name = "btn_NewCustomer";
            this.btn_NewCustomer.Size = new System.Drawing.Size(152, 46);
            this.btn_NewCustomer.TabIndex = 0;
            this.btn_NewCustomer.Text = "New Customer";
            this.btn_NewCustomer.UseVisualStyleBackColor = true;
            this.btn_NewCustomer.Click += new System.EventHandler(this.btn_NewCustomer_Click);
            // 
            // btn_MyAccount
            // 
            this.btn_MyAccount.Location = new System.Drawing.Point(455, 38);
            this.btn_MyAccount.Name = "btn_MyAccount";
            this.btn_MyAccount.Size = new System.Drawing.Size(139, 46);
            this.btn_MyAccount.TabIndex = 1;
            this.btn_MyAccount.Text = "My Account";
            this.btn_MyAccount.UseVisualStyleBackColor = true;
            this.btn_MyAccount.Click += new System.EventHandler(this.btn_MyAccount_Click);
            // 
            // btn_NewTransaction
            // 
            this.btn_NewTransaction.Location = new System.Drawing.Point(31, 161);
            this.btn_NewTransaction.Name = "btn_NewTransaction";
            this.btn_NewTransaction.Size = new System.Drawing.Size(152, 40);
            this.btn_NewTransaction.TabIndex = 2;
            this.btn_NewTransaction.Text = "New Transaction";
            this.btn_NewTransaction.UseVisualStyleBackColor = true;
            this.btn_NewTransaction.Click += new System.EventHandler(this.button3_Click);
            // 
            // btn_MyTransaction
            // 
            this.btn_MyTransaction.Location = new System.Drawing.Point(455, 161);
            this.btn_MyTransaction.Name = "btn_MyTransaction";
            this.btn_MyTransaction.Size = new System.Drawing.Size(139, 40);
            this.btn_MyTransaction.TabIndex = 3;
            this.btn_MyTransaction.Text = "My Transaction";
            this.btn_MyTransaction.UseVisualStyleBackColor = true;
            this.btn_MyTransaction.Click += new System.EventHandler(this.btn_MyTransaction_Click);
            // 
            // Home_Page
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(780, 320);
            this.Controls.Add(this.btn_MyTransaction);
            this.Controls.Add(this.btn_NewTransaction);
            this.Controls.Add(this.btn_MyAccount);
            this.Controls.Add(this.btn_NewCustomer);
            this.Name = "Home_Page";
            this.Text = "Home_Page";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_NewCustomer;
        private System.Windows.Forms.Button btn_MyAccount;
        private System.Windows.Forms.Button btn_NewTransaction;
        private System.Windows.Forms.Button btn_MyTransaction;
    }
}