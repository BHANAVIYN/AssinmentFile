﻿namespace Windows_Account_MiniProject
{
    partial class My_Account
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_CustomerID = new System.Windows.Forms.Label();
            this.btn_Show = new System.Windows.Forms.Button();
            this.dg_AcntList = new System.Windows.Forms.DataGridView();
            this.txt_CustomerID = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dg_AcntList)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_CustomerID
            // 
            this.lbl_CustomerID.AutoSize = true;
            this.lbl_CustomerID.Location = new System.Drawing.Point(65, 45);
            this.lbl_CustomerID.Name = "lbl_CustomerID";
            this.lbl_CustomerID.Size = new System.Drawing.Size(89, 17);
            this.lbl_CustomerID.TabIndex = 0;
            this.lbl_CustomerID.Text = "Customer ID:";
            // 
            // btn_Show
            // 
            this.btn_Show.Location = new System.Drawing.Point(476, 125);
            this.btn_Show.Name = "btn_Show";
            this.btn_Show.Size = new System.Drawing.Size(75, 23);
            this.btn_Show.TabIndex = 1;
            this.btn_Show.Text = "Show";
            this.btn_Show.UseVisualStyleBackColor = true;
            this.btn_Show.Click += new System.EventHandler(this.btn_Show_Click);
            // 
            // dg_AcntList
            // 
            this.dg_AcntList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_AcntList.Location = new System.Drawing.Point(12, 250);
            this.dg_AcntList.Name = "dg_AcntList";
            this.dg_AcntList.RowTemplate.Height = 24;
            this.dg_AcntList.Size = new System.Drawing.Size(666, 150);
            this.dg_AcntList.TabIndex = 2;
            // 
            // txt_CustomerID
            // 
            this.txt_CustomerID.Location = new System.Drawing.Point(160, 45);
            this.txt_CustomerID.Name = "txt_CustomerID";
            this.txt_CustomerID.Size = new System.Drawing.Size(100, 22);
            this.txt_CustomerID.TabIndex = 3;
            // 
            // My_Account
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(707, 444);
            this.Controls.Add(this.txt_CustomerID);
            this.Controls.Add(this.dg_AcntList);
            this.Controls.Add(this.btn_Show);
            this.Controls.Add(this.lbl_CustomerID);
            this.Name = "My_Account";
            this.Text = "My_Account";
            this.Load += new System.EventHandler(this.My_Account_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dg_AcntList)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_CustomerID;
        private System.Windows.Forms.Button btn_Show;
        private System.Windows.Forms.DataGridView dg_AcntList;
        private System.Windows.Forms.TextBox txt_CustomerID;
    }
}