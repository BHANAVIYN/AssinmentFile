﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_day3_abstract_assinment
{
    class Order_Overseas : Order
    {
        public Order_Overseas(int OrderID, string CustomerName, int ItemQty, int ItemPrice) : base(OrderID, CustomerName, ItemQty, ItemPrice)
        {

        }
        public override int GetOrderValue()
        {
            int OrderValue = (this.PItemPrice * this.PItemQty) / 10;
            return OrderValue + this.PItemPrice;
        }
    }
}
