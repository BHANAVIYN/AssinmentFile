﻿namespace WindowsForms_DAl
{
    partial class Find
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_CustomerName = new System.Windows.Forms.Label();
            this.lbl_CustomerPassword = new System.Windows.Forms.Label();
            this.lbl_CustomerCity = new System.Windows.Forms.Label();
            this.lbl_CustomerAddress = new System.Windows.Forms.Label();
            this.txt_CustomerAddress = new System.Windows.Forms.TextBox();
            this.txt_CustomerCity = new System.Windows.Forms.TextBox();
            this.txt_CustomerPassword = new System.Windows.Forms.TextBox();
            this.txt_CustomerName = new System.Windows.Forms.TextBox();
            this.lbl_CustomerMobileNO = new System.Windows.Forms.Label();
            this.lbl_CusomerEmailID = new System.Windows.Forms.Label();
            this.txt_CustomerMobileNO = new System.Windows.Forms.TextBox();
            this.txt_CustomerEmailID = new System.Windows.Forms.TextBox();
            this.btn_Add = new System.Windows.Forms.Button();
            this.btn_Find = new System.Windows.Forms.Button();
            this.btn_Update = new System.Windows.Forms.Button();
            this.btn_Delete = new System.Windows.Forms.Button();
            this.lbl_CustomerID = new System.Windows.Forms.Label();
            this.txt_CustomerID = new System.Windows.Forms.TextBox();
            this.btn_Reset = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_CustomerName
            // 
            this.lbl_CustomerName.AutoSize = true;
            this.lbl_CustomerName.Location = new System.Drawing.Point(30, 119);
            this.lbl_CustomerName.Name = "lbl_CustomerName";
            this.lbl_CustomerName.Size = new System.Drawing.Size(113, 17);
            this.lbl_CustomerName.TabIndex = 0;
            this.lbl_CustomerName.Text = "Customer Name:";
            this.lbl_CustomerName.Click += new System.EventHandler(this.label1_Click);
            // 
            // lbl_CustomerPassword
            // 
            this.lbl_CustomerPassword.AutoSize = true;
            this.lbl_CustomerPassword.Location = new System.Drawing.Point(12, 170);
            this.lbl_CustomerPassword.Name = "lbl_CustomerPassword";
            this.lbl_CustomerPassword.Size = new System.Drawing.Size(137, 17);
            this.lbl_CustomerPassword.TabIndex = 1;
            this.lbl_CustomerPassword.Text = "Customer Password:";
            // 
            // lbl_CustomerCity
            // 
            this.lbl_CustomerCity.AutoSize = true;
            this.lbl_CustomerCity.Location = new System.Drawing.Point(44, 220);
            this.lbl_CustomerCity.Name = "lbl_CustomerCity";
            this.lbl_CustomerCity.Size = new System.Drawing.Size(99, 17);
            this.lbl_CustomerCity.TabIndex = 2;
            this.lbl_CustomerCity.Text = "Customer City:";
            // 
            // lbl_CustomerAddress
            // 
            this.lbl_CustomerAddress.AutoSize = true;
            this.lbl_CustomerAddress.Location = new System.Drawing.Point(15, 267);
            this.lbl_CustomerAddress.Name = "lbl_CustomerAddress";
            this.lbl_CustomerAddress.Size = new System.Drawing.Size(128, 17);
            this.lbl_CustomerAddress.TabIndex = 3;
            this.lbl_CustomerAddress.Text = "Customer Address:";
            // 
            // txt_CustomerAddress
            // 
            this.txt_CustomerAddress.Location = new System.Drawing.Point(174, 264);
            this.txt_CustomerAddress.Name = "txt_CustomerAddress";
            this.txt_CustomerAddress.Size = new System.Drawing.Size(133, 22);
            this.txt_CustomerAddress.TabIndex = 4;
            // 
            // txt_CustomerCity
            // 
            this.txt_CustomerCity.Location = new System.Drawing.Point(174, 215);
            this.txt_CustomerCity.Name = "txt_CustomerCity";
            this.txt_CustomerCity.Size = new System.Drawing.Size(133, 22);
            this.txt_CustomerCity.TabIndex = 5;
            this.txt_CustomerCity.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // txt_CustomerPassword
            // 
            this.txt_CustomerPassword.Location = new System.Drawing.Point(174, 167);
            this.txt_CustomerPassword.Name = "txt_CustomerPassword";
            this.txt_CustomerPassword.Size = new System.Drawing.Size(133, 22);
            this.txt_CustomerPassword.TabIndex = 6;
            // 
            // txt_CustomerName
            // 
            this.txt_CustomerName.Location = new System.Drawing.Point(174, 116);
            this.txt_CustomerName.Name = "txt_CustomerName";
            this.txt_CustomerName.Size = new System.Drawing.Size(133, 22);
            this.txt_CustomerName.TabIndex = 7;
            // 
            // lbl_CustomerMobileNO
            // 
            this.lbl_CustomerMobileNO.AutoSize = true;
            this.lbl_CustomerMobileNO.Location = new System.Drawing.Point(8, 311);
            this.lbl_CustomerMobileNO.Name = "lbl_CustomerMobileNO";
            this.lbl_CustomerMobileNO.Size = new System.Drawing.Size(135, 17);
            this.lbl_CustomerMobileNO.TabIndex = 8;
            this.lbl_CustomerMobileNO.Text = "Customer MobileNo:";
            // 
            // lbl_CusomerEmailID
            // 
            this.lbl_CusomerEmailID.AutoSize = true;
            this.lbl_CusomerEmailID.Location = new System.Drawing.Point(20, 351);
            this.lbl_CusomerEmailID.Name = "lbl_CusomerEmailID";
            this.lbl_CusomerEmailID.Size = new System.Drawing.Size(123, 17);
            this.lbl_CusomerEmailID.TabIndex = 9;
            this.lbl_CusomerEmailID.Text = "Customer EmailID:";
            // 
            // txt_CustomerMobileNO
            // 
            this.txt_CustomerMobileNO.Location = new System.Drawing.Point(174, 306);
            this.txt_CustomerMobileNO.Name = "txt_CustomerMobileNO";
            this.txt_CustomerMobileNO.Size = new System.Drawing.Size(133, 22);
            this.txt_CustomerMobileNO.TabIndex = 10;
            // 
            // txt_CustomerEmailID
            // 
            this.txt_CustomerEmailID.Location = new System.Drawing.Point(174, 346);
            this.txt_CustomerEmailID.Name = "txt_CustomerEmailID";
            this.txt_CustomerEmailID.Size = new System.Drawing.Size(133, 22);
            this.txt_CustomerEmailID.TabIndex = 11;
            // 
            // btn_Add
            // 
            this.btn_Add.Location = new System.Drawing.Point(411, 74);
            this.btn_Add.Name = "btn_Add";
            this.btn_Add.Size = new System.Drawing.Size(75, 23);
            this.btn_Add.TabIndex = 12;
            this.btn_Add.Text = "Add";
            this.btn_Add.UseVisualStyleBackColor = true;
            // 
            // btn_Find
            // 
            this.btn_Find.Location = new System.Drawing.Point(411, 142);
            this.btn_Find.Name = "btn_Find";
            this.btn_Find.Size = new System.Drawing.Size(75, 23);
            this.btn_Find.TabIndex = 13;
            this.btn_Find.Text = "Find";
            this.btn_Find.UseVisualStyleBackColor = true;
            // 
            // btn_Update
            // 
            this.btn_Update.Location = new System.Drawing.Point(411, 214);
            this.btn_Update.Name = "btn_Update";
            this.btn_Update.Size = new System.Drawing.Size(75, 23);
            this.btn_Update.TabIndex = 14;
            this.btn_Update.Text = "Update";
            this.btn_Update.UseVisualStyleBackColor = true;
            // 
            // btn_Delete
            // 
            this.btn_Delete.Location = new System.Drawing.Point(411, 284);
            this.btn_Delete.Name = "btn_Delete";
            this.btn_Delete.Size = new System.Drawing.Size(75, 23);
            this.btn_Delete.TabIndex = 15;
            this.btn_Delete.Text = "Delete";
            this.btn_Delete.UseVisualStyleBackColor = true;
            // 
            // lbl_CustomerID
            // 
            this.lbl_CustomerID.AutoSize = true;
            this.lbl_CustomerID.Location = new System.Drawing.Point(54, 74);
            this.lbl_CustomerID.Name = "lbl_CustomerID";
            this.lbl_CustomerID.Size = new System.Drawing.Size(89, 17);
            this.lbl_CustomerID.TabIndex = 16;
            this.lbl_CustomerID.Text = "Customer ID:";
            this.lbl_CustomerID.Click += new System.EventHandler(this.lbl_CustomerID_Click);
            // 
            // txt_CustomerID
            // 
            this.txt_CustomerID.Location = new System.Drawing.Point(174, 71);
            this.txt_CustomerID.Name = "txt_CustomerID";
            this.txt_CustomerID.Size = new System.Drawing.Size(133, 22);
            this.txt_CustomerID.TabIndex = 17;
            // 
            // btn_Reset
            // 
            this.btn_Reset.Location = new System.Drawing.Point(411, 345);
            this.btn_Reset.Name = "btn_Reset";
            this.btn_Reset.Size = new System.Drawing.Size(75, 23);
            this.btn_Reset.TabIndex = 18;
            this.btn_Reset.Text = "Reset";
            this.btn_Reset.UseVisualStyleBackColor = true;
            // 
            // Find
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(853, 516);
            this.Controls.Add(this.btn_Reset);
            this.Controls.Add(this.txt_CustomerID);
            this.Controls.Add(this.lbl_CustomerID);
            this.Controls.Add(this.btn_Delete);
            this.Controls.Add(this.btn_Update);
            this.Controls.Add(this.btn_Find);
            this.Controls.Add(this.btn_Add);
            this.Controls.Add(this.txt_CustomerEmailID);
            this.Controls.Add(this.txt_CustomerMobileNO);
            this.Controls.Add(this.lbl_CusomerEmailID);
            this.Controls.Add(this.lbl_CustomerMobileNO);
            this.Controls.Add(this.txt_CustomerName);
            this.Controls.Add(this.txt_CustomerPassword);
            this.Controls.Add(this.txt_CustomerCity);
            this.Controls.Add(this.txt_CustomerAddress);
            this.Controls.Add(this.lbl_CustomerAddress);
            this.Controls.Add(this.lbl_CustomerCity);
            this.Controls.Add(this.lbl_CustomerPassword);
            this.Controls.Add(this.lbl_CustomerName);
            this.Name = "Find";
            this.Text = "Find";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_CustomerName;
        private System.Windows.Forms.Label lbl_CustomerPassword;
        private System.Windows.Forms.Label lbl_CustomerCity;
        private System.Windows.Forms.Label lbl_CustomerAddress;
        private System.Windows.Forms.TextBox txt_CustomerAddress;
        private System.Windows.Forms.TextBox txt_CustomerCity;
        private System.Windows.Forms.TextBox txt_CustomerPassword;
        private System.Windows.Forms.TextBox txt_CustomerName;
        private System.Windows.Forms.Label lbl_CustomerMobileNO;
        private System.Windows.Forms.Label lbl_CusomerEmailID;
        private System.Windows.Forms.TextBox txt_CustomerMobileNO;
        private System.Windows.Forms.TextBox txt_CustomerEmailID;
        private System.Windows.Forms.Button btn_Add;
        private System.Windows.Forms.Button btn_Find;
        private System.Windows.Forms.Button btn_Update;
        private System.Windows.Forms.Button btn_Delete;
        private System.Windows.Forms.Label lbl_CustomerID;
        private System.Windows.Forms.TextBox txt_CustomerID;
        private System.Windows.Forms.Button btn_Reset;
    }
}