﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_day1_array
{
    class Program
    {
        static void Main(string[] args)
        {

            int[] nums = new int[5];
            nums[0] = 10;
            nums[1] = 20;
            nums[2] = 30;
            nums[3] = 40;
            nums[4] = 50;
            for (int c = 0; c < nums.Length; c++)
            {
                Console.WriteLine(nums[c]);
            }
            Console.ReadLine();
        }
    }
}
