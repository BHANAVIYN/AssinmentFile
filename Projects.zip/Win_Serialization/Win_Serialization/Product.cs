﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Win_Serialization
{
    [Serializable]      //Attribute like metadata this code must be for serialization incase of xml its not required 
    public class Product  //made bulic
    {
        public int ProductID { get; set; }

        public string ProductName { get; set; }

        public int ProductPrice { get; set; }
    }
}
