﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Xml.Serialization;


namespace Win_Serialization
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_Serialize_Click(object sender, EventArgs e)
        {
            Product p = new Product();
            p.ProductID = Convert.ToInt32(txt_ProductID.Text);
            p.ProductName = txt_ProductName.Text;
            p.ProductPrice = Convert.ToInt32(txt_ProductPrice.Text);

            FileStream fs = new FileStream("c:/TestFolder/product.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite);

            BinaryFormatter b = new BinaryFormatter();
            b.Serialize(fs, p); ;
            fs.Close();
            MessageBox.Show("Binary Serialization Done");

        }

        private void btn_deserialize_Click(object sender, EventArgs e)
        {
            FileStream fs = new FileStream("c:/TestFolder/product.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            BinaryFormatter b = new BinaryFormatter();
            Product p = b.Deserialize(fs) as Product;
            fs.Close();
            txt_ProductID.Text = p.ProductID.ToString();
            txt_ProductName.Text = p.ProductName;
            txt_ProductPrice.Text = p.ProductPrice.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FileStream fs = new FileStream("c:/TestFolder/prod.xml", FileMode.Create, FileAccess.Write);
            Product p = new Product();
            p.ProductID = Convert.ToInt32(txt_ProductID.Text);
            p.ProductName = txt_ProductName.Text;
            p.ProductPrice = Convert.ToInt32(txt_ProductPrice.Text);
            XmlSerializer xml = new XmlSerializer(typeof(Product));
            xml.Serialize(fs, p);
            fs.Close();
            MessageBox.Show("XML Serialization Done");



        }

        private void button1_Click(object sender, EventArgs e)
        {
            FileStream fs = new FileStream("c:/TestFolder/prod.xml", FileMode.Open, FileAccess.Read);
            XmlSerializer xml = new XmlSerializer(typeof(Product));
            Product p = xml.Deserialize(fs) as Product;
            fs.Close();
            txt_ProductID.Text = p.ProductID.ToString();
            txt_ProductName.Text = p.ProductName;
            txt_ProductPrice.Text = p.ProductPrice.ToString();

        }
    }
}
