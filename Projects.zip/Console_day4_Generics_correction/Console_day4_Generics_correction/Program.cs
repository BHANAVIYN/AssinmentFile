﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_day4_Generics_correction
{
    class Program
    {
        static void Main(string[] args)
        {
            College c = new College(1, "Pathfront");
            bool flag = true;
            while (flag)
            {
                Console.WriteLine("Enter you Operation : 1-Add,2-Find,3-Remove,4-Show,5-Exit,6-Leave");
                int Opt = Convert.ToInt32(Console.ReadLine());

                switch (Opt)
                {
                    case 1:
                        Console.WriteLine("Enter StudentName:");
                        String Name = Console.ReadLine();
                        Console.WriteLine("Enter Student City:");
                        String City = Console.ReadLine();
                        Student s = new Student(Name, City);
                        c.AddStudent(s);
                        Console.WriteLine("Student Added  :" + s.PStudentID);
                        break;

                    case 2:
                        Console.WriteLine("Enter Student ID:");
                        int ID = Convert.ToInt32(Console.ReadLine());
                        Student obj = c.Find(ID);
                        if (obj != null)
                        {
                            Console.WriteLine(obj.PStudentID + " " + obj.PStudentName);
                        }
                        else
                        {
                            Console.WriteLine("Student Not Found");
                        }
                        break;

                    case 3:
                        Console.WriteLine("Enter Student ID:");
                        int SID = Convert.ToInt32(Console.ReadLine());
                        bool Status = c.remove(SID);
                        if (Status)

                        {
                            Console.WriteLine("Student Removed");

                        }
                        else
                        {
                            Console.WriteLine("Student Not Found ");
                        }
                        break;
                    case 4:
                        c.ShowAll();
                        break;
                    case 5:
                        flag = false;
                        break;
                    case 6:
                        Console.WriteLine("Enter Student ID :");
                        int StudentID = Convert.ToInt32(Console.ReadLine());
                        Student sobj = c.Find(StudentID);
                        Console.WriteLine("Enter Reason:");
                        string Reason = Console.ReadLine();
                        sobj.TakeLeave(Reason);
                        break;
                }
            }

        }
    }
}