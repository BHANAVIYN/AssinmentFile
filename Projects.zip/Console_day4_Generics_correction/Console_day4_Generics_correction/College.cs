﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_day4_Generics_correction
{
    class College
    {

        public void onleave(int Id,string Reason) //delegate function
        {
            Console.WriteLine("College class: Student on leave :" + Id + "," + Reason);
        }
        private int CollegeID;
        private string CollegeName;

        public College(int CollegeID, string CollegeName)
        {
            this.CollegeID = CollegeID;
            this.CollegeName = CollegeName;
        }
        private List<Student> Studentlist = new List<Student>();
        public void AddStudent(Student st)
        {
           // Student.delleave d = new Student.delleave(this.onleave); // binding code
            st.evtleave += new Student.delleave(this.onleave); //give d also
            // st.evtleave is event and this.onleave is event handling delleave is deligates
            Studentlist.Add(st);

        }
        public Student Find(int ID)    //finding student
        {
            foreach (Student s in Studentlist)
            {
                if (s.PStudentID == ID)
                {
                    return s;
                }
            }



            return null;
        }
        public bool remove(int ID)  //remove student from the list using boolean condition
        {
            foreach (Student s in Studentlist)
            {
                if (s.PStudentID == ID)
                {

                    Studentlist.Remove(s);
                    return true;

                }
            }
            return false;
        }
        public void ShowAll()  //show the details in list
        {
            foreach (Student s in Studentlist)
            {
                Console.WriteLine(s.PStudentID + " " + s.PStudentName + " " + s.PstudentCity);
            }
        }

    }
}

