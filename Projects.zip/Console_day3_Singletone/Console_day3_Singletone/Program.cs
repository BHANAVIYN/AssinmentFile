﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_day3_Singletone
{
    class Program
    {
        static void Main(string[] args)
        {
            Manager m1 = Manager.GetManager();
            Manager m2 = Manager.GetManager();
            if (m1 == m2)
            {
                Console.WriteLine("Singleton");
            }
            else
            {
                Console.WriteLine("Not Singleton");

            }
            Console.ReadLine();
        }
    }
}

