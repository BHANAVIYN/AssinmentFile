﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Class_Reflection
{
   public class Test
    {
        public string Call1()
        {
            return "hi";
        }
        public string Call2()
        {
            return "pathfront";
        }
    }
}
