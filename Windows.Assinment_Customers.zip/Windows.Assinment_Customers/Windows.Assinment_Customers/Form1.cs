﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Windows.Assinment_Customers
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

      

        private void btn_Add_Click(object sender, EventArgs e)
        {
            if (txt_Customerid.Text == string.Empty)
            {
                MessageBox.Show("Enter Valid ID");
            }
            else if (txt_CustomerName.Text == string.Empty)
            {
                MessageBox.Show("Enter Name");

            }
            else if (txt_CustomerPassword.Text == string.Empty)
            {
                MessageBox.Show("Enter Valid Password");
            }
            else if (txt_CustomerCity.Text == string.Empty)
            {
                MessageBox.Show("Enter City");
            }
            else if (txt_CustomerAddress.Text == string.Empty)
            {
                MessageBox.Show("Enter Address");
            }
            else if (txt_CustomerMOB.Text == string.Empty)
            {
                MessageBox.Show("Enter valid Mobile Number");
            }
            else if (txt_CustomerEmailID.Text == string.Empty)
            {
                MessageBox.Show("Enter Valid EmailID");
            }
            else
            {
                string Name = txt_CustomerName.Text;
                string Password = txt_CustomerPassword.Text;
                string City = txt_CustomerCity.Text;
                string Address = txt_CustomerAddress.Text;
                string MobileNo = txt_CustomerMOB.Text;
                string EmailId = txt_CustomerEmailID.Text;

                Customers obj = new Customers();
                obj.CustomerName = Name;
                obj.CustomerPassword = Password;
                obj.CustomerCity = City;
                obj.CustomerAddress = Address;
                obj.CustomerMobileNO = MobileNo;
                obj.CustomerEmailID = EmailId;
                DAL_Customers dal = new DAL_Customers();
                int Id = dal.AddCustomer(obj);
                MessageBox.Show("Enter Added:" + Id);


            }
        }

        private void btn_Find_Click(object sender, EventArgs e)
        {
            if (txt_Customerid.Text == string.Empty)
            {
                MessageBox.Show("Enter ID");
            }
            else
            {
                int Id = Convert.ToInt32(txt_Customerid.Text);
                DAL_Customers cus = new DAL_Customers();
                Customers cust = cus.Find(Id);
                if (cust != null)
                {
                    txt_CustomerName.Text = cust.CustomerName;
                    txt_CustomerPassword.Text = cust.CustomerPassword;
                    txt_CustomerCity.Text = cust.CustomerCity;
                    txt_CustomerAddress.Text = cust.CustomerAddress;
                    txt_CustomerMOB.Text = cust.CustomerMobileNO;
                    txt_CustomerEmailID.Text = cust.CustomerEmailID;
                }
                else
                {
                    MessageBox.Show("Not Found");
                }
            }
        }

        private void btn_update_Click(object sender, EventArgs e)
        {
            if (txt_Customerid.Text == string.Empty)
            {
                MessageBox.Show("Enter ID");
            }
            else if (txt_CustomerCity.Text == string.Empty)
            {
                MessageBox.Show("Enter City");
            }
            else if (txt_CustomerPassword.Text == string.Empty)
            {
                MessageBox.Show("Enter valid Password");
            }
            else
            {
                int ID = Convert.ToInt32(txt_Customerid.Text);
                string city = txt_CustomerCity.Text;
                string pasword = txt_CustomerPassword.Text;

                DAL_Customers dal = new DAL_Customers();
                bool status = dal.Update(ID, city, pasword);
                if (status)
                {
                    MessageBox.Show("Update");
                }


                else
                {
                    MessageBox.Show("Not Update");
                }
            }
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            if (txt_Customerid.Text == string.Empty)
            {
                MessageBox.Show("Enter ID");
            }
            else
            {
                int ID = Convert.ToInt32(txt_Customerid.Text);
                DAL_Customers dal = new DAL_Customers();
                bool status = dal.Delete(ID);
                if (status)
                {
                    MessageBox.Show("Deleted");
                }
                else
                {
                    MessageBox.Show("Not Founds");
                }
            }
        }

      

        private void btn_Reset_Click(object sender, EventArgs e)
        {
            txt_Customerid.Text = string.Empty;
            txt_CustomerName.Text = string.Empty;
            txt_CustomerPassword.Text = string.Empty;
            txt_CustomerCity.Text = string.Empty;
            txt_CustomerAddress.Text = string.Empty;
            txt_CustomerMOB.Text = string.Empty;
            txt_CustomerEmailID.Text = string.Empty;
        }
    }
}

        
