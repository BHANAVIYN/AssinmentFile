﻿namespace Windows.Assinment_Customers
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_customerID = new System.Windows.Forms.Label();
            this.lbl_Customername = new System.Windows.Forms.Label();
            this.lbl_CustomerCity = new System.Windows.Forms.Label();
            this.lbl_Customeraddress = new System.Windows.Forms.Label();
            this.lbl_CustomerMOb = new System.Windows.Forms.Label();
            this.lbl_CustomerEmailId = new System.Windows.Forms.Label();
            this.lbl_CustomerPassword = new System.Windows.Forms.Label();
            this.txt_CustomerPassword = new System.Windows.Forms.TextBox();
            this.txt_CustomerEmailID = new System.Windows.Forms.TextBox();
            this.txt_CustomerMOB = new System.Windows.Forms.TextBox();
            this.txt_CustomerAddress = new System.Windows.Forms.TextBox();
            this.txt_CustomerCity = new System.Windows.Forms.TextBox();
            this.txt_CustomerName = new System.Windows.Forms.TextBox();
            this.txt_Customerid = new System.Windows.Forms.TextBox();
            this.btn_Add = new System.Windows.Forms.Button();
            this.btn_Find = new System.Windows.Forms.Button();
            this.btn_update = new System.Windows.Forms.Button();
            this.btn_delete = new System.Windows.Forms.Button();
            this.btn_Reset = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_customerID
            // 
            this.lbl_customerID.AutoSize = true;
            this.lbl_customerID.Location = new System.Drawing.Point(100, 38);
            this.lbl_customerID.Name = "lbl_customerID";
            this.lbl_customerID.Size = new System.Drawing.Size(89, 17);
            this.lbl_customerID.TabIndex = 0;
            this.lbl_customerID.Text = "Customer ID:";
            // 
            // lbl_Customername
            // 
            this.lbl_Customername.AutoSize = true;
            this.lbl_Customername.Location = new System.Drawing.Point(100, 85);
            this.lbl_Customername.Name = "lbl_Customername";
            this.lbl_Customername.Size = new System.Drawing.Size(113, 17);
            this.lbl_Customername.TabIndex = 1;
            this.lbl_Customername.Text = "Customer Name:";
            // 
            // lbl_CustomerCity
            // 
            this.lbl_CustomerCity.AutoSize = true;
            this.lbl_CustomerCity.Location = new System.Drawing.Point(100, 149);
            this.lbl_CustomerCity.Name = "lbl_CustomerCity";
            this.lbl_CustomerCity.Size = new System.Drawing.Size(99, 17);
            this.lbl_CustomerCity.TabIndex = 2;
            this.lbl_CustomerCity.Text = "Customer City:";
            // 
            // lbl_Customeraddress
            // 
            this.lbl_Customeraddress.AutoSize = true;
            this.lbl_Customeraddress.Location = new System.Drawing.Point(100, 206);
            this.lbl_Customeraddress.Name = "lbl_Customeraddress";
            this.lbl_Customeraddress.Size = new System.Drawing.Size(128, 17);
            this.lbl_Customeraddress.TabIndex = 3;
            this.lbl_Customeraddress.Text = "Customer Address:";
            // 
            // lbl_CustomerMOb
            // 
            this.lbl_CustomerMOb.AutoSize = true;
            this.lbl_CustomerMOb.Location = new System.Drawing.Point(100, 261);
            this.lbl_CustomerMOb.Name = "lbl_CustomerMOb";
            this.lbl_CustomerMOb.Size = new System.Drawing.Size(107, 17);
            this.lbl_CustomerMOb.TabIndex = 4;
            this.lbl_CustomerMOb.Text = "Customer MOB:";
            // 
            // lbl_CustomerEmailId
            // 
            this.lbl_CustomerEmailId.AutoSize = true;
            this.lbl_CustomerEmailId.Location = new System.Drawing.Point(100, 327);
            this.lbl_CustomerEmailId.Name = "lbl_CustomerEmailId";
            this.lbl_CustomerEmailId.Size = new System.Drawing.Size(123, 17);
            this.lbl_CustomerEmailId.TabIndex = 5;
            this.lbl_CustomerEmailId.Text = "Customer EmailID:";
            // 
            // lbl_CustomerPassword
            // 
            this.lbl_CustomerPassword.AutoSize = true;
            this.lbl_CustomerPassword.Location = new System.Drawing.Point(100, 381);
            this.lbl_CustomerPassword.Name = "lbl_CustomerPassword";
            this.lbl_CustomerPassword.Size = new System.Drawing.Size(130, 17);
            this.lbl_CustomerPassword.TabIndex = 6;
            this.lbl_CustomerPassword.Text = "Customer Pasword:";
            // 
            // txt_CustomerPassword
            // 
            this.txt_CustomerPassword.Location = new System.Drawing.Point(269, 376);
            this.txt_CustomerPassword.Name = "txt_CustomerPassword";
            this.txt_CustomerPassword.Size = new System.Drawing.Size(100, 22);
            this.txt_CustomerPassword.TabIndex = 7;
            // 
            // txt_CustomerEmailID
            // 
            this.txt_CustomerEmailID.Location = new System.Drawing.Point(269, 322);
            this.txt_CustomerEmailID.Name = "txt_CustomerEmailID";
            this.txt_CustomerEmailID.Size = new System.Drawing.Size(100, 22);
            this.txt_CustomerEmailID.TabIndex = 8;
            // 
            // txt_CustomerMOB
            // 
            this.txt_CustomerMOB.Location = new System.Drawing.Point(269, 256);
            this.txt_CustomerMOB.Name = "txt_CustomerMOB";
            this.txt_CustomerMOB.Size = new System.Drawing.Size(100, 22);
            this.txt_CustomerMOB.TabIndex = 9;
            // 
            // txt_CustomerAddress
            // 
            this.txt_CustomerAddress.Location = new System.Drawing.Point(269, 201);
            this.txt_CustomerAddress.Name = "txt_CustomerAddress";
            this.txt_CustomerAddress.Size = new System.Drawing.Size(100, 22);
            this.txt_CustomerAddress.TabIndex = 10;
            // 
            // txt_CustomerCity
            // 
            this.txt_CustomerCity.Location = new System.Drawing.Point(269, 144);
            this.txt_CustomerCity.Name = "txt_CustomerCity";
            this.txt_CustomerCity.Size = new System.Drawing.Size(100, 22);
            this.txt_CustomerCity.TabIndex = 11;
            // 
            // txt_CustomerName
            // 
            this.txt_CustomerName.Location = new System.Drawing.Point(269, 80);
            this.txt_CustomerName.Name = "txt_CustomerName";
            this.txt_CustomerName.Size = new System.Drawing.Size(100, 22);
            this.txt_CustomerName.TabIndex = 12;
            // 
            // txt_Customerid
            // 
            this.txt_Customerid.Location = new System.Drawing.Point(269, 35);
            this.txt_Customerid.Name = "txt_Customerid";
            this.txt_Customerid.Size = new System.Drawing.Size(100, 22);
            this.txt_Customerid.TabIndex = 13;
            // 
            // btn_Add
            // 
            this.btn_Add.Location = new System.Drawing.Point(526, 38);
            this.btn_Add.Name = "btn_Add";
            this.btn_Add.Size = new System.Drawing.Size(75, 37);
            this.btn_Add.TabIndex = 14;
            this.btn_Add.Text = "Add";
            this.btn_Add.UseVisualStyleBackColor = true;
            this.btn_Add.Click += new System.EventHandler(this.btn_Add_Click);
            // 
            // btn_Find
            // 
            this.btn_Find.Location = new System.Drawing.Point(526, 115);
            this.btn_Find.Name = "btn_Find";
            this.btn_Find.Size = new System.Drawing.Size(75, 31);
            this.btn_Find.TabIndex = 15;
            this.btn_Find.Text = "FIND";
            this.btn_Find.UseVisualStyleBackColor = true;
            this.btn_Find.Click += new System.EventHandler(this.btn_Find_Click);
            // 
            // btn_update
            // 
            this.btn_update.Location = new System.Drawing.Point(526, 189);
            this.btn_update.Name = "btn_update";
            this.btn_update.Size = new System.Drawing.Size(75, 34);
            this.btn_update.TabIndex = 16;
            this.btn_update.Text = "Update";
            this.btn_update.UseVisualStyleBackColor = true;
            this.btn_update.Click += new System.EventHandler(this.btn_update_Click);
            // 
            // btn_delete
            // 
            this.btn_delete.Location = new System.Drawing.Point(526, 261);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(75, 32);
            this.btn_delete.TabIndex = 17;
            this.btn_delete.Text = "Delete";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // btn_Reset
            // 
            this.btn_Reset.Location = new System.Drawing.Point(526, 342);
            this.btn_Reset.Name = "btn_Reset";
            this.btn_Reset.Size = new System.Drawing.Size(75, 34);
            this.btn_Reset.TabIndex = 19;
            this.btn_Reset.Text = "Reset";
            this.btn_Reset.UseVisualStyleBackColor = true;
            this.btn_Reset.Click += new System.EventHandler(this.btn_Reset_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(940, 496);
            this.Controls.Add(this.btn_Reset);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btn_update);
            this.Controls.Add(this.btn_Find);
            this.Controls.Add(this.btn_Add);
            this.Controls.Add(this.txt_Customerid);
            this.Controls.Add(this.txt_CustomerName);
            this.Controls.Add(this.txt_CustomerCity);
            this.Controls.Add(this.txt_CustomerAddress);
            this.Controls.Add(this.txt_CustomerMOB);
            this.Controls.Add(this.txt_CustomerEmailID);
            this.Controls.Add(this.txt_CustomerPassword);
            this.Controls.Add(this.lbl_CustomerPassword);
            this.Controls.Add(this.lbl_CustomerEmailId);
            this.Controls.Add(this.lbl_CustomerMOb);
            this.Controls.Add(this.lbl_Customeraddress);
            this.Controls.Add(this.lbl_CustomerCity);
            this.Controls.Add(this.lbl_Customername);
            this.Controls.Add(this.lbl_customerID);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_customerID;
        private System.Windows.Forms.Label lbl_Customername;
        private System.Windows.Forms.Label lbl_CustomerCity;
        private System.Windows.Forms.Label lbl_Customeraddress;
        private System.Windows.Forms.Label lbl_CustomerMOb;
        private System.Windows.Forms.Label lbl_CustomerEmailId;
        private System.Windows.Forms.Label lbl_CustomerPassword;
        private System.Windows.Forms.TextBox txt_CustomerPassword;
        private System.Windows.Forms.TextBox txt_CustomerEmailID;
        private System.Windows.Forms.TextBox txt_CustomerMOB;
        private System.Windows.Forms.TextBox txt_CustomerAddress;
        private System.Windows.Forms.TextBox txt_CustomerCity;
        private System.Windows.Forms.TextBox txt_CustomerName;
        private System.Windows.Forms.TextBox txt_Customerid;
        private System.Windows.Forms.Button btn_Add;
        private System.Windows.Forms.Button btn_Find;
        private System.Windows.Forms.Button btn_update;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.Button btn_Reset;
    }
}

