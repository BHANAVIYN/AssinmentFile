﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Windows.Assinment_Customers
{
    public partial class Form_Login : Form
    {
        public Form_Login()
        {
            InitializeComponent();
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            int ID = Convert.ToInt32(txt_login.Text);
            string password = txt_Password.Text;


            DAL_Customers dal = new DAL_Customers();
            bool status = dal.login(ID, password);
            if (status)
            {
                MessageBox.Show("valid User");
            }
            else
            {
                MessageBox.Show("Invalid User");
            }
        }

        private void btn_Logininjection_Click(object sender, EventArgs e)
        {
            string id = txt_login.Text;
            string password = txt_Password.Text;

            DAL_Customers dal = new DAL_Customers();
            bool status = dal.logininjection(id, password);
            if (status)
            {
                MessageBox.Show("Valid User ");

            }
            else
            {
                MessageBox.Show("Invalid User");
            }

        }
    }
}
