﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_day4_generic_employee
{
    class Company
    {
        public void onleave(int ID,string Reason)
        {
            Console.WriteLine("Company : employee  on leavae :" + ID + ", " + Reason);
        }
        private string CmpName;
        private string CmpAddress;

        public Company(string CmpName, string CmpAddress)
        {
            this.CmpName = CmpName;
            this.CmpAddress = CmpAddress;

        }

        private List<Employee> Employeelist = new List<Employee>();

        public void AddEmployee(Employee Em)
        {
            Em.eventleave += new Employee.delleavee(this.onleave);
            Employeelist.Add(Em);
        }

        public Employee Search(int ID)
        {
            foreach (Employee E in Employeelist)
            {
                if (E.PEmpID == ID)
                {
                    return E;

                }
            }
            return null;
            
        }
        public bool Remove(int ID)
        {
            foreach (Employee E in Employeelist)
            {
                if (E.PEmpID == ID)
                {
                    Employeelist.Remove(E);

                    return true;
                }
                
            }
            return false;
        }
        public void ShowAll()
        {
            foreach (Employee E in Employeelist)
            {
                Console.WriteLine(E.PEmpID + " " + E.PEmpName + " " + E.PEmpCity);
            }
        }
   }

}           
                 
