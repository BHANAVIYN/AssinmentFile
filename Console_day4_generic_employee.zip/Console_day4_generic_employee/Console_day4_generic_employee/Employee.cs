﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_day4_generic_employee
{
    class Employee
    {
        public delegate void delleavee(int ID, string Reason);
        public event delleavee eventleave;
        private int EmpID;
        private string EmpName;
        private string EmpCity;
        private static int Count = 1000;

        public Employee(string EmpName, string EmpCity)
        {
            Employee.Count++;
            this.EmpID = Employee.Count;
            this.EmpName = EmpName;
            this.EmpCity = EmpCity;

        }
        public int PEmpID { get { return this.EmpID; } }
        public string PEmpName { get { return this.EmpName; } }
        public string PEmpCity { get { return this.EmpCity; } }

        public void TakeLeave(string Reason)
        {
            if (this.eventleave != null)
            {
                this.eventleave(this.EmpID, Reason);
                Console.WriteLine("Employee On Leave:" + this.EmpID + ",Reason : " + Reason);

            }
        }
    }
}
