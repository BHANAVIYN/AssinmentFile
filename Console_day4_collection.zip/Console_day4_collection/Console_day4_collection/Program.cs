﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace Console_day4_collection
{
    class Program
    {
        static void Main(string[] args)
        {

            ArrayList list = new ArrayList();
            list.Add(1000);
            list.Add(2000);
            list.Add(3000);
            int X=( 4000);
            list.Add(X);
            list.Add("ABC");

            int X1 = Convert.ToInt32(list[0]);
            string S1 = list[4].ToString();
            foreach(int m in list)
            {
                Console.WriteLine(m);
            }

            Console.WriteLine(list.Count);
            list.Remove(1000);
            list.Remove(0);
            Console.ReadLine();
        }
    }
}
