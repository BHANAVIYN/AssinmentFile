select*from tbl_OrderASPS

use Webappli

create proc proc_AddOrder(@Customeremailid varchar(100),@ProductPrice int,@ProductQnt int,@PaymentType varchar(100),
@OrderCity varchar(100),@OrderAddress varchar(100))
as
insert tbl_OrderASPS  values(@Customeremailid,@ProductPrice,@ProductQnt,@PaymentType,@OrderCity,@OrderAddress)
return @@identity