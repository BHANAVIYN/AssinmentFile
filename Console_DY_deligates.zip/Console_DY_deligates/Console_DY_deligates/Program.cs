﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_DY_deligates
{
    class Program
    {
        static void Main(string[] args)
        {

            int x = 100;
            Test obj = new Test(); //we can create object  for  delidate memmory 

            Test.del d = new Test.del(obj.call1);

                d("Hello Deligates"); //singale deligate


            d += new Test.del(obj.call2);//add
            d -= new Test.del(obj.call1);//remove
            d +=new Test.del(obj.call1);
            d += delegate (string s)s
            {
                Console.WriteLine("Anonymous Function :" + s + " " + x);
            };
            d += (s) => Console.WriteLine(s); //lambda expression another way of creating ananymouse

            Console.ReadLine();
        }
    }
}
