﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_day4_Interface_Employee
{
    class Employee
    {
        private int EmpID;
        private string EmpName;
        private string EmpCity;
        private int EmpSal;
        private string EmpAdd;
        private string EmpPrjctD;
        private string EmpExp;
        private int EmpAcctN;
        private string EmpBName;
        private int EmpAge;

        public Employee (int EmpId,string EmpName,  string EmpCity, int EmpSal, string EmpAdd, string EmpPrjctD,string EmpExp, int EmpAcctN,string EmpBName, int EmpAge)

        {
            this.EmpID = EmpID;
            this.EmpName = EmpName;
            this.EmpCity = EmpCity;
            this.EmpSal = EmpSal;
            this.EmpAdd = EmpAdd;
            this.EmpPrjctD = EmpPrjctD;
            this.EmpExp = EmpExp;
            this.EmpAcctN = EmpAcctN;
            this.EmpBName = EmpBName;
            this.EmpAge = EmpAge;
        }




    }
}
