use PathfrontDB2

create table tbl_empL
(
EmpID int primary key,
EmpName varchar(100),
EmpCity varchar(100),
EmpSalary int,
EmpDOB datetime,
EmpDOJ datetime,
EmpMOB varchar(100),
EmpEmID varchar(100),
EmpPaswrd varchar(100),
EmplyDEPt varchar(100)
)

insert tbl_empL values(5,'nhidbjb','jhdwkhriur',7000,'4-25-1994','6-17-2017',9298976667,'kjjgs@mm','h2h7jb8','shhsshgjg')

create table Empl_Av_leaves
(
EmpID int foreign key references tbl_Empl(EmpID),
sickleave varchar(100),
casualleave varchar(100),
vacationleave varchar(100),
compoff varchar(100)
)
select * from Empl_Av_leaves

insert Empl_Av_leaves values(4,'nbhyubh','lajdbvhhxu','iuwdhgyhhi','kwuhguyuy')

create table emp_leaves
(
EmpID int foreign key references tbl_empl(empid),
leavetype varchar(100),
leaveappDate datetime,
leavedate datetime,
noofleaves int
)
select * from emp_leaves
insert emp_leaves values(2,'jhfh','3-26-2018',getdate(),5d)

create table tbl_empysalarys
(
EmpID int foreign key references tbl_empl(empid),
EMPsalary int,
SalaryMonth int,
Salaryyear int,
SalaryDate datetime
)
insert tbl_empysalarys values(3,26668,6,2012,getdate())
select * from tbl_empysalarys

select EmpName from tbl_empL where EmpId in (select empid from tbl_empysalarys where empsalary>2000)

select count(*) empname,sum(empsalary),avg(empsalary)  from tbl_empl group by  empsalary

select tbl_empL.empid,tbl_empl.empname,tbl_empL.EmpSalary,Empl_Av_leaves.sickleave,
Empl_Av_leaves.casualleave,
Empl_Av_leaves.vacationleave,
Empl_Av_leaves.compoff from tbl_empL join Empl_Av_leaves on tbl_empL.EmpID=Empl_Av_leaves.EmpID

select tbl_empL.empid,tbl_empl.empname,tbl_empL.EmpSalary,tbl_empysalarys.SalaryMonth,
tbl_empysalarys.SalaryDate from tbl_empL join tbl_empysalarys on
tbl_empL.EmpID=tbl_empysalarys.EmpID


