select * from tbl_Employees

select * from tbl_customerrs
select * from tbl_Account
select * from tbl_Transaction
--1
create proc sp_add_customers(@name varchar(100),@city varchar(100),@address varchar(100),@mobilenumber varchar(100),@pan varchar(100),@pasword varchar(100))
as
begin
insert tbl_customerrs values (@name,@city,@address,@mobilenumber,@pan,@pasword)
return @@identity
end

--2
create proc sp_aa1_customers(@name varchar(100),@customerid int,@city varchar(100),@address varchar(100),@mobilenumber varchar(100),@pan varchar(100),@pasword varchar(100))
as
update tbl_Custmrs set CustomerName=@name where customerid=@customerid

--3
create proc sp_adre_customer(@name varchar(100),@customerid int,@city varchar(100)
,@address varchar(100),@mobilenumber varchar(100),@pan varchar(100),@pasword varchar(100))
as
update tbl_customerrs set  customermobilenumber=@mobilenumber
 where customerId=@customerid and customerPasword=@pasword

---4
create proc sp_a3_custom(@name varchar(100),@customerid int,@accountid int,@accountbalance int)
as
select tbl_customerrs.customerId,tbl_customerrs.customerName,tbl_Account.AccountId,tbl_Account.AccountBalance
from tbl_customerrs join tbl_Account on tbl_customerrs.customerId=tbl_Account.customerid where tbl_customerrs.customerid=@customerid

---5
create trigger trg_update_tbl
on tbl_transaction
for insert
as
begin 
declare @accountid int;
declare @amount int;
select @accountid=accountid,@amount=amount from inserted
update tbl_Account set amountbalance=amountbalance-@amount where accountid= @accountid
end
select * from tbl_Transaction
--6
create view v_cust_accnt
as
select tbl_customerrs.customerId,tbl_customerrs.customerName,tbl_Account.AccountId,tbl_Account.AccountBalance from tbl_customerrs
join tbl_Account on tbl_customerrs.customerId=tbl_Account.customerid

--7

select * from tbl_Account

select * from tbl_orders

5. Create a Trigger for updating the account balance in the account table as per the transaction (withdraw / deposit) in the transation table.

6. Create a view for displaying CustomerID , CustomerName , AccountID , AccountBalance
7. Create a procedure named LoginCheck , the procedure should take two parameters and return 0 or 1.