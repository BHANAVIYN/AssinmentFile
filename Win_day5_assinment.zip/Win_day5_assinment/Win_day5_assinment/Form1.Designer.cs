﻿namespace Win_day5_assinment
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_Order = new System.Windows.Forms.Label();
            this.txt_Order = new System.Windows.Forms.TextBox();
            this.lbl_Item = new System.Windows.Forms.Label();
            this.txt_ItemId = new System.Windows.Forms.TextBox();
            this.lbl_CsmName = new System.Windows.Forms.Label();
            this.txt_CstmName = new System.Windows.Forms.TextBox();
            this.lbl_Itemqnty = new System.Windows.Forms.Label();
            this.txt_ItemQntny = new System.Windows.Forms.TextBox();
            this.lbl_DelvryAdds = new System.Windows.Forms.Label();
            this.txt_Addrs = new System.Windows.Forms.TextBox();
            this.lbl_payment = new System.Windows.Forms.Label();
            this.rdb_Cash = new System.Windows.Forms.RadioButton();
            this.rdb_Card = new System.Windows.Forms.RadioButton();
            this.rdb_Netbnkn = new System.Windows.Forms.RadioButton();
            this.cmb_cities = new System.Windows.Forms.ComboBox();
            this.lbl_cities = new System.Windows.Forms.Label();
            this.lbl_Price = new System.Windows.Forms.Label();
            this.txt_Price = new System.Windows.Forms.TextBox();
            this.btn_Order = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_Order
            // 
            this.lbl_Order.AutoSize = true;
            this.lbl_Order.Location = new System.Drawing.Point(68, 83);
            this.lbl_Order.Name = "lbl_Order";
            this.lbl_Order.Size = new System.Drawing.Size(66, 17);
            this.lbl_Order.TabIndex = 0;
            this.lbl_Order.Text = "Order ID:";
            // 
            // txt_Order
            // 
            this.txt_Order.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Order.Location = new System.Drawing.Point(140, 70);
            this.txt_Order.Name = "txt_Order";
            this.txt_Order.Size = new System.Drawing.Size(134, 30);
            this.txt_Order.TabIndex = 1;
            // 
            // lbl_Item
            // 
            this.lbl_Item.AutoSize = true;
            this.lbl_Item.Location = new System.Drawing.Point(79, 115);
            this.lbl_Item.Name = "lbl_Item";
            this.lbl_Item.Size = new System.Drawing.Size(55, 17);
            this.lbl_Item.TabIndex = 2;
            this.lbl_Item.Text = "Item ID:";
            // 
            // txt_ItemId
            // 
            this.txt_ItemId.Location = new System.Drawing.Point(140, 115);
            this.txt_ItemId.Name = "txt_ItemId";
            this.txt_ItemId.Size = new System.Drawing.Size(134, 22);
            this.txt_ItemId.TabIndex = 4;
            // 
            // lbl_CsmName
            // 
            this.lbl_CsmName.AutoSize = true;
            this.lbl_CsmName.Location = new System.Drawing.Point(79, 46);
            this.lbl_CsmName.Name = "lbl_CsmName";
            this.lbl_CsmName.Size = new System.Drawing.Size(49, 17);
            this.lbl_CsmName.TabIndex = 5;
            this.lbl_CsmName.Text = "Name:";
            // 
            // txt_CstmName
            // 
            this.txt_CstmName.Location = new System.Drawing.Point(140, 42);
            this.txt_CstmName.Name = "txt_CstmName";
            this.txt_CstmName.Size = new System.Drawing.Size(134, 22);
            this.txt_CstmName.TabIndex = 6;
            // 
            // lbl_Itemqnty
            // 
            this.lbl_Itemqnty.AutoSize = true;
            this.lbl_Itemqnty.Location = new System.Drawing.Point(49, 165);
            this.lbl_Itemqnty.Name = "lbl_Itemqnty";
            this.lbl_Itemqnty.Size = new System.Drawing.Size(79, 17);
            this.lbl_Itemqnty.TabIndex = 7;
            this.lbl_Itemqnty.Text = "Item Qntity:";
            // 
            // txt_ItemQntny
            // 
            this.txt_ItemQntny.Location = new System.Drawing.Point(140, 165);
            this.txt_ItemQntny.Name = "txt_ItemQntny";
            this.txt_ItemQntny.Size = new System.Drawing.Size(134, 22);
            this.txt_ItemQntny.TabIndex = 8;
            // 
            // lbl_DelvryAdds
            // 
            this.lbl_DelvryAdds.AutoSize = true;
            this.lbl_DelvryAdds.Location = new System.Drawing.Point(64, 264);
            this.lbl_DelvryAdds.Name = "lbl_DelvryAdds";
            this.lbl_DelvryAdds.Size = new System.Drawing.Size(64, 17);
            this.lbl_DelvryAdds.TabIndex = 9;
            this.lbl_DelvryAdds.Text = "Address:";
            // 
            // txt_Addrs
            // 
            this.txt_Addrs.Location = new System.Drawing.Point(140, 264);
            this.txt_Addrs.Name = "txt_Addrs";
            this.txt_Addrs.Size = new System.Drawing.Size(134, 22);
            this.txt_Addrs.TabIndex = 10;
            // 
            // lbl_payment
            // 
            this.lbl_payment.AutoSize = true;
            this.lbl_payment.Location = new System.Drawing.Point(31, 312);
            this.lbl_payment.Name = "lbl_payment";
            this.lbl_payment.Size = new System.Drawing.Size(103, 17);
            this.lbl_payment.TabIndex = 11;
            this.lbl_payment.Text = "Payment Type:";
            // 
            // rdb_Cash
            // 
            this.rdb_Cash.AutoSize = true;
            this.rdb_Cash.Location = new System.Drawing.Point(156, 312);
            this.rdb_Cash.Name = "rdb_Cash";
            this.rdb_Cash.Size = new System.Drawing.Size(61, 21);
            this.rdb_Cash.TabIndex = 12;
            this.rdb_Cash.TabStop = true;
            this.rdb_Cash.Text = "Cash";
            this.rdb_Cash.UseVisualStyleBackColor = true;
            // 
            // rdb_Card
            // 
            this.rdb_Card.AutoSize = true;
            this.rdb_Card.Location = new System.Drawing.Point(156, 339);
            this.rdb_Card.Name = "rdb_Card";
            this.rdb_Card.Size = new System.Drawing.Size(59, 21);
            this.rdb_Card.TabIndex = 13;
            this.rdb_Card.TabStop = true;
            this.rdb_Card.Text = "Card";
            this.rdb_Card.UseVisualStyleBackColor = true;
            // 
            // rdb_Netbnkn
            // 
            this.rdb_Netbnkn.AutoSize = true;
            this.rdb_Netbnkn.Location = new System.Drawing.Point(156, 375);
            this.rdb_Netbnkn.Name = "rdb_Netbnkn";
            this.rdb_Netbnkn.Size = new System.Drawing.Size(106, 21);
            this.rdb_Netbnkn.TabIndex = 14;
            this.rdb_Netbnkn.TabStop = true;
            this.rdb_Netbnkn.Text = "Net Banking";
            this.rdb_Netbnkn.UseVisualStyleBackColor = true;
            // 
            // cmb_cities
            // 
            this.cmb_cities.FormattingEnabled = true;
            this.cmb_cities.Location = new System.Drawing.Point(450, 49);
            this.cmb_cities.Name = "cmb_cities";
            this.cmb_cities.Size = new System.Drawing.Size(210, 24);
            this.cmb_cities.TabIndex = 15;
         //   this.cmb_cities.SelectedIndexChanged += new System.EventHandler(this.cmb_cities_SelectedIndexChanged);
            // 
            // lbl_cities
            // 
            this.lbl_cities.AutoSize = true;
            this.lbl_cities.Location = new System.Drawing.Point(398, 49);
            this.lbl_cities.Name = "lbl_cities";
            this.lbl_cities.Size = new System.Drawing.Size(46, 17);
            this.lbl_cities.TabIndex = 16;
            this.lbl_cities.Text = "Cities:";
            // 
            // lbl_Price
            // 
            this.lbl_Price.AutoSize = true;
            this.lbl_Price.Location = new System.Drawing.Point(68, 222);
            this.lbl_Price.Name = "lbl_Price";
            this.lbl_Price.Size = new System.Drawing.Size(44, 17);
            this.lbl_Price.TabIndex = 19;
            this.lbl_Price.Text = "Price:";
            // 
            // txt_Price
            // 
            this.txt_Price.Location = new System.Drawing.Point(140, 219);
            this.txt_Price.Name = "txt_Price";
            this.txt_Price.Size = new System.Drawing.Size(134, 22);
            this.txt_Price.TabIndex = 20;
            // 
            // btn_Order
            // 
            this.btn_Order.Location = new System.Drawing.Point(450, 136);
            this.btn_Order.Name = "btn_Order";
            this.btn_Order.Size = new System.Drawing.Size(75, 23);
            this.btn_Order.TabIndex = 21;
            this.btn_Order.Text = "Order";
            this.btn_Order.UseVisualStyleBackColor = true;
            this.btn_Order.Click += new System.EventHandler(this.btn_Order_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(808, 440);
            this.Controls.Add(this.btn_Order);
            this.Controls.Add(this.txt_Price);
            this.Controls.Add(this.lbl_Price);
            this.Controls.Add(this.lbl_cities);
            this.Controls.Add(this.cmb_cities);
            this.Controls.Add(this.rdb_Netbnkn);
            this.Controls.Add(this.rdb_Card);
            this.Controls.Add(this.rdb_Cash);
            this.Controls.Add(this.lbl_payment);
            this.Controls.Add(this.txt_Addrs);
            this.Controls.Add(this.lbl_DelvryAdds);
            this.Controls.Add(this.txt_ItemQntny);
            this.Controls.Add(this.lbl_Itemqnty);
            this.Controls.Add(this.txt_CstmName);
            this.Controls.Add(this.lbl_CsmName);
            this.Controls.Add(this.txt_ItemId);
            this.Controls.Add(this.lbl_Item);
            this.Controls.Add(this.txt_Order);
            this.Controls.Add(this.lbl_Order);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_Order;
        private System.Windows.Forms.TextBox txt_Order;
        private System.Windows.Forms.Label lbl_Item;
        private System.Windows.Forms.TextBox txt_ItemId;
        private System.Windows.Forms.Label lbl_CsmName;
        private System.Windows.Forms.TextBox txt_CstmName;
        private System.Windows.Forms.Label lbl_Itemqnty;
        private System.Windows.Forms.TextBox txt_ItemQntny;
        private System.Windows.Forms.Label lbl_DelvryAdds;
        private System.Windows.Forms.TextBox txt_Addrs;
        private System.Windows.Forms.Label lbl_payment;
        private System.Windows.Forms.RadioButton rdb_Cash;
        private System.Windows.Forms.RadioButton rdb_Card;
        private System.Windows.Forms.RadioButton rdb_Netbnkn;
        private System.Windows.Forms.ComboBox cmb_cities;
        private System.Windows.Forms.Label lbl_cities;
        private System.Windows.Forms.Label lbl_Price;
        private System.Windows.Forms.TextBox txt_Price;
        private System.Windows.Forms.Button btn_Order;
    }
}

