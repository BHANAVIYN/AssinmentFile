﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_day5_assinment
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_Order_Click(object sender, EventArgs e)
        {
            if (txt_Order.Text == string.Empty)
            {
                MessageBox.Show("Select Order");

            }

            else if (txt_CstmName.Text == string.Empty)
            {
                MessageBox.Show("Select Valid Name");

            }
            else if (txt_ItemId.Text == string.Empty)
            {
                MessageBox.Show("Slect Valid ID");
            }
            else if (txt_Price.Text == string.Empty)
            {
                MessageBox.Show("Enter the Price");
            }

            else if (txt_Addrs.Text == string.Empty)
            {
                MessageBox.Show("Enter The Valid Address");
            }
            else if (lbl_payment.Text == string.Empty)
            {
                MessageBox.Show("Enter The Payment Method");
            }
            else if (cmb_cities.Text == string.Empty)
            {
                MessageBox.Show("Enter the citie Name");
            }
            else
            {
                if (rdb_Cash.Checked == false && rdb_Card.Checked == false && rdb_Netbnkn.Checked == false)
                {
                    MessageBox.Show("Select Your Payment Type");
                }
                else
                {
                    string Payment = string.Empty;
                    if (rdb_Card.Checked)
                    {
                        Payment = "Cash";
                    }
                    else if (rdb_Card.Checked)
                    {
                        Payment = "Card";
                    }
                    else
                    {
                        Payment = "Net Banking";
                    }

                    string Name = txt_CstmName.Text;
                    int Order = Convert.ToInt32(txt_Order.Text);
                    int ItemId = Convert.ToInt32(txt_ItemId.Text);
                    int ItemQnt = Convert.ToInt32(txt_ItemQntny.Text);
                    int Price = Convert.ToInt32(txt_Price.Text);
                    string Adress = txt_Addrs.Text;
                    string cities = cmb_cities.Text;

                    Order obj = new Order(Name, Order, ItemQnt, Price, Adress, Payment, cities);
                    MessageBox.Show(obj.getOrderValue().ToString());


                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cmb_cities.Items.Add("Pune");
            cmb_cities.Items.Add("chennai");
            cmb_cities.Items.Add("Hyd");
            cmb_cities.Items.Add("banglore");


        }
    }
}

       

