create database BankingApplication

use BankingApplication


create table tbl_Customers
(
CustomerID int identity(1,1) primary key,
CustomerName varchar(100),
CustomerEmail varchar(100),
CustomerMOB varchar(100),
CustomerGender varchar(50),
CustomerPassword varchar(100)
)

select * from tbl_Customers
create  table tbl_Account
(
AccountID int identity(100,1) primary key,
CustomerID int foreign key references tbl_Customers(CustomerID),
AccountBalance int,
AccountType varchar(100),
AccountOpeningDate Datetime,
)

select *from tbl_Account

create table tbl_Transaction
(
TransID int identity(1000,1) primary key,
AccountID int foreign key references tbl_Account(AccountID),
Amount int,
TransType varchar(100),
TransDate Datetime,
)

create proc proc_addCustomer(@Name varchar(100),
@Email varchar(100),@MOB varchar(100),@Gender varchar(100),@Password varchar(100))
as
insert tbl_Customers values(@Name,@Email,@MOB,@Gender,@Password)
return @@identity
--2
create proc proc_Customerdetail(@CID int)
as
select * from tbl_Customers where CustomerID=@CID
--3
create proc proc_showCustomer(@EmailID varchar(100))
as
select * from tbl_Customers where CustomerEmail=@EmailID
--4
alter proc proc_AddAccount(@CID int ,@AcntBalance int,@AcntType varchar(100))
as
insert tbl_Account values(@CID,@AcntBalance,@AcntType,getdate())
return @@identity

--5
create proc proc_ShowAccount(@CID int)
as
select * from tbl_Account where CustomerID=@CID

--6
alter proc proc_AddTransationse(@AcntID int,@Amount int,@TranType varchar(100))
as
insert tbl_Transaction values(@AcntID,@Amount,@TranType,getdate())
return @@identity
--7
create proc proc_ShowTrans(@AcntID int)
as
select * from tbl_Transaction where AccountID=@AcntID
--8
create proc proc_login(@CID int,@password varchar(100))
as
declare @count int
select @count=count(*) from tbl_Customers where
CustomerID=@CID and CustomerPassword=@password
return @count


create trigger trg_update_tbl
on tbl_transaction
for insert
as
begin 
declare @AcntID int;
declare @amount int;
select @AcntID=AccountID,@Amount=Amount from inserted
update tbl_Account set AccountBalance=AccountBalance-@Amount where AccountID=@AcntID
end
select * from tbl_Transaction


 

