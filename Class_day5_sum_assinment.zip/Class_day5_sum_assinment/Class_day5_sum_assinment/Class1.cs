﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Class_day5_sum_assinment
{
    public class Calculator
    {
        public int GetSum(int Number1, int Number2)
        {
            return Number1 + Number2;


        }
        public int GetMultiply(int Number1,int Number2)
        {
            return Number1 * Number2;
        }
        public int GetSubstraction(int Number1,int Number2)
        {
            return Number1 - Number2;
        }
        public int GetDivide ( int Number1,int Number2)
        {
            return Number1 / Number2;
        }
    }
}
