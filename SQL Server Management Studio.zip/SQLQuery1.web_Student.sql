Create database StudentID

use StudentID

create table tbl_Students
(

StudentID int identity(1,1) primary key,
StudentName varchar(100) not null,
StudentCity varchar(100) not null,
StudentImageAddress varchar(1000) not null
)


create proc proc_addSudent(@name varchar(100),@city varchar(100),@address varchar(1000))
as
insert tbl_Students values(@name,@city,@address)
return @@identity


create proc pro_SearchStudent(@key varchar(1000))
as
select * from tbl_Students where StudentID like '%'+@key+'%'
or StudentName like '%'+@key+'%'
or StudentCity like '%'+@key+'%'


create proc proc_details(@id int)
as
select * from tbl_Students where StudentID=@id

create table tbl_liberary
(
BookID int identity(1000,1) primary key,
BookName varchar(100) not null,
AuthorName varchar(100)not null,
BookImage varchar(1000) not null
)
drop table tbl_liberary

drop table tbl_liberarys


create proc proc_Addbook(@Bname varchar(100),@Aname varchar(100),@Image varchar(1000))
as
insert tbl_liberary values(@Bname,@Aname,@Image)
return @@identity

create proc pro_SearchBooks(@key varchar(1000))
as
select * from tbl_liberary  where BookID like '%'+@key+'%'
or BookName like '%'+@key+'%'

