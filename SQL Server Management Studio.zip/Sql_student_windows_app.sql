use DAL

create table Student
(
StudentID int identity(100,1) primary key,
StudentName varchar(100),
StudentCity varchar(100),
StudentAddress varchar(100),
StudentEmailID varchar(100)
)
create proc proc_addStudent(@name varchar(100),
@city varchar(100),@pasword varchar(100))
as
insert Student values(@name,@city,@pasword,getdate())
return @@identity
--2
create proc proc_Studentdetail(@id int)
as
select * from Student where StudentID=@id
--3
create proc proc_showStudent(@city varchar(100))
as
select * from Student where StudentCity=@city
--4
create proc proc_searcStudent(@key varchar(100))
as
select * from Student
where StudentID like '%'+@key+'%' or StudentName like '%'+@key+'%'
or StudentCity like '%'+@key+'%';

--5
create proc proc_updateStudent(@id int,@city varchar(100),@EmailID varchar(100))
as
update Student set StudentAddress=@city,StudentEmailID=@EmailID
where StudentID=@id
return @@rowcount

--6
create proc proc_deleteStudent(@id int)
as
delete Student where StudentID=@id
return @@rowcount
--7
create proc proce_login(@id int,@EmailID varchar(100))
as
declare @count int
select @count=count(*) from Student where
StudentID=@id and StudentEmailID=@EmailID
return @count


select * from tbl_employees