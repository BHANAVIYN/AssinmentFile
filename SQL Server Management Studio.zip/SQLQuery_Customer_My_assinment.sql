use StudentID

create table tbl_Customers
(
CustomerID int identity(1,1) primary key,
CustomerName varchar(100),
CustomerCity varchar(100),
CustomerMobileNO varchar(100),
CustomerEmail varchar(100)
)