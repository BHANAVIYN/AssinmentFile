use PathfrontDB2

create table tbl_Restaurentss
(
RestID int identity(1,1) primary key,
RestName varchar(100),
RestAddress varchar(100),
RestCity varchar(100),
RestCntct varchar(100)
)
select * from tbl_Restaurentss

insert tbl_Restaurentss values('restjhsdfjyudf','mshdtfuusfy','Arsikere',9866586757)

create table tbl_RMenuItems
(
MenuID int identity(100,1) primary key,
RestID int foreign key references tbl_Restaurentss(RestID),
MenuName varchar(100),
MenuType varchar(100),
MenuCatagory varchar(100),
MenuPrice int check(MenuPrice>0),
MenuDesc varchar(100)
)
select * from tbl_RMenuItems
insert tbl_RMenuItems values(1,'maefeecgssefd','veg','northandsouthindia',30000,'akjdch45jhhff')



create table tbl_Custmrs
(
CustomerID varchar(100) primary key,
CustomerName varchar(100),
CustomerCity varchar(100),
CustomerDOB DateTime,
CustomerGender varchar(100),
CustPasswrd varchar(100)
)
select  * from tbl_Custmrs
insert tbl_Custmrs values('zushiasava@gmail.com','bhoovan','hyd','6-22-1996','male','jsdbanfmdnmnfh')

create table tbl_Orders
(
OrderID int identity(1000,1) primary key,
CustomerID varchar(100) foreign key references tbl_Custmrs(CustomerID),
Orderdate DateTime,
DeliveryAddress varchar(100),
OrderStatus varchar(100)
)

select * from tbl_Orders
insert tbl_Orders values('zushiasava@gmail.com',getdate(),'shjfg','pending')
insert tbl_Orders values('bhanjsa@gmail.com','2-4-2017','jwdgvdhd','deliverd')
insert tbl_Orders values('seersa@gmail.com',getdate(),'kajedfg','one hr left')
insert tbl_orders values('bhanjsa@gmail.com','3-22-2018','kejwdfh','deliverd')
insert tbl_Orders values('shasa@gmail.com',getdate(),'jafgifg','pending')


create table tbl_OrderMenus
(
OrderID int foreign key references tbl_Orders(OrderID),
MenuID int foreign key references tbl_RMenuItems(MenuID),
MenuQty varchar(100),
MenuPrice int check(MenuPrice>0) primary key (OrderId,MenuID)
)
insert tbl_OrderMenus values(1010,110,9,4000)

select *from tbl_OrderMenu

select RestCity from tbl_Restaurentss

select  tbl_Restaurentss.RestID,tbl_Restaurentss.RestName,tbl_RMenuItems.MenuID,tbl_RMenuItems.MenuPrice,tbl_RMenuItems.MenuName
from tbl_Restaurentss  full outer join tbl_RMenuItems on tbl_Restaurentss.RestID=tbl_RMenuItems.RestID

select  tbl_Restaurentss.RestID,tbl_Restaurentss.RestName,tbl_RMenuItems.MenuID,tbl_RMenuItems.MenuPrice,tbl_RMenuItems.MenuName
from tbl_Restaurentss  join tbl_RMenuItems on tbl_Restaurentss.RestID=tbl_RMenuItems.RestID

select orderid from tbl_Orders where customerid=  in(select customerid from tbl_Custmrs)

select tbl_Orders.OrderID,tbl_Orders.CustomerID,tbl_Orders.Orderdate,tbl_OrderMenus.MenuID,tbl_OrderMenus.MenuPrice  from
tbl_Orders join tbl_OrderMenus on tbl_Orders.OrderID=tbl_OrderMenus.OrderID

select top 5 * from tbl_Orders where customerid in (select customerid from tbl_Custmrs) order by Orderdate desc 
 
select MenuPrice from tbl_OrderMenus order by MenuPrice asc

select RestCity ,count(*) RestCount from tbl_Restaurentss
group by RestCity


select CustomerName from tbl_Custmrs where customerid not in(select customerid from tbl_Orders)

select  top 1 *  from tbl_RMenuItems   order by MenuPrice desc

select top 1* from tbl_RMenuItems   where MenuID in (select top 2 menuid from tbl_RMenuItems order by MenuPrice desc) order by MenuPrice asc



create table tbl_RMenuItems
(
MenuID int identity(100,1) primary key,
RestID int foreign key references tbl_Restaurentss(RestID),
MenuName varchar(100),
MenuType varchar(100),
MenuCatagory varchar(100),
MenuPrice int check(MenuPrice>0),
MenuDesc varchar(100)
)