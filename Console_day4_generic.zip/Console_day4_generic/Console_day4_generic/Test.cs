﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_day4_generic
{
    class Test
    { 
        public T GetDetails <T>(T Para)
    {
        return Para;
    }
    }
}
