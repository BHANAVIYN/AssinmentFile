﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_jaggedarray
{
    class Program
    {
        static void Main(string[] args)
        {
            int[][] jaggedarray= new int[3][];
            jaggedarray[0] = new int[2];
            jaggedarray[1] = new int[3];
            jaggedarray[2] = new int[2];

            jaggedarray[0][0] = 10;
            jaggedarray[0][1] = 20;
            jaggedarray[1][0] = 30;
            jaggedarray[0][0]




        }
    }
}
