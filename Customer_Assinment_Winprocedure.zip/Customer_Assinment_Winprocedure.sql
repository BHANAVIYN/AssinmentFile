select * from tbl_customers
use DAL

create proc proc_addcustomer(@name int,@City varchar(100),@Pasword varchar(100))
as
insert tbl_customers values(@name,@City,@Pasword,getdate())
return @@identity
--2
create proc proc_employeedetail(@id int)
as
select * from tbl_customers where CustomerID=@id
--3
create proc proc_showCustomers(@city varchar(100))
as
select * from tbl_customers where CustomerCity=@City
--4
create proc proc_searchemployee(@key varchar(100))
as
select * from tbl_customers
where CustomerID like '%'+@key+'%' or CustomerName like '%'+@key+'%'
or CustomerCity like '%'+@key+'%';

--5
create proc proc_updateCustomer(@id int,@city varchar(100),@pasword varchar(100))
as
update tbl_customers set CustomerCity=@City,CustomerPassword=@pasword
where CustomerID=@id
return @@rowcount

--6
create proc proc_deleteCustomer(@id int)
as
delete tbl_customers  where CustomerID=@id
return @@rowcount
--7
create proc proc_login(@id int,@pasword varchar(100))
as
declare @count int
select @count=count(*) from tbl_customers where
CustomerID=@id and CustomerPassword=@pasword
return @count

