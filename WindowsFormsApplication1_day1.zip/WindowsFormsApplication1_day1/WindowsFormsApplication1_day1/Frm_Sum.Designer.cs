﻿namespace WindowsFormsApplication1_day1
{
    partial class Frm_Sum
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_Num1 = new System.Windows.Forms.Label();
            this.txt_Number1 = new System.Windows.Forms.TextBox();
            this.lbl_Num2 = new System.Windows.Forms.Label();
            this.txt_Number2 = new System.Windows.Forms.TextBox();
            this.BTN_Sum = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_Num1
            // 
            this.lbl_Num1.AutoSize = true;
            this.lbl_Num1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Num1.Location = new System.Drawing.Point(118, 74);
            this.lbl_Num1.Name = "lbl_Num1";
            this.lbl_Num1.Size = new System.Drawing.Size(124, 29);
            this.lbl_Num1.TabIndex = 0;
            this.lbl_Num1.Text = "Number1:";
          //  this.lbl_Num1.Click += new System.EventHandler(this.label1_Click);
            // 
            // txt_Number1
            // 
            this.txt_Number1.Location = new System.Drawing.Point(248, 74);
            this.txt_Number1.Name = "txt_Number1";
            this.txt_Number1.Size = new System.Drawing.Size(198, 22);
            this.txt_Number1.TabIndex = 1;
           // this.txt_Number1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // lbl_Num2
            // 
            this.lbl_Num2.AutoSize = true;
            this.lbl_Num2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Num2.Location = new System.Drawing.Point(118, 133);
            this.lbl_Num2.Name = "lbl_Num2";
            this.lbl_Num2.Size = new System.Drawing.Size(124, 29);
            this.lbl_Num2.TabIndex = 2;
            this.lbl_Num2.Text = "Number2:";
            // 
            // txt_Number2
            // 
            this.txt_Number2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Number2.Location = new System.Drawing.Point(248, 126);
            this.txt_Number2.Name = "txt_Number2";
            this.txt_Number2.Size = new System.Drawing.Size(198, 36);
            this.txt_Number2.TabIndex = 3;
            // 
            // BTN_Sum
            // 
            this.BTN_Sum.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_Sum.Location = new System.Drawing.Point(167, 233);
            this.BTN_Sum.Name = "BTN_Sum";
            this.BTN_Sum.Size = new System.Drawing.Size(173, 54);
            this.BTN_Sum.TabIndex = 4;
            this.BTN_Sum.Text = "Sum";
            this.BTN_Sum.UseVisualStyleBackColor = true;
            this.BTN_Sum.Click += new System.EventHandler(this.BTN_Sum_Click);
            // 
            // Frm_Sum
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(794, 342);
            this.Controls.Add(this.BTN_Sum);
            this.Controls.Add(this.txt_Number2);
            this.Controls.Add(this.lbl_Num2);
            this.Controls.Add(this.txt_Number1);
            this.Controls.Add(this.lbl_Num1);
            this.Name = "Frm_Sum";
            this.Text = "Frm_Sum";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_Num1;
        private System.Windows.Forms.TextBox txt_Number1;
        private System.Windows.Forms.Label lbl_Num2;
        private System.Windows.Forms.TextBox txt_Number2;
        private System.Windows.Forms.Button BTN_Sum;
    }
}