﻿namespace WindowsFormsApplication1_day1
{
    partial class Frm_Controles
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lst_Cities = new System.Windows.Forms.ListBox();
            this.btn_Save = new System.Windows.Forms.Button();
            this.cmb_cities = new System.Windows.Forms.ComboBox();
            this.chk_readme = new System.Windows.Forms.CheckBox();
            this.rdb_female = new System.Windows.Forms.RadioButton();
            this.rdb_Male = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // lst_Cities
            // 
            this.lst_Cities.FormattingEnabled = true;
            this.lst_Cities.ItemHeight = 16;
            this.lst_Cities.Location = new System.Drawing.Point(134, 153);
            this.lst_Cities.Name = "lst_Cities";
            this.lst_Cities.Size = new System.Drawing.Size(120, 84);
            this.lst_Cities.TabIndex = 0;
            // 
            // btn_Save
            // 
            this.btn_Save.Location = new System.Drawing.Point(351, 114);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(75, 23);
            this.btn_Save.TabIndex = 1;
            this.btn_Save.Text = "Save";
            this.btn_Save.UseVisualStyleBackColor = true;
            this.btn_Save.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // cmb_cities
            // 
            this.cmb_cities.FormattingEnabled = true;
            this.cmb_cities.Location = new System.Drawing.Point(133, 293);
            this.cmb_cities.Name = "cmb_cities";
            this.cmb_cities.Size = new System.Drawing.Size(121, 24);
            this.cmb_cities.TabIndex = 2;
         //   this.cmb_cities.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // chk_readme
            // 
            this.chk_readme.AutoSize = true;
            this.chk_readme.Location = new System.Drawing.Point(338, 178);
            this.chk_readme.Name = "chk_readme";
            this.chk_readme.Size = new System.Drawing.Size(87, 21);
            this.chk_readme.TabIndex = 3;
            this.chk_readme.Text = "Read Me";
            this.chk_readme.UseVisualStyleBackColor = true;
            // 
            // rdb_female
            // 
            this.rdb_female.AutoSize = true;
            this.rdb_female.Location = new System.Drawing.Point(338, 272);
            this.rdb_female.Name = "rdb_female";
            this.rdb_female.Size = new System.Drawing.Size(75, 21);
            this.rdb_female.TabIndex = 4;
            this.rdb_female.TabStop = true;
            this.rdb_female.Text = "Female";
            this.rdb_female.UseVisualStyleBackColor = true;
            // 
            // rdb_Male
            // 
            this.rdb_Male.AutoSize = true;
            this.rdb_Male.Location = new System.Drawing.Point(434, 272);
            this.rdb_Male.Name = "rdb_Male";
            this.rdb_Male.Size = new System.Drawing.Size(59, 21);
            this.rdb_Male.TabIndex = 5;
            this.rdb_Male.TabStop = true;
            this.rdb_Male.Text = "Male";
            this.rdb_Male.UseVisualStyleBackColor = true;
          //  this.rdb_Male.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // Frm_Controles
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(879, 466);
            this.Controls.Add(this.rdb_Male);
            this.Controls.Add(this.rdb_female);
            this.Controls.Add(this.chk_readme);
            this.Controls.Add(this.cmb_cities);
            this.Controls.Add(this.btn_Save);
            this.Controls.Add(this.lst_Cities);
            this.Name = "Frm_Controles";
            this.Text = "Frm_Controles";
            this.Load += new System.EventHandler(this.Frm_Controles_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lst_Cities;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.ComboBox cmb_cities;
        private System.Windows.Forms.CheckBox chk_readme;
        private System.Windows.Forms.RadioButton rdb_female;
        private System.Windows.Forms.RadioButton rdb_Male;
    }
}