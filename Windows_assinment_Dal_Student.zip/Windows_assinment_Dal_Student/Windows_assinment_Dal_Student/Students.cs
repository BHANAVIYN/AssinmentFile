﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Windows_assinment_Dal_Student
{
    class Students
    {
        public int StudentID { get; set; }
        public string StudentName { get; set; }

        public string StudentCity { get; set; }

        public string Studentaddress { get; set; }

        public string StudentEmailID { get; set; }

    }
}

  
