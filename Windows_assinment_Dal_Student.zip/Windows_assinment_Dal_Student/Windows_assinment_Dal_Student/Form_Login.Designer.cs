﻿namespace Windows_assinment_Dal_Student
{
    partial class Form_Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Logininjection = new System.Windows.Forms.Button();
            this.btn_login = new System.Windows.Forms.Button();
            this.txt_login = new System.Windows.Forms.TextBox();
            this.txt_Password = new System.Windows.Forms.TextBox();
            this.lbl_Password = new System.Windows.Forms.Label();
            this.lbl_loginId = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_Logininjection
            // 
            this.btn_Logininjection.Location = new System.Drawing.Point(513, 347);
            this.btn_Logininjection.Name = "btn_Logininjection";
            this.btn_Logininjection.Size = new System.Drawing.Size(238, 35);
            this.btn_Logininjection.TabIndex = 17;
            this.btn_Logininjection.Text = "Login with injecction";
            this.btn_Logininjection.UseVisualStyleBackColor = true;
            // 
            // btn_login
            // 
            this.btn_login.Location = new System.Drawing.Point(271, 347);
            this.btn_login.Name = "btn_login";
            this.btn_login.Size = new System.Drawing.Size(75, 35);
            this.btn_login.TabIndex = 16;
            this.btn_login.Text = "Login";
            this.btn_login.UseVisualStyleBackColor = true;
            // 
            // txt_login
            // 
            this.txt_login.Location = new System.Drawing.Point(530, 115);
            this.txt_login.Name = "txt_login";
            this.txt_login.Size = new System.Drawing.Size(100, 22);
            this.txt_login.TabIndex = 15;
            // 
            // txt_Password
            // 
            this.txt_Password.Location = new System.Drawing.Point(530, 205);
            this.txt_Password.Name = "txt_Password";
            this.txt_Password.Size = new System.Drawing.Size(100, 22);
            this.txt_Password.TabIndex = 14;
            // 
            // lbl_Password
            // 
            this.lbl_Password.AutoSize = true;
            this.lbl_Password.Location = new System.Drawing.Point(330, 210);
            this.lbl_Password.Name = "lbl_Password";
            this.lbl_Password.Size = new System.Drawing.Size(61, 17);
            this.lbl_Password.TabIndex = 13;
            this.lbl_Password.Text = "Pssword";
            // 
            // lbl_loginId
            // 
            this.lbl_loginId.AutoSize = true;
            this.lbl_loginId.Location = new System.Drawing.Point(330, 120);
            this.lbl_loginId.Name = "lbl_loginId";
            this.lbl_loginId.Size = new System.Drawing.Size(60, 17);
            this.lbl_loginId.TabIndex = 12;
            this.lbl_loginId.Text = "Login ID";
            // 
            // Form_Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1022, 496);
            this.Controls.Add(this.btn_Logininjection);
            this.Controls.Add(this.btn_login);
            this.Controls.Add(this.txt_login);
            this.Controls.Add(this.txt_Password);
            this.Controls.Add(this.lbl_Password);
            this.Controls.Add(this.lbl_loginId);
            this.Name = "Form_Login";
            this.Text = "Form_Login";
            this.Load += new System.EventHandler(this.Form_Login_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Logininjection;
        private System.Windows.Forms.Button btn_login;
        private System.Windows.Forms.TextBox txt_login;
        private System.Windows.Forms.TextBox txt_Password;
        private System.Windows.Forms.Label lbl_Password;
        private System.Windows.Forms.Label lbl_loginId;
    }
}