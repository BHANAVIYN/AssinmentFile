﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;   
using System.Data.SqlClient;

namespace Windows_assinment_Dal_Student
{
    class DAL_Students
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Student"].ConnectionString);
        public int AddStudent(Students stu)
        {
            SqlCommand com_stu_insert = new SqlCommand
                ("insert Student values(@name,@city,@Address,@EmailID)", con);
            com_stu_insert.Parameters.AddWithValue("@name", stu.StudentName);
            com_stu_insert.Parameters.AddWithValue("@city", stu.StudentCity);
            com_stu_insert.Parameters.AddWithValue("@Address", stu.Studentaddress);
            com_stu_insert.Parameters.AddWithValue("@EmailID", stu.StudentEmailID);
            con.Open(); // opens the connection
            com_stu_insert.ExecuteNonQuery(); 
            SqlCommand com_id = new SqlCommand("select @@identity", con);  
            int ID = Convert.ToInt32(com_id.ExecuteScalar());
            con.Close();
            return ID;
        }
        public Students Find(int ID)
        {
            SqlCommand com_find = new SqlCommand
                ("select * from Student where StudentID=@id", con);
            com_find.Parameters.AddWithValue("@id", ID);
            con.Open();
            SqlDataReader dr = com_find.ExecuteReader();
            if (dr.Read())
            {
                Students e = new Students();
                e.StudentID = dr.GetInt32(0);
                e.StudentName = dr.GetString(1);
                e.StudentCity = dr.GetString(2);
                e.Studentaddress = dr.GetString(3);
                e.StudentEmailID = dr.GetString(4);
                con.Close();
                return e;


            }
            else
            {
                return null;
            }
        }

        public bool Update(int ID, string City, string StudentEmailID)
        {
            SqlCommand com_update = new SqlCommand("update Student set StudentCity=@city,StudentEmailID=@EmailID where StudentID=@id", con);
            com_update.Parameters.AddWithValue("@id", ID);
            com_update.Parameters.AddWithValue("@city", City);
            com_update.Parameters.AddWithValue("@EmailID", StudentEmailID);
            con.Open();
            int count = com_update.ExecuteNonQuery();
            con.Close();
            if (count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }

        }

        public bool Delete(int ID)
        {
            SqlCommand com_delete = new SqlCommand("delete Student where StudentID=@id", con);
            com_delete.Parameters.AddWithValue("@id", ID);
            con.Open();
            int count = com_delete.ExecuteNonQuery();
            con.Close();
            if (count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }

        }
    }
}



