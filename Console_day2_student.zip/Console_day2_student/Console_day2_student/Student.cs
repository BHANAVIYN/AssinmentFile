﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_day2_student
{
    class Student
    {
        private int StudentID;
        private string StudentName;
        private int StudentMarks;


        public int PStudentmarks
        {
            get
            {
                return this.StudentMarks;
            }
            set
            {
                if (value < 0 || value > 100)
                {
                    this.StudentMarks = 0;

                }
                else
                {
                    this.StudentMarks = value;
                }
            }
        }


        public int PStudentID
        {
            get

            {
                return this.StudentID;
            }
        }

        public string PStudentName
        {
            get
            {
                return this.StudentName;
            }
        }

        private static int count = 1000;


        public Student(string StudentName, int StudentMarks)

        {
            Student.count++;
            this.StudentID = Student.count;
            this.StudentName = StudentName;
            this.StudentMarks = StudentMarks;
            Console.WriteLine("object constructor");

        }
        static Student()
        {
            Student.count = 1000;
            Console.WriteLine("static constructor");
        }
    }
}

