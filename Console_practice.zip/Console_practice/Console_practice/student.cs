﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_practice
{
    class student
    {
        private string SName;
        private string SId;
        private int SMarks;
        private string SBranch;

        public student(string SName,string SId,int SMarks,string SBranch )
        {
            this.SName = SName;
            this.SId = SId;
            this.SMarks = SMarks;
            this.SBranch = SBranch;


        }
         public int GetMarks(Int1,int2)
        {

        }
    }
}
