declare @count int=0;
 set @count=100;
 select @count=count(*) from tbl_Employees
 if(@count>0)
 begin
 --insert
 end
 else
 begin
 ---update
 end
 select @count;




 declare @count int=0
 while(@count<10)
 begine
 select @count;
 set @count=@count+1;
 end

 select * from tbl_Employees
 
 create proc sp_Employees
 as
 select * from tbl_Employees
 
 Exec sp_Employees

 alter proc sp_Employees
 as
 select * from tbl_Employees order by EmployeeSalary desc


 create proc sp_Employees_City@City varchar(100)
 as
 select * from tbl_Employees where EmployeeCity=@City
  exec sp_Employees_City 'Pune'

  create proc sp_add_account(@Name varchar(100),@balance int)
  as
  if(@balance>=1000)
  begin
  insert tbl_accounts values (@name,@Balance)
  return @@identity
  end 
  else
  begin
  return 0
  end

  declare @r int
  Exec @r=sp_add_account 'Abc',20000
  select @r


  create proc sp_account_balance(@Accountid int)
  as
  declare @balance int
  select @balance=accountbalance from tbl_accounts where accountid=@Accontid;
  return @balance

  declare @bal int 
  exec @bal=sp_account_balance 1000
  select @bal

  select * from tbl_customerrs

  create proc sp_login(@id int,@Password varchar(100))
  as
  declare @count int
  select @count=count(*) from tbl_customerrs
  where customerid=@id and customerPasword=@password
  return @count


  declare @c int
  Exec @c=sp_login 1001,'pass@123'
  select @c


  select * from tbl_Employees

  create proc sp_employeedetails(@id int ,@name varchar(100) output,@city varchar(100) output)
  as
  select @name=employeename ,@city=employeecity from tbl_Employees where EmployeeID=@id

  declare @ename varchar(100) 
  declare @ecity varchar(100)
  exec sp_employeedetails 1001,@ename output ,@ecity output
  select @ename,@ecity



  create table tbl_student
  (
  studentid int ,
  studentname varchar(100),
  studentcity varchar(100)
  )

  create Trigger trag_add_student
  on tbl_student
  for insert
  as
  begin
  select * from inserted
  select 'trigger fired'
  end

  insert tbl_student values(1,'d','wed')




  insert tbl_student values(1,'d','wed')


  s
create table tbl_Itemss
(
ItemId int  primary key,
ItemQnty int
)
insert tbl_itemss values(4,100)
insert tbl_Itemss values(6,200)

select * from tbl_Itemss
create table tbl_Orders
(
OrderId int identity(1,1) ,
ItemId int foreign key references tbl_Itemss(itemid),
ItemQnty int ,
Qty int,
IemPrice int 
)
insert tbl_Orders values(2,4,4,20)
select * from  tbl_Itemss

create trigger trg_update_Itemss
on tbl_Orders
for insert
as
begin
declare @itemid int
declare @qty int
select @itemid=itemid,@qty=qty from inserted
update tbl_Itemss set itemqnty=itemqnty-@qty where itemid=@itemid
end
select * from tbl_orders



select *from tbl_Employees

create view V_employees_Bgl
as
select * from tbl_Employees where employeecity='Hassan'



insert  V_employees_Bgl values(1003,'abc','sjjd',2000)

alter view v_employees_bgl
as
select * from tbl_Employees where employeecity='Arsikere'  //Hassan
with check option



alter view v_employees_bgl
with encryption
as
select * from tbl_Employees where EmployeeCity='arsikere'
with check option

sp_helptext v_employees_bgl

select * from v_employees_bgl where EmployeeSalary>5000



alter view v_employees_bgl
with encryption,schemabinding
as
select employeeid,employeesalary,employeecity from dbo.tbl_Employees where EmployeeCity='hassan'
with check option


create table t1
(
code int,
Name varchar(100)
)

create table t2
(
code int,
city varchar(100)
)
select * from t1
select * from t2

insert t2 values(1,'bhs')

select t1.code,t1.name,t2.city from t1 join t2 on t1.code=t2.code


create view v_data
as
select t1.code,t1.name,t2.city from t1 join t2 on t1.code=t2.code

select * from v_data

insert v_data values(2,'sjdh','pune') -- inserting is difficult bcz it will confuse value are placed to which table so we go for trigger


create trigger trg_view
on v_data
instead of insert 
as
begin 
declare @code int 
declare @name varchar(100)
declare @city varchar(100)
select @code=code,@name=name,@city=city from inserted 
insert t1 values(@code,@name)
insert t2 values(@code,@city)
end



create table tble_mployeeinfo
(
Empid int identity(1,1),
emoployeename varchar(100),
EmployeeCity varchar(100)
)

declare @c int=0;
while(@c<50000)
begin
insert tble_mployeeinfo values('avldn','hss');
set @c=@c+1;
end 

select * from tble_mployeeinfo where empid=323045

create clustered index idx
on tble_mployeeinfo(empid)

select * from tbl_Employees

begin tran tr1 ---using transation

insert tbl_Employees values(1009,'jasy','dudh',2999)

commit tran ---store the data permanentlyh
rollback tran ---delet the date








