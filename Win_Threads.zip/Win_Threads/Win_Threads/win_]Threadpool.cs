﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace Win_Threads
{
    public partial class win__Threadpool : Form
    {
        public void Call(Object obj)
        {
            int id = Thread.CurrentThread.ManagedThreadId;
            MessageBox.Show("Thread ID :" + id + ",loop No :" + obj);
        }

        public win__Threadpool()
        {
            InitializeComponent();
        }

        private void btn_Threadpool_Click(object sender, EventArgs e)
        {
            ThreadPool.SetMaxThreads(10, 1000);  //worker thread 
            ThreadPool.SetMaxThreads(5, 1000);   //port thread 5 minimu

            int counter = 0;
            while(counter<20)
            {
                ThreadPool.UnsafeQueueUserWorkItem(Call, counter);  //
                counter++;
            }
        }
    }
}
