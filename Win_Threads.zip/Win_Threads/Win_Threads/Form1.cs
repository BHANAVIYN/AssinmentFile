﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;     //for threading

namespace Win_Threads
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_Newthread_Click(object sender, EventArgs e)
        {
            ThreadStart d = new ThreadStart(this.Call);
            Thread th = new Thread(d);  //rapper class
            th.IsBackground = true;
            th.Start();     //create a new Thread
           // MessageBox.Show("Main Thread Task");

           /* Thread th3 = new Thread(() =>
            {
                MessageBox.Show("New Task 3 Using Lambda Update1");


            });
            th3.IsBackground = true;
            th3.Start();*/
            MessageBox.Show("Main thread Task");
            th.Join();   //it blocks main method untill new task complet
            MessageBox.Show("Main thread Task2");

        }
        public void Call()          //function
        {
            MessageBox.Show("New Thread Task  Started");
            Thread.Sleep(10000);   //thred sleep at 10mlsac
            MessageBox.Show("New Thread Task Completed");
        }
    }
}
