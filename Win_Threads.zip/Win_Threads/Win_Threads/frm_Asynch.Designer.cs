﻿namespace Win_Threads
{
    partial class frm_Asynch
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_Number2 = new System.Windows.Forms.TextBox();
            this.txt_Number1 = new System.Windows.Forms.TextBox();
            this.lbl_Number1 = new System.Windows.Forms.Label();
            this.lvl_Number1 = new System.Windows.Forms.Label();
            this.btn_thread1 = new System.Windows.Forms.Button();
            this.lst_msg = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // txt_Number2
            // 
            this.txt_Number2.Location = new System.Drawing.Point(391, 155);
            this.txt_Number2.Name = "txt_Number2";
            this.txt_Number2.Size = new System.Drawing.Size(100, 22);
            this.txt_Number2.TabIndex = 10;
            // 
            // txt_Number1
            // 
            this.txt_Number1.Location = new System.Drawing.Point(391, 101);
            this.txt_Number1.Name = "txt_Number1";
            this.txt_Number1.Size = new System.Drawing.Size(100, 22);
            this.txt_Number1.TabIndex = 9;
            // 
            // lbl_Number1
            // 
            this.lbl_Number1.AutoSize = true;
            this.lbl_Number1.Location = new System.Drawing.Point(284, 101);
            this.lbl_Number1.Name = "lbl_Number1";
            this.lbl_Number1.Size = new System.Drawing.Size(74, 17);
            this.lbl_Number1.TabIndex = 8;
            this.lbl_Number1.Text = "Number 1:";
            // 
            // lvl_Number1
            // 
            this.lvl_Number1.AutoSize = true;
            this.lvl_Number1.Location = new System.Drawing.Point(284, 155);
            this.lvl_Number1.Name = "lvl_Number1";
            this.lvl_Number1.Size = new System.Drawing.Size(74, 17);
            this.lvl_Number1.TabIndex = 7;
            this.lvl_Number1.Text = "Number 2:";
            // 
            // btn_thread1
            // 
            this.btn_thread1.Location = new System.Drawing.Point(56, 288);
            this.btn_thread1.Name = "btn_thread1";
            this.btn_thread1.Size = new System.Drawing.Size(358, 23);
            this.btn_thread1.TabIndex = 6;
            this.btn_thread1.Text = "Asyn SUm";
            this.btn_thread1.UseVisualStyleBackColor = true;
            this.btn_thread1.Click += new System.EventHandler(this.btn_thread1_Click);
            // 
            // lst_msg
            // 
            this.lst_msg.FormattingEnabled = true;
            this.lst_msg.ItemHeight = 16;
            this.lst_msg.Location = new System.Drawing.Point(616, 254);
            this.lst_msg.Name = "lst_msg";
            this.lst_msg.Size = new System.Drawing.Size(120, 84);
            this.lst_msg.TabIndex = 11;
            // 
            // frm_Asynch
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(880, 419);
            this.Controls.Add(this.lst_msg);
            this.Controls.Add(this.txt_Number2);
            this.Controls.Add(this.txt_Number1);
            this.Controls.Add(this.lbl_Number1);
            this.Controls.Add(this.lvl_Number1);
            this.Controls.Add(this.btn_thread1);
            this.Name = "frm_Asynch";
            this.Text = "frm_Asynch";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txt_Number2;
        private System.Windows.Forms.TextBox txt_Number1;
        private System.Windows.Forms.Label lbl_Number1;
        private System.Windows.Forms.Label lvl_Number1;
        private System.Windows.Forms.Button btn_thread1;
        private System.Windows.Forms.ListBox lst_msg;
    }
}