﻿namespace Win_Threads
{
    partial class win__Threadpool
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Threadpool = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_Threadpool
            // 
            this.btn_Threadpool.Location = new System.Drawing.Point(241, 156);
            this.btn_Threadpool.Name = "btn_Threadpool";
            this.btn_Threadpool.Size = new System.Drawing.Size(270, 37);
            this.btn_Threadpool.TabIndex = 0;
            this.btn_Threadpool.Text = "Thread Pool";
            this.btn_Threadpool.UseVisualStyleBackColor = true;
            this.btn_Threadpool.Click += new System.EventHandler(this.btn_Threadpool_Click);
            // 
            // win__Threadpool
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(733, 412);
            this.Controls.Add(this.btn_Threadpool);
            this.Name = "win__Threadpool";
            this.Text = "win__Threadpool";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_Threadpool;
    }
}