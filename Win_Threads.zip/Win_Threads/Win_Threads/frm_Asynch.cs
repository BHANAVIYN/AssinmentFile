﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace Win_Threads
{
    public partial class frm_Asynch : Form
    {

        public delegate int delthread(int n1, int n2);
        public int GetSum(int n1,int n2)
        {
            Thread.Sleep(5000);
            return n1 + n2;
        }

        public delegate void del();
        public void callback(IAsyncResult res)
        {
            int returndata = d.EndInvoke(res);
            // MessageBox.Show("GetSum Called :"+res.AsyncState+":"+returndata);
            del obj = new del(() =>
            {
           lst_msg.Items.Add(res.AsyncState + ":" + returndata);  //thread affinity
        });
            this.BeginInvoke(obj);

        }
        public frm_Asynch()
        {
            InitializeComponent();
        }

        delthread d;
        private void btn_thread1_Click(object sender, EventArgs e)
        {
            if(d==null)
            {
                d=new delthread(this.GetSum);
            }

            int n1 = Convert.ToInt32(txt_Number1.Text);
            int n2 = Convert.ToInt32(txt_Number2.Text);
            string str = n1 + " +" + n2;           
            //delthread d = new delthread(this.GetSum);

            d.BeginInvoke(n1, n2, callback,str);  //new thread
           // d.BeginInvoke(10, 20, callback,"101");
        }
    }
}
