﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_day3_Singletone
{
    class Manager
    {
        private int ManagerID;
        private string ManagerName;

        public int PManagerID
        {
            get
            {
                return this.ManagerID;
            }
        }
        public string PManagerName
        {
            get
            {
                return this.ManagerName;
            }
        }
        public Manager(int ManagerID, string ManagerName)
        {
            this.ManagerID = ManagerID;
            this.ManagerName = ManagerName;

        }
        static Manager m;
        public static Manager GetManager()
        {
            if (m == null)
            {
                Manager m = new Manager(1001, "ABC");
            }
            return m;
        }
    }
}
