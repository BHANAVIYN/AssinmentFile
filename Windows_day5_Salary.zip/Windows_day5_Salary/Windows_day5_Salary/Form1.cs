﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Windows_day5_Salary
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (txt_days.Text == string.Empty)
            {
                MessageBox.Show("Enter Days");
            }
            else if (txt_perdaysalary.Text == string.Empty)
            {
                MessageBox.Show("Enter per Day Salary");
            }
            else
            {
                int days = Convert.ToInt32(txt_days.Text);
                int per_day_salary = Convert.ToInt32(txt_perdaysalary.Text);
                Salary_day5_liberary.Salary obj = new Salary_day5_liberary.Salary();
                int total = obj.GetSalary(days, per_day_salary);
                lbl_salary.Text = total.ToString();

            }
        }

        private void btn_getsalary_Click(object sender, EventArgs e)
        {

            if (txt_days.Text == string.Empty)
            {
                MessageBox.Show("Enter Days");
            }
            else if (txt_perdaysalary.Text == string.Empty)
            {
                MessageBox.Show("Enter per Day Salary");
            }
            else
            {
                int days = Convert.ToInt32(txt_days.Text);
                int per_day_salary = Convert.ToInt32(txt_perdaysalary.Text);
                Salary_day5_liberary.Salary obj = new Salary_day5_liberary.Salary();
                int total = obj.GetSalary(days, per_day_salary);
                lbl_salary.Text = total.ToString();

            }
        }

    }
}

