create database Webappli

use Webappli

create table tbl_OrderASPS
(
OrderID int identity(1,1) primary key,
CustomerEmailID varchar(100) ,
ProductPrice int,
ProductQnt int,
PaymentType varchar(100),
OrderCity varchar(100),
OrderAddress varchar(100)
)


create proc proc_order(@CustomerEmail

