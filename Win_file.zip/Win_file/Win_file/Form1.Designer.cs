﻿namespace Win_file
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_BinaryWriter = new System.Windows.Forms.Button();
            this.btn_Binaryreader = new System.Windows.Forms.Button();
            this.btn_streamReader = new System.Windows.Forms.Button();
            this.btn_StreamWriter = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_BinaryWriter
            // 
            this.btn_BinaryWriter.Location = new System.Drawing.Point(29, 114);
            this.btn_BinaryWriter.Name = "btn_BinaryWriter";
            this.btn_BinaryWriter.Size = new System.Drawing.Size(187, 41);
            this.btn_BinaryWriter.TabIndex = 0;
            this.btn_BinaryWriter.Text = "Binary Writer";
            this.btn_BinaryWriter.UseVisualStyleBackColor = true;
            this.btn_BinaryWriter.Click += new System.EventHandler(this.btn_BinaryWriter_Click);
            // 
            // btn_Binaryreader
            // 
            this.btn_Binaryreader.Location = new System.Drawing.Point(29, 228);
            this.btn_Binaryreader.Name = "btn_Binaryreader";
            this.btn_Binaryreader.Size = new System.Drawing.Size(187, 38);
            this.btn_Binaryreader.TabIndex = 1;
            this.btn_Binaryreader.Text = "Binary Reader";
            this.btn_Binaryreader.UseVisualStyleBackColor = true;
            this.btn_Binaryreader.Click += new System.EventHandler(this.btn_Binaryreader_Click);
            // 
            // btn_streamReader
            // 
            this.btn_streamReader.Location = new System.Drawing.Point(383, 236);
            this.btn_streamReader.Name = "btn_streamReader";
            this.btn_streamReader.Size = new System.Drawing.Size(162, 45);
            this.btn_streamReader.TabIndex = 2;
            this.btn_streamReader.Text = "Stream Reader";
            this.btn_streamReader.UseVisualStyleBackColor = true;
            this.btn_streamReader.Click += new System.EventHandler(this.btn_streamReader_Click);
            // 
            // btn_StreamWriter
            // 
            this.btn_StreamWriter.Location = new System.Drawing.Point(383, 114);
            this.btn_StreamWriter.Name = "btn_StreamWriter";
            this.btn_StreamWriter.Size = new System.Drawing.Size(162, 41);
            this.btn_StreamWriter.TabIndex = 3;
            this.btn_StreamWriter.Text = "Stream Writer";
            this.btn_StreamWriter.UseVisualStyleBackColor = true;
            this.btn_StreamWriter.Click += new System.EventHandler(this.btn_StreamWriter_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(649, 423);
            this.Controls.Add(this.btn_StreamWriter);
            this.Controls.Add(this.btn_streamReader);
            this.Controls.Add(this.btn_Binaryreader);
            this.Controls.Add(this.btn_BinaryWriter);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_BinaryWriter;
        private System.Windows.Forms.Button btn_Binaryreader;
        private System.Windows.Forms.Button btn_streamReader;
        private System.Windows.Forms.Button btn_StreamWriter;
    }
}

