﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Win_file
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_BinaryWriter_Click(object sender, EventArgs e)
        {
            FileStream fs = new FileStream("C:/TestFolder/a.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            BinaryWriter bw = new BinaryWriter(fs);
            int x = 100;
            bw.Write(x);
            bw.Flush();
            fs.Close();
            MessageBox.Show("File created");


        }

      
        private void btn_StreamWriter_Click(object sender, EventArgs e)
        {
            FileStream fs = new FileStream
                ("C:/TestFolder/b.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            StreamWriter sw = new StreamWriter(fs);
            string str = "hello dotnet";
            sw.WriteLine(str);
            sw.Flush();
            sw.Close();
            MessageBox.Show("File created");
        }

        private void btn_streamReader_Click(object sender, EventArgs e)
        {
            FileStream fs = new FileStream
                ("C:/TestFolder/b.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            StreamReader sr = new StreamReader(fs);
            string str = sr.ReadToEnd();
            fs.Close();
            MessageBox.Show(str);
        }

        private void btn_Binaryreader_Click(object sender, EventArgs e)
        {
            FileStream fs = new FileStream("C:/TestFolder/a.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            BinaryReader br = new BinaryReader(fs);
            int x = br.ReadInt32();
            fs.Flush();
            fs.Close();
            MessageBox.Show(x.ToString());
        }
    }
}
