﻿namespace Windows_dya5_sum_exeapplication
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_Number1 = new System.Windows.Forms.Label();
            this.lbl_Number2 = new System.Windows.Forms.Label();
            this.txt_Number1 = new System.Windows.Forms.TextBox();
            this.txt_Number2 = new System.Windows.Forms.TextBox();
            this.btn_GetSum = new System.Windows.Forms.Button();
            this.btn_GetMul = new System.Windows.Forms.Button();
            this.btn_Sub = new System.Windows.Forms.Button();
            this.btn_Div = new System.Windows.Forms.Button();
            this.lbl_GetResult = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl_Number1
            // 
            this.lbl_Number1.AutoSize = true;
            this.lbl_Number1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Number1.Location = new System.Drawing.Point(64, 73);
            this.lbl_Number1.Name = "lbl_Number1";
            this.lbl_Number1.Size = new System.Drawing.Size(124, 29);
            this.lbl_Number1.TabIndex = 0;
            this.lbl_Number1.Text = "Number1:";
            // 
            // lbl_Number2
            // 
            this.lbl_Number2.AutoSize = true;
            this.lbl_Number2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Number2.Location = new System.Drawing.Point(64, 121);
            this.lbl_Number2.Name = "lbl_Number2";
            this.lbl_Number2.Size = new System.Drawing.Size(124, 29);
            this.lbl_Number2.TabIndex = 1;
            this.lbl_Number2.Text = "Number2:";
            // 
            // txt_Number1
            // 
            this.txt_Number1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Number1.Location = new System.Drawing.Point(194, 80);
            this.txt_Number1.Name = "txt_Number1";
            this.txt_Number1.Size = new System.Drawing.Size(144, 26);
            this.txt_Number1.TabIndex = 2;
            // 
            // txt_Number2
            // 
            this.txt_Number2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Number2.Location = new System.Drawing.Point(194, 129);
            this.txt_Number2.Name = "txt_Number2";
            this.txt_Number2.Size = new System.Drawing.Size(144, 26);
            this.txt_Number2.TabIndex = 3;
            // 
            // btn_GetSum
            // 
            this.btn_GetSum.Location = new System.Drawing.Point(113, 176);
            this.btn_GetSum.Name = "btn_GetSum";
            this.btn_GetSum.Size = new System.Drawing.Size(75, 23);
            this.btn_GetSum.TabIndex = 4;
            this.btn_GetSum.Text = "Sum";
            this.btn_GetSum.UseVisualStyleBackColor = true;
            this.btn_GetSum.Click += new System.EventHandler(this.btn_GetSum_Click);
            // 
            // btn_GetMul
            // 
            this.btn_GetMul.Location = new System.Drawing.Point(113, 217);
            this.btn_GetMul.Name = "btn_GetMul";
            this.btn_GetMul.Size = new System.Drawing.Size(75, 23);
            this.btn_GetMul.TabIndex = 5;
            this.btn_GetMul.Text = "Multiply";
            this.btn_GetMul.UseVisualStyleBackColor = true;
            this.btn_GetMul.Click += new System.EventHandler(this.btn_GetMul_Click);
            // 
            // btn_Sub
            // 
            this.btn_Sub.Location = new System.Drawing.Point(113, 259);
            this.btn_Sub.Name = "btn_Sub";
            this.btn_Sub.Size = new System.Drawing.Size(75, 23);
            this.btn_Sub.TabIndex = 6;
            this.btn_Sub.Text = "Substraction";
            this.btn_Sub.UseVisualStyleBackColor = true;
            this.btn_Sub.Click += new System.EventHandler(this.btn_Sub_Click);
            // 
            // btn_Div
            // 
            this.btn_Div.Location = new System.Drawing.Point(113, 309);
            this.btn_Div.Name = "btn_Div";
            this.btn_Div.Size = new System.Drawing.Size(75, 23);
            this.btn_Div.TabIndex = 7;
            this.btn_Div.Text = "Division";
            this.btn_Div.UseVisualStyleBackColor = true;
            this.btn_Div.Click += new System.EventHandler(this.btn_Div_Click);
            // 
            // lbl_GetResult
            // 
            this.lbl_GetResult.AutoSize = true;
            this.lbl_GetResult.Location = new System.Drawing.Point(409, 234);
            this.lbl_GetResult.Name = "lbl_GetResult";
            this.lbl_GetResult.Size = new System.Drawing.Size(71, 17);
            this.lbl_GetResult.TabIndex = 8;
            this.lbl_GetResult.Text = "GetResult";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(700, 387);
            this.Controls.Add(this.lbl_GetResult);
            this.Controls.Add(this.btn_Div);
            this.Controls.Add(this.btn_Sub);
            this.Controls.Add(this.btn_GetMul);
            this.Controls.Add(this.btn_GetSum);
            this.Controls.Add(this.txt_Number2);
            this.Controls.Add(this.txt_Number1);
            this.Controls.Add(this.lbl_Number2);
            this.Controls.Add(this.lbl_Number1);
            this.Name = "Form1";
            this.Text = "h";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_Number1;
        private System.Windows.Forms.Label lbl_Number2;
        private System.Windows.Forms.TextBox txt_Number1;
        private System.Windows.Forms.TextBox txt_Number2;
        private System.Windows.Forms.Button btn_GetSum;
        private System.Windows.Forms.Button btn_GetMul;
        private System.Windows.Forms.Button btn_Sub;
        private System.Windows.Forms.Button btn_Div;
        private System.Windows.Forms.Label lbl_GetResult;
    }
}

