﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_day1_Account
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("enter account id:");
            int AccountID = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter Customer Name");
            string CustomerName = Console.ReadLine();
            Console.WriteLine("enter customer address");
            string customeraddress = Console.ReadLine();
            Console.WriteLine("enter type of account");
            string typeofaccount = Console.ReadLine();
            Console.WriteLine("enter balance");
            int balance = Convert.ToInt32(Console.ReadLine());
            bool f = true;
            while (f)
            {
                Console.WriteLine("1.deposit");
                Console.WriteLine("2.withdraw");
                Console.WriteLine("3.check balance");
                Console.WriteLine("4.return");
                Console.WriteLine("write any number from 1 to 4");
                int number = Convert.ToInt32(Console.ReadLine());
                switch (number)
                {
                    case 1:
                        Console.WriteLine("enter amount to deposit");
                        int amount = Convert.ToInt32(Console.ReadLine());
                        if (amount < 500)
                        {
                            Console.WriteLine("minimum 500 should be deposited");
                        }
                        else
                        {
                            Console.WriteLine("amount is deposited");
                            balance = amount + balance;
                        }
                        break;

                    case 2:
                        Console.WriteLine("enter amount to be withdrawn");
                        int amount1 = Convert.ToInt32(Console.ReadLine());
                        if (amount1 > 5000)
                        {
                            Console.WriteLine("5000 is the limit");

                        }
                        else if (amount1 > balance)
                        {
                            Console.WriteLine("insufficient funds");
                        }
                        else if (amount1 < balance)
                        {
                            Console.WriteLine("funds are deposited");
                        }
                        break;

                    case 3:

                        Console.WriteLine("remaing balance is:");
                        Console.WriteLine(balance);
                        break;
                    case 4:
                        f = false ;
                        break;

                    default:
                        Console.WriteLine("invalid number");
                        break;
                }
            }
        }
    }
}

