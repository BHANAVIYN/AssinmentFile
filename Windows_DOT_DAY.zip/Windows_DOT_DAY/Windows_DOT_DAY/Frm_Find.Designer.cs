﻿namespace Windows_DOT_DAY
{
    partial class Frm_Find
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Update = new System.Windows.Forms.Button();
            this.btn_find = new System.Windows.Forms.Button();
            this.txt_EmployeePassword = new System.Windows.Forms.TextBox();
            this.txt_EmployeeCity = new System.Windows.Forms.TextBox();
            this.txt_EmployeeName = new System.Windows.Forms.TextBox();
            this.lbl_EmployeePaswrd = new System.Windows.Forms.Label();
            this.lbl_EmployeeCity = new System.Windows.Forms.Label();
            this.lbl_Employeename = new System.Windows.Forms.Label();
            this.btn_Delet = new System.Windows.Forms.Button();
            this.lbl_EmployeeId = new System.Windows.Forms.Label();
            this.lbl_EmployeeDOJ = new System.Windows.Forms.Label();
            this.txt_EmployeeDOJ = new System.Windows.Forms.TextBox();
            this.txt_EmployeeID = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btn_Update
            // 
            this.btn_Update.Location = new System.Drawing.Point(571, 180);
            this.btn_Update.Name = "btn_Update";
            this.btn_Update.Size = new System.Drawing.Size(153, 36);
            this.btn_Update.TabIndex = 15;
            this.btn_Update.Text = "Update";
            this.btn_Update.UseVisualStyleBackColor = true;
            this.btn_Update.Click += new System.EventHandler(this.btn_Update_Click);
            // 
            // btn_find
            // 
            this.btn_find.Location = new System.Drawing.Point(571, 68);
            this.btn_find.Name = "btn_find";
            this.btn_find.Size = new System.Drawing.Size(153, 36);
            this.btn_find.TabIndex = 14;
            this.btn_find.Text = "Find ";
            this.btn_find.UseVisualStyleBackColor = true;
            this.btn_find.Click += new System.EventHandler(this.btn_newemployee_Click);
            // 
            // txt_EmployeePassword
            // 
            this.txt_EmployeePassword.Location = new System.Drawing.Point(335, 219);
            this.txt_EmployeePassword.Name = "txt_EmployeePassword";
            this.txt_EmployeePassword.Size = new System.Drawing.Size(158, 22);
            this.txt_EmployeePassword.TabIndex = 13;
            // 
            // txt_EmployeeCity
            // 
            this.txt_EmployeeCity.Location = new System.Drawing.Point(335, 148);
            this.txt_EmployeeCity.Name = "txt_EmployeeCity";
            this.txt_EmployeeCity.Size = new System.Drawing.Size(158, 22);
            this.txt_EmployeeCity.TabIndex = 12;
            // 
            // txt_EmployeeName
            // 
            this.txt_EmployeeName.Location = new System.Drawing.Point(335, 87);
            this.txt_EmployeeName.Name = "txt_EmployeeName";
            this.txt_EmployeeName.Size = new System.Drawing.Size(158, 22);
            this.txt_EmployeeName.TabIndex = 11;
            // 
            // lbl_EmployeePaswrd
            // 
            this.lbl_EmployeePaswrd.AutoSize = true;
            this.lbl_EmployeePaswrd.Location = new System.Drawing.Point(158, 209);
            this.lbl_EmployeePaswrd.Name = "lbl_EmployeePaswrd";
            this.lbl_EmployeePaswrd.Size = new System.Drawing.Size(135, 17);
            this.lbl_EmployeePaswrd.TabIndex = 10;
            this.lbl_EmployeePaswrd.Text = "Employee Password";
            // 
            // lbl_EmployeeCity
            // 
            this.lbl_EmployeeCity.AutoSize = true;
            this.lbl_EmployeeCity.Location = new System.Drawing.Point(158, 148);
            this.lbl_EmployeeCity.Name = "lbl_EmployeeCity";
            this.lbl_EmployeeCity.Size = new System.Drawing.Size(93, 17);
            this.lbl_EmployeeCity.TabIndex = 9;
            this.lbl_EmployeeCity.Text = "EmployeeCity";
            // 
            // lbl_Employeename
            // 
            this.lbl_Employeename.AutoSize = true;
            this.lbl_Employeename.Location = new System.Drawing.Point(158, 87);
            this.lbl_Employeename.Name = "lbl_Employeename";
            this.lbl_Employeename.Size = new System.Drawing.Size(107, 17);
            this.lbl_Employeename.TabIndex = 8;
            this.lbl_Employeename.Text = "EmployeeName";
            // 
            // btn_Delet
            // 
            this.btn_Delet.Location = new System.Drawing.Point(571, 243);
            this.btn_Delet.Name = "btn_Delet";
            this.btn_Delet.Size = new System.Drawing.Size(153, 34);
            this.btn_Delet.TabIndex = 17;
            this.btn_Delet.Text = "Delete";
            this.btn_Delet.UseVisualStyleBackColor = true;
            this.btn_Delet.Click += new System.EventHandler(this.btn_Delet_Click);
            // 
            // lbl_EmployeeId
            // 
            this.lbl_EmployeeId.AutoSize = true;
            this.lbl_EmployeeId.Location = new System.Drawing.Point(170, 33);
            this.lbl_EmployeeId.Name = "lbl_EmployeeId";
            this.lbl_EmployeeId.Size = new System.Drawing.Size(87, 17);
            this.lbl_EmployeeId.TabIndex = 18;
            this.lbl_EmployeeId.Text = "Employee ID";
            // 
            // lbl_EmployeeDOJ
            // 
            this.lbl_EmployeeDOJ.AutoSize = true;
            this.lbl_EmployeeDOJ.Location = new System.Drawing.Point(170, 270);
            this.lbl_EmployeeDOJ.Name = "lbl_EmployeeDOJ";
            this.lbl_EmployeeDOJ.Size = new System.Drawing.Size(102, 17);
            this.lbl_EmployeeDOJ.TabIndex = 19;
            this.lbl_EmployeeDOJ.Text = "Employee DOJ";
            // 
            // txt_EmployeeDOJ
            // 
            this.txt_EmployeeDOJ.Location = new System.Drawing.Point(335, 270);
            this.txt_EmployeeDOJ.Name = "txt_EmployeeDOJ";
            this.txt_EmployeeDOJ.Size = new System.Drawing.Size(158, 22);
            this.txt_EmployeeDOJ.TabIndex = 20;
            // 
            // txt_EmployeeID
            // 
            this.txt_EmployeeID.Location = new System.Drawing.Point(335, 33);
            this.txt_EmployeeID.Name = "txt_EmployeeID";
            this.txt_EmployeeID.Size = new System.Drawing.Size(158, 22);
            this.txt_EmployeeID.TabIndex = 21;
            // 
            // Frm_Find
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(994, 428);
            this.Controls.Add(this.txt_EmployeeID);
            this.Controls.Add(this.txt_EmployeeDOJ);
            this.Controls.Add(this.lbl_EmployeeDOJ);
            this.Controls.Add(this.lbl_EmployeeId);
            this.Controls.Add(this.btn_Delet);
            this.Controls.Add(this.btn_Update);
            this.Controls.Add(this.btn_find);
            this.Controls.Add(this.txt_EmployeePassword);
            this.Controls.Add(this.txt_EmployeeCity);
            this.Controls.Add(this.txt_EmployeeName);
            this.Controls.Add(this.lbl_EmployeePaswrd);
            this.Controls.Add(this.lbl_EmployeeCity);
            this.Controls.Add(this.lbl_Employeename);
            this.Name = "Frm_Find";
            this.Text = "Frm_Find";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Update;
        private System.Windows.Forms.Button btn_find;
        private System.Windows.Forms.TextBox txt_EmployeePassword;
        private System.Windows.Forms.TextBox txt_EmployeeCity;
        private System.Windows.Forms.TextBox txt_EmployeeName;
        private System.Windows.Forms.Label lbl_EmployeePaswrd;
        private System.Windows.Forms.Label lbl_EmployeeCity;
        private System.Windows.Forms.Label lbl_Employeename;
        private System.Windows.Forms.Button btn_Delet;
        private System.Windows.Forms.Label lbl_EmployeeId;
        private System.Windows.Forms.Label lbl_EmployeeDOJ;
        private System.Windows.Forms.TextBox txt_EmployeeDOJ;
        private System.Windows.Forms.TextBox txt_EmployeeID;
    }
}