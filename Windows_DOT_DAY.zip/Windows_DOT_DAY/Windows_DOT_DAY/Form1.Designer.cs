﻿namespace Windows_DOT_DAY
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_Employeename = new System.Windows.Forms.Label();
            this.lbl_EmployeeCity = new System.Windows.Forms.Label();
            this.lbl_EmployeePaswrd = new System.Windows.Forms.Label();
            this.txt_EmployeeName = new System.Windows.Forms.TextBox();
            this.txt_EmployeeCity = new System.Windows.Forms.TextBox();
            this.txt_EmployeePassword = new System.Windows.Forms.TextBox();
            this.btn_newemployee = new System.Windows.Forms.Button();
            this.btn_Reset = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_Employeename
            // 
            this.lbl_Employeename.AutoSize = true;
            this.lbl_Employeename.Location = new System.Drawing.Point(68, 86);
            this.lbl_Employeename.Name = "lbl_Employeename";
            this.lbl_Employeename.Size = new System.Drawing.Size(107, 17);
            this.lbl_Employeename.TabIndex = 0;
            this.lbl_Employeename.Text = "EmployeeName";
            // 
            // lbl_EmployeeCity
            // 
            this.lbl_EmployeeCity.AutoSize = true;
            this.lbl_EmployeeCity.Location = new System.Drawing.Point(68, 156);
            this.lbl_EmployeeCity.Name = "lbl_EmployeeCity";
            this.lbl_EmployeeCity.Size = new System.Drawing.Size(93, 17);
            this.lbl_EmployeeCity.TabIndex = 1;
            this.lbl_EmployeeCity.Text = "EmployeeCity";
            // 
            // lbl_EmployeePaswrd
            // 
            this.lbl_EmployeePaswrd.AutoSize = true;
            this.lbl_EmployeePaswrd.Location = new System.Drawing.Point(68, 208);
            this.lbl_EmployeePaswrd.Name = "lbl_EmployeePaswrd";
            this.lbl_EmployeePaswrd.Size = new System.Drawing.Size(135, 17);
            this.lbl_EmployeePaswrd.TabIndex = 2;
            this.lbl_EmployeePaswrd.Text = "Employee Password";
            // 
            // txt_EmployeeName
            // 
            this.txt_EmployeeName.Location = new System.Drawing.Point(245, 81);
            this.txt_EmployeeName.Name = "txt_EmployeeName";
            this.txt_EmployeeName.Size = new System.Drawing.Size(158, 22);
            this.txt_EmployeeName.TabIndex = 3;
            // 
            // txt_EmployeeCity
            // 
            this.txt_EmployeeCity.Location = new System.Drawing.Point(245, 142);
            this.txt_EmployeeCity.Name = "txt_EmployeeCity";
            this.txt_EmployeeCity.Size = new System.Drawing.Size(158, 22);
            this.txt_EmployeeCity.TabIndex = 4;
            // 
            // txt_EmployeePassword
            // 
            this.txt_EmployeePassword.Location = new System.Drawing.Point(256, 208);
            this.txt_EmployeePassword.Name = "txt_EmployeePassword";
            this.txt_EmployeePassword.Size = new System.Drawing.Size(158, 22);
            this.txt_EmployeePassword.TabIndex = 5;
            // 
            // btn_newemployee
            // 
            this.btn_newemployee.Location = new System.Drawing.Point(100, 309);
            this.btn_newemployee.Name = "btn_newemployee";
            this.btn_newemployee.Size = new System.Drawing.Size(153, 36);
            this.btn_newemployee.TabIndex = 6;
            this.btn_newemployee.Text = "New Employee";
            this.btn_newemployee.UseVisualStyleBackColor = true;
            this.btn_newemployee.Click += new System.EventHandler(this.btn_newemployee_Click);
            // 
            // btn_Reset
            // 
            this.btn_Reset.Location = new System.Drawing.Point(353, 309);
            this.btn_Reset.Name = "btn_Reset";
            this.btn_Reset.Size = new System.Drawing.Size(100, 36);
            this.btn_Reset.TabIndex = 7;
            this.btn_Reset.Text = "Reset";
            this.btn_Reset.UseVisualStyleBackColor = true;
            this.btn_Reset.Click += new System.EventHandler(this.btn_Reset_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(739, 398);
            this.Controls.Add(this.btn_Reset);
            this.Controls.Add(this.btn_newemployee);
            this.Controls.Add(this.txt_EmployeePassword);
            this.Controls.Add(this.txt_EmployeeCity);
            this.Controls.Add(this.txt_EmployeeName);
            this.Controls.Add(this.lbl_EmployeePaswrd);
            this.Controls.Add(this.lbl_EmployeeCity);
            this.Controls.Add(this.lbl_Employeename);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_Employeename;
        private System.Windows.Forms.Label lbl_EmployeeCity;
        private System.Windows.Forms.Label lbl_EmployeePaswrd;
        private System.Windows.Forms.TextBox txt_EmployeeName;
        private System.Windows.Forms.TextBox txt_EmployeeCity;
        private System.Windows.Forms.TextBox txt_EmployeePassword;
        private System.Windows.Forms.Button btn_newemployee;
        private System.Windows.Forms.Button btn_Reset;
    }
}

