﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_day4_Generics_correction
{
    class Student
    {
        public delegate void delleave(int Id, string Reason);
        public event delleave evtleave; //event from delegates to 
        private int StudentID;
        private string StudentName;
        private string StudentCity;
        private static int Count = 1000;

        public Student(string StudentName, string StudentCity)
        {
            Student.Count++;
            this.StudentID = Student.Count;
            this.StudentName = StudentName;
            this.StudentCity = StudentCity;


        }
        public int PStudentID { get { return this.StudentID; } }
        public string PStudentName { get { return this.StudentName; } }
        public string PstudentCity { get { return this.StudentCity; } }

        public void TakeLeave(string Reason)
        {
            if(this.evtleave!=null)
            {
                this.evtleave(this.StudentID,Reason);
            }
            Console.WriteLine("Student On Leave:" + this.StudentID + ",Reason:" + Reason);
            
        }
    }
}
