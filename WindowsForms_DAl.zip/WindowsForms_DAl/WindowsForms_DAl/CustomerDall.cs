﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;   //Dll ref
using System.Data.SqlClient;

namespace WindowsForms_DAl
{
    class CustomerDall
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["custm"].ConnectionString);
        public int AddCustomer(Customerss cus)
        {
            SqlCommand com_cus_insert = new SqlCommand("insert tbl_customers values(@name,@passwors,@City,@Address,@MOBNO,@EmailID)",con);
            com_cus_insert.Parameters.AddWithValue("@name", cus.CustomerName);
            com_cus_insert.Parameters.AddWithValue("@password", cus.CustomerPassword);
            com_cus_insert.Parameters.AddWithValue("@City", cus.CustomerCity);
            com_cus_insert.Parameters.AddWithValue("@Address", cus.CustomerAddress);
            com_cus_insert.Parameters.AddWithValue("@MoBNO", cus.CustomerMobileNO);
            com_cus_insert.Parameters.AddWithValue("@EmailID", cus.CustomerEmailID);
            con.Open();
            com_cus_insert.ExecuteNonQuery();
            SqlCommand com_id = new SqlCommand("select @@identity", con);  //read the CustomerId one by one
            int ID = Convert.ToInt32(com_id.ExecuteScalar());
            con.Close();
            return ID;

        }
         public Customerss Find(int ID)
        {
            SqlCommand com_find = new SqlCommand("select * from tbl_customers where CustomerID=@Id ", con);
            com_find.Parameters.AddWithValue("@Id", ID);
            con.Open();
            SqlDataReader cr = com_find.ExecuteReader();
            if(cr.Read())
            {
                Customerss c = new Customerss();
                c.CustomerID = cr.GetInt32(0);  //1st column
                c.CustomerName = cr.GetString(1); //2nd column
                c.CustomerPassword = cr.GetString(2);
                c.CustomerCity = cr.GetString(3);
                c.CustomerAddress = cr.GetString(4);
                c.CustomerMobileNO = cr.GetString(5);
                c.CustomerEmailID = cr.GetString(6);
                con.Close();
                return c;
            }
            else
            {
                return null;
            }
        }
         public bool Update(int ID,string Name,string City)
        {
            SqlCommand com_update = new SqlCommand("update tbl_customers set CustomerCity=@city,CustomerPassword=@p

        }
       







    }
}
