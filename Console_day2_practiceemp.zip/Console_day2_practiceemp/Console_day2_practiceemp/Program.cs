﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_day2_practiceemp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter employeeid");
            int id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter employeename");
            string name = Console.ReadLine();
            Console.WriteLine("enter employee city");
            string city = Console.ReadLine();
            Console.WriteLine("enter employee salary");
            double salary = Convert.ToDouble(Console.ReadLine());

            Employee obj = new Employee(id, name, city, salary);
            Console.WriteLine("enter number of days");
            int days = Convert.ToInt32(Console.ReadLine());

            double a = obj.getemployeesalary(days);
            Console.WriteLine(a);

            string b = obj.getdetails();
            Console.WriteLine(b);
            Console.ReadLine();

            {

            }

        }
    }
}

