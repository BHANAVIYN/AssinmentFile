﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Console_linq_XML
{
    class Program
    {
        static void Main(string[] args)
        {
            XElement Orders = new XElement("Orders",
                new XElement("Order", new XElement("OrderID", "1001"),
                new XElement("CustomerName", "bhavya"),
                new XElement("OrderAmnt", "10000")),

            new XElement("Order",new XElement("OrderID","1002"),
                new XElement ("CustomerName","Navya"),
                new XElement("OrderAmnt","30000"))
                );

            Orders.Save("C:/XML/orders.XML");
            Console.WriteLine("XML file Created");

            Console.ReadLine();





           /* string url = @"c:\users\user\documents\visual studio 2015\Projects\Console_linq_XML\Console_linq_XML\XML_Customer.xml";
            XDocument doc = XDocument.Load(url);

            var data = from x in doc.Descendants("Customer")
                       //where x.Element("CustomerCity").value=="BGL"
                       select new
                       {
                           CID = x.Element("CustomerID").Value,
                           CName = x.Element("CustomerName").Value,
                           CCity = x.Element("CustomerCity").Value
                       };
            foreach(var d in data)
            {
                Console.WriteLine(d.CID + " " + d.CName + " " + d.CCity);
            }*/
            Console.ReadLine();
            
        }
    }
}
