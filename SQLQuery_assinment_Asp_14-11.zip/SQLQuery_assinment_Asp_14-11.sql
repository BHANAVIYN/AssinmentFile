Create database LiberaryDB

use LiberaryDB

create table tbl_Students
(
StudentID int identity(1,1) primary key,
StudentName varchar(100)not null,
StudentEmailID varchar(100)not null,
StudentPssword varchar(100)not null,
StudentImage varchar(100)not null
)

create table tbl_Books
(
BookID int identity(100,1) primary key,
BookName varchar(100)not null,
AuthorName varchar(100)not null,
BookImage varchar(100)not null
)
select *from tbl_Students

create table tbl_IssuedBooks
(
IssueID int identity(1000,1),
BookID int foreign key references tbl_Books(BookID),
StudentID int foreign key references tbl_Students (StudentID),
IssueDate DateTime not null,
IssueStatus varchar(100)not null
)


create proc proc_AddIssueBook(@BID int,@SID int,@IssueStatus varchar(100))
as
insert tbl_IssuedBooks values(@BID,@SID,@IssueStatus,getdate())
return @@identity

create proc proc_AddStudents(@Sname varchar(100),@Semail varchar(100),@Spassword varchar(100),@Simage varchar(100))
as
insert tbl_Students values(@Sname,@Semail,@Spassword,@Simage)
return @@identity

create proc proc_AddBooks(@Bname varchar(100),@Aname varchar(100),@Bimage varchar(100))
as
insert tbl_Books values(@Bname,@Aname,@Bimage)
return @@identity


create proc proc_BookDetails(@ID int)
as
select * from tbl_Books where BookID=@ID

create proc proc_ShowIssuedBook(@BID int)
as
select * from tbl_IssuedBooks where BookID=@BID

create proc proc_Find(@BID int)
as
select * from tbl_IssuedBooks where BookID=@BID

create proc Proc_SearchBook(@key varchar(100))
as
select * from tbl_Books where BookID like '%'+@key+'%' or
BookName like '%'+@key+'%'


create proc proc_SearchIssueBook(@key varchar(100))
as
select * from tbl_IssuedBooks where BookID like '%'+@key+'%'



create proc proc_Login(@SID int,@Spassword varchar(100))
as
declare @count int
select @count=count(*) from tbl_Students
where StudentID=@SID and StudentPssword=@Spassword
return @count






select * from tbl_Students

select * from tbl_IssuedBooks

select * from tbl_Books
