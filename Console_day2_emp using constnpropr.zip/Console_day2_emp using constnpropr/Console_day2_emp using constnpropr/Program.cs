﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_day2_emp_using_constnpropr
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Account ID:");
            int AccountID = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Customer Name:");
            string Name = Console.ReadLine();
            Console.WriteLine("Enter Account Balance:");
            int Balance = Convert.ToInt32(Console.ReadLine());

            Account obj = new Account(AccountID, Name, Balance);
            int NewBalance = obj.GetBalance();
            Console.WriteLine("Enter an amount to withdraw:");
            int Amt = Convert.ToInt32(Console.ReadLine());
            obj.Withdraw(Amt);
            NewBalance = obj.GetBalance();
            Console.Write("Account Balance:" + NewBalance);
            Console.WriteLine("Enter an amount to deposit");
            Amt = Convert.ToInt32(Console.ReadLine());
            obj.Deposit(Amt);

            NewBalance = obj.GetBalance();
            Console.WriteLine("Account Balance:" + NewBalance);



            /*
            Console.WriteLine("Enter customer ID:");
            int id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Customer Name:");
            string name = Console.ReadLine();
            Console.WriteLine("Enter customer city:");
            string city = Console.ReadLine();

            customer obj = new customer(id,name,city);

            string details = obj.GetDetails();
            Console.WriteLine(details);*/
            Console.ReadLine();





        }
    }
}

