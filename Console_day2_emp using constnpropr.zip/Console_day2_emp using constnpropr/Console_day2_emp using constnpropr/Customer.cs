﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_day2_emp_using_constnpropr
{
    class Customer
    {
        private int CustomerId;
        private string CustomerName;
        private string CustomerCity;

        public Customer(int CustomerId, string CustomerName, string CustomerCity)
        {
            this.CustomerId = CustomerId;
            this.CustomerName = CustomerName;
            this.CustomerCity = CustomerCity;


        }
        public string GetDetails()
        {
            return this.CustomerId + " " + this.CustomerName + " " + this.CustomerCity;

        }




    }
}

