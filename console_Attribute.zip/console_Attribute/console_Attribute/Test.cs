﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace console_Attribute
{
    [Developer("1001","jhon")]
    class Test
    {
        [Obsolete("Not in use,use XYz")]  //aditional information 
        [Developer("1002","david")]
        public void Call1()
        {
            Console.WriteLine("Call Function Called");
        }
    }
}
