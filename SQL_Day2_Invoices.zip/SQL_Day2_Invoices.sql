create database PathfrontDB2

use   PathfrontDB2

create table tbl_customers
(
customerId int identity(1000,1) primary key,
customerName varchar(100) not null,
customerCity varchar(100) not null,
customerEmail varchar(100) not null unique,
customerMobile varchar(100) not null unique
)


create table tbl_Items
(
ItemId int identity(1,1) primary key,
ItemName varchar(100) not null,
Itemprice int check(Itemprice>0)
)


create table tbl_invoices
(
InvoiceId int identity(10000,1) primary key,
customerId int not null foreign key references tbl_customers(customerId),
invoiceCity varchar(100) not null,
invoiceDate DateTime not null,
invoiceAddress varchar(100)
)


create table tbl_invoiceitems
(
invoiceId int not null foreign key references tbl_invoices(invoiceid),
ItemId int not null foreign key references tbl_items(itemid),
itemqty int check (itemqty>0),
itemprice int check(itemprice>0)
primary key (invoiceid,itemid)
)


